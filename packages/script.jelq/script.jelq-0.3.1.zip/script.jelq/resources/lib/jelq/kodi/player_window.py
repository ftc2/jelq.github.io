"""Kodi window adapter for the jelq-owned playback surfaces."""

from __future__ import annotations

import queue
import threading
import time
from contextlib import suppress
from typing import Any, Iterable, Sequence, cast

import xbmc
import xbmcgui

from jelq.models import Segment, integer
from jelq.player_ui import (
  PlaybackBadge,
  StreamChoice,
  chapter_ranges,
  format_time,
  percentage,
  range_string,
  segment_rows,
)

CAPTURE = 1
SEEK_SLIDER = 50
SEEK_HEAD = 51
SEEK_PREVIEW_BUBBLE = 52
SEEK_TIME_BUBBLE = 53
PLAY_PAUSE = 101
PREVIOUS_EPISODE = 102
EPISODES = 103
NEXT_EPISODE = 104
AUDIO = 105
SUBTITLES = 106
CHAPTERS = 107
MORE = 108
INFO = 109
PANEL_LIST = 300
PANEL_BACK = 301
UP_NEXT_START = 400
UP_NEXT_HIDE = 401
SEGMENT_SKIP = 410
_BACK_ACTIONS = frozenset({9, 10, 92})
_EXIT_SURFACES = frozenset({'clean', 'prompt'})
_SEEK_RAIL_LEFT = 64
_SEEK_RAIL_WIDTH = 1792
_SEEK_HEAD_TOP = 817
_SEEK_PREVIEW_TOP = 355
_SEEK_PREVIEW_WIDTH = 410
_SEEK_TIME_TOP = 750
_SEEK_TIME_WIDTH = 220
_FOCUS_NAMES = {
  CAPTURE: 'player',
  SEEK_SLIDER: 'seek',
  PLAY_PAUSE: 'play_pause',
  PREVIOUS_EPISODE: 'previous_episode',
  EPISODES: 'episodes',
  NEXT_EPISODE: 'next_episode',
  AUDIO: 'audio',
  SUBTITLES: 'subtitles',
  CHAPTERS: 'chapters',
  MORE: 'more',
  INFO: 'playback_information',
  PANEL_LIST: 'panel_list',
  PANEL_BACK: 'panel_back',
  UP_NEXT_START: 'up_next_start',
  UP_NEXT_HIDE: 'up_next_hide',
  SEGMENT_SKIP: 'segment_skip',
}


def logical_focus_name(control_id: int) -> str:
  """Return the stable development name for a player control."""
  return _FOCUS_NAMES.get(control_id, f'control:{control_id}' if control_id else 'unknown')


class PlayerWindow(xbmcgui.WindowXMLDialog):
  commands: queue.Queue[tuple[str, int, int, float]]
  command_lock: Any
  accepting_input: bool
  pending_input_commands: int
  player_surface: str
  exit_requested: bool

  def _queue_command(
    self,
    command: tuple[str, int, int, float],
    *,
    input_command: bool,
    exit_action: bool = False,
  ) -> None:
    with self.command_lock:
      if not self.accepting_input:
        return
      if exit_action and self.pending_input_commands == 0 and self.player_surface in _EXIT_SURFACES:
        self.exit_requested = True
      if input_command:
        self.pending_input_commands += 1
      self.commands.put(command)

  def finish_command(self, kind: str) -> None:
    if kind not in {'action', 'click'}:
      return
    with self.command_lock:
      self.pending_input_commands -= 1

  def consume_exit_request(self) -> bool:
    with self.command_lock:
      requested = self.exit_requested
      self.exit_requested = False
      return requested

  def onInit(self) -> None:  # noqa: N802 - Kodi callback name.
    try:
      dialog_id = xbmcgui.getCurrentWindowDialogId()
    except (AttributeError, RuntimeError):
      dialog_id = 0
    self._queue_command(('ready', dialog_id, 0, 0.0), input_command=False)

  def onClick(self, control_id: int) -> None:  # noqa: N802 - Kodi callback name.
    selected = -1
    if control_id == PANEL_LIST:
      try:
        selected = cast('xbmcgui.ControlList', self.getControl(PANEL_LIST)).getSelectedPosition()
      except RuntimeError:
        selected = -1
    self._queue_command(('click', control_id, selected, 0.0), input_command=True)

  def onAction(self, action: xbmcgui.Action) -> None:  # noqa: N802 - Kodi callback name.
    try:
      focus = self.getFocusId()
    except RuntimeError:
      focus = 0
    try:
      amount = action.getAmount1()
    except (AttributeError, RuntimeError):
      amount = 0.0
    action_id = action.getId()
    # Latch an isolated exit-surface Back early so it outranks lifecycle events.
    # If another input is queued or being processed, preserve command order:
    # that input may open an inner surface which this Back must close instead.
    self._queue_command(
      ('action', action_id, focus, amount),
      input_command=True,
      exit_action=action_id in _BACK_ACTIONS,
    )


class PlayerView:
  def __init__(self, addon_path: str, *, startup_visibility_seconds: float = 45.0) -> None:
    self.window = PlayerWindow('player.xml', addon_path, 'Default', '1080i')
    self.window.commands = queue.Queue()
    self.window.command_lock = threading.Lock()
    self.window.accepting_input = False
    self.window.pending_input_commands = 0
    self.window.player_surface = 'clean'
    with self.window.command_lock:
      self.window.exit_requested = False
    self.ready = False
    self.visible = False
    self.dialog_id = 0
    self.startup_visibility_until = 0.0
    self.startup_visibility_seconds = startup_visibility_seconds
    self.panel_values: list[Any] = []
    self.requested_focus_id = CAPTURE

  @property
  def commands(self) -> queue.Queue[tuple[str, int, int, float]]:
    return self.window.commands

  def show(self) -> None:
    if not self.visible:
      with self.window.command_lock:
        self.window.accepting_input = True
        self.window.exit_requested = False
      if not self.ready or self.dialog_id <= 0:
        self.startup_visibility_until = time.monotonic() + self.startup_visibility_seconds
      self.window.show()
      self.visible = True

  def close(self) -> None:
    with self.window.command_lock:
      self.window.accepting_input = False
      self.window.exit_requested = False
    if self.visible:
      self.window.close()
      self.visible = False
    self.ready = False
    self.dialog_id = 0
    self.startup_visibility_until = 0.0

  def consume_exit_request(self) -> bool:
    return self.window.consume_exit_request()

  def finish_command(self, kind: str) -> None:
    self.window.finish_command(kind)

  def mark_ready(self, dialog_id: int) -> None:
    self.ready = True
    self.dialog_id = max(0, dialog_id)
    if self.dialog_id > 0:
      self.startup_visibility_until = 0.0

  def playback_visible(self) -> bool:
    """Keep ownership while this dialog remains visible beneath any modal dialog."""
    if not self.visible:
      return False
    now = time.monotonic()
    has_dialog_id = self.ready and self.dialog_id > 0
    visible = self._dialog_visible() if has_dialog_id else False
    if not has_dialog_id:
      return self._startup_visibility_pending(now)
    return visible

  def _dialog_visible(self) -> bool:
    try:
      return bool(xbmc.getCondVisibility(f'Window.IsVisible({self.dialog_id})'))
    except (AttributeError, RuntimeError):
      return False

  def _startup_visibility_pending(self, now: float) -> bool:
    # onInit can arrive after playback starts, but that startup gap must stay
    # bounded so an absent/invalid callback cannot retain ownership forever.
    if now <= self.startup_visibility_until:
      return True
    self.startup_visibility_until = 0.0
    return False

  def property(self, name: str, value: str) -> None:
    self.window.setProperty('jelq.' + name, value)

  def clear_property(self, name: str) -> None:
    self.window.clearProperty('jelq.' + name)

  def surface(self, value: str) -> None:
    with self.window.command_lock:
      self.window.player_surface = value
    self.property('surface', value)
    if not self.ready:
      return
    focus = {
      'clean': CAPTURE,
      'sosd': CAPTURE,
      'main': PLAY_PAUSE,
      'prompt': SEGMENT_SKIP,
      'upnext': UP_NEXT_START,
    }.get(value)
    if focus is not None:
      self.focus(focus)

  def focus(self, control_id: int) -> None:
    self.requested_focus_id = control_id
    with suppress(RuntimeError):
      self.window.setFocusId(control_id)

  def logical_focus(self) -> str:
    """Return the current actual focus when Kodi exposes it, else the requested focus."""
    control_id = self.requested_focus_id
    if self.ready:
      with suppress(RuntimeError):
        control_id = self.window.getFocusId()
        self.requested_focus_id = control_id
    return logical_focus_name(control_id)

  def context(  # noqa: PLR0913 - explicit player presentation context.
    self,
    *,
    title: str,
    subtitle: str,
    year: int,
    duration_ticks: int,
    status: PlaybackBadge | None,
    chapters: Sequence[Any],
    segments: Sequence[Segment],
  ) -> None:
    self.property('title', title)
    self.property('subtitle', subtitle)
    self.property('year', str(year) if year else '')
    self.property('duration', format_time(duration_ticks))
    if status:
      self.property('method', status.label)
      self.property('method.tone', status.tone)
    else:
      self.clear_property('method')
      self.clear_property('method.tone')
    ticks = [max(0, integer(getattr(chapter, 'start_ticks', 0))) for chapter in chapters]
    self.property('chapters', chapter_ranges(ticks, duration_ticks))
    first, second = segment_rows(segments)
    self.property(
      'segments.1',
      range_string(((value.start_ticks, value.end_ticks) for value in first), duration_ticks),
    )
    self.property(
      'segments.2',
      range_string(((value.start_ticks, value.end_ticks) for value in second), duration_ticks),
    )

  def timeline(self, position_ticks: int, duration_ticks: int, target_ticks: int | None) -> None:
    remaining = max(0, duration_ticks - position_ticks)
    self.property('elapsed', format_time(position_ticks))
    self.property('remaining', format_time(remaining, signed_remaining=True))
    selected = position_ticks if target_ticks is None else target_ticks
    self.property('seek.pending', 'true' if target_ticks is not None else 'false')
    self.property('seek.target', format_time(selected))
    seek_percent = percentage(selected, duration_ticks)
    self.property('seek.percent', f'{seek_percent:.4f}')
    if target_ticks is not None:
      self._position_seek_feedback(seek_percent)

  def _position_seek_feedback(self, seek_percent: float) -> None:
    if not self.ready:
      return
    target = _SEEK_RAIL_LEFT + round(_SEEK_RAIL_WIDTH * seek_percent / 100)
    self._set_control_position(SEEK_HEAD, target - 3, _SEEK_HEAD_TOP)
    preview_left = min(
      max(_SEEK_RAIL_LEFT, target - _SEEK_PREVIEW_WIDTH // 2),
      _SEEK_RAIL_LEFT + _SEEK_RAIL_WIDTH - _SEEK_PREVIEW_WIDTH,
    )
    time_left = min(
      max(_SEEK_RAIL_LEFT, target - _SEEK_TIME_WIDTH // 2),
      _SEEK_RAIL_LEFT + _SEEK_RAIL_WIDTH - _SEEK_TIME_WIDTH,
    )
    self._set_control_position(SEEK_PREVIEW_BUBBLE, preview_left, _SEEK_PREVIEW_TOP)
    self._set_control_position(SEEK_TIME_BUBBLE, time_left, _SEEK_TIME_TOP)

  def _set_control_position(self, control_id: int, left: int, top: int) -> None:
    with suppress(AttributeError, RuntimeError):
      self.window.getControl(control_id).setPosition(left, top)

  def seeking_context(self, chapter_name: str, segment_names: Iterable[str]) -> None:
    self.property('seek.chapter', chapter_name)
    self.property('seek.segments', ' · '.join(segment_names))

  def seek_preview(self, image_url: str, label: str = '') -> None:
    """Show an authenticated chapter-image fallback for the pending seek target."""
    if image_url:
      self.property('seek.preview', image_url)
      self.property('seek.preview.label', label)
    else:
      self.clear_property('seek.preview')
      self.clear_property('seek.preview.label')

  def playing(self, paused: bool) -> None:  # noqa: FBT001 - small view adapter API.
    self.property('transport', 'Play' if paused else 'Pause')

  def panel(  # noqa: PLR0913 - explicit presentation data for heterogeneous rows.
    self,
    title: str,
    values: Sequence[Any],
    labels: Sequence[str],
    *,
    selected: int = 0,
    details: Sequence[str] = (),
    thumbnails: Sequence[str] = (),
  ) -> None:
    self.panel_values = list(values)
    self.property('panel.title', title)
    control = cast('xbmcgui.ControlList', self.window.getControl(PANEL_LIST))
    control.reset()
    for index, (value, label) in enumerate(zip(values, labels)):
      entry = xbmcgui.ListItem(label=label)
      if isinstance(value, StreamChoice):
        badges = (('Active',) if value.selected else ()) + value.badges
        entry.setLabel2(' · '.join(badges))
        entry.setProperty('selected', 'true' if value.selected else 'false')
      elif index < len(details) and details[index]:
        entry.setLabel2(details[index])
      if index < len(thumbnails) and thumbnails[index]:
        entry.setArt({'thumb': thumbnails[index]})
      control.addItem(entry)
    if values:
      with suppress(AttributeError, RuntimeError):
        control.selectItem(min(max(0, selected), len(values) - 1))
    self.surface('panel')
    self.focus(PANEL_LIST if values else PANEL_BACK)

  def selected_panel_value(self, index: int) -> Any | None:
    return self.panel_values[index] if 0 <= index < len(self.panel_values) else None

  def nerd_stats(self, value: str) -> None:
    self.property('panel.title', 'Playback information')
    self.property('panel.stats', value)
    self.surface('stats')
    self.focus(PANEL_BACK)

  def prompt(self, label: str, start_ticks: int, end_ticks: int) -> None:
    self.property('prompt.label', label)
    self.property(
      'prompt.range',
      format_time(start_ticks) + '–' + format_time(end_ticks),  # noqa: RUF001
    )
    self.surface('prompt')

  def up_next(self, title: str, context: str, countdown: int | None) -> None:
    self.property('upnext.title', title)
    self.property('upnext.context', context)
    self.property(
      'upnext.countdown',
      f'Starting in {countdown} seconds' if countdown is not None else '',
    )
    self.surface('upnext')

  def hide_conditional(
    self,
    control: str,
    hidden: bool,  # noqa: FBT001 - small view adapter API.
  ) -> None:
    self.property('hide.' + control, 'true' if hidden else 'false')
