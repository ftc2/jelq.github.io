"""Small, non-sensitive state contract for external development tools."""

from __future__ import annotations

from typing import Any

CONTRACT_VERSION = '1'
_PREFIX = 'jelq.dev.'
_PLAYER_FIELDS = ('player.phase', 'player.surface', 'player.focus', 'player.pending_seek')
_ALL_FIELDS = ('contract', 'app', *_PLAYER_FIELDS)


class DevelopmentState:
  """Publish stable state labels on Kodi's Home window without redundant writes."""

  def __init__(self, home_window: Any) -> None:
    self.home_window = home_window
    self.values: dict[str, str] = {}

  def start_application(self) -> None:
    """Advertise the contract while jelq owns its application window."""
    for field in _PLAYER_FIELDS:
      self._clear(field, force=True)
    self._set('contract', CONTRACT_VERSION)
    self._set('app', 'active')

  def publish_player(
    self,
    *,
    phase: str,
    surface: str,
    focus: str,
    pending_seek: bool,
  ) -> None:
    """Publish the current logical player state without media or account data."""
    self._set('player.phase', phase)
    self._set('player.surface', surface)
    self._set('player.focus', focus)
    self._set('player.pending_seek', 'true' if pending_seek else 'false')

  def clear_player(self) -> None:
    """Clear player-only state while leaving the application contract active."""
    for field in _PLAYER_FIELDS:
      self._clear(field)

  def clear(self) -> None:
    """Clear every property owned by the development-state contract."""
    for field in reversed(_ALL_FIELDS):
      self._clear(field, force=True)

  def _set(self, field: str, value: str) -> None:
    if self.values.get(field) == value:
      return
    self.home_window.setProperty(_PREFIX + field, value)
    self.values[field] = value

  def _clear(self, field: str, *, force: bool = False) -> None:
    if not force and field not in self.values:
      return
    self.home_window.clearProperty(_PREFIX + field)
    self.values.pop(field, None)
