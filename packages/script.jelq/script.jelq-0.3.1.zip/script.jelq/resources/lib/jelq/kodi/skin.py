from __future__ import annotations

import json
import time
from dataclasses import dataclass
from typing import Callable

import xbmc
import xbmcaddon
import xbmcgui

from jelq.kodi.log import event

HOME_WINDOW_ID = 10000
SKIN_CONFIRMATION_DIALOG_ID = 10100
SKIN_ACCEPTED_WINDOW_ID = 12999
POLL_SECONDS = 0.05
SETTLE_SECONDS = 0.1
CONFIRMATION_TIMEOUT_SECONDS = 10.5
HOME_TIMEOUT_SECONDS = 2.0
SKIN_TIMEOUT_SECONDS = 20.0
ACTIVATION_PROPERTY = 'jelq.skin.activating'


def _always() -> bool:
  return True


@dataclass(frozen=True)
class CompanionSkin:
  identifier: str
  minimum_version: str
  applicable: Callable[[], bool] = _always


# Order is preference order. Future device variants belong here with an applicability predicate.
COMPATIBLE_SKINS = (CompanionSkin('skin.jelq', '0.3.1'),)


class SkinChangeMonitor(xbmc.Monitor):
  def __init__(self) -> None:
    super().__init__()
    self.unloading = False
    self.settled = False
    self.failed = False
    self.reloads = 0

  def onNotification(self, sender: str, method: str, _data: str) -> None:  # noqa: N802
    if sender != 'xbmc':
      return
    if method == 'GUI.OnSkinUnloading':
      self.reloads += 1
      self.unloading = True
      self.settled = False
      self.failed = False
    elif method in {'GUI.OnSkinLoaded', 'GUI.OnSkinLoadFailed'} and self.unloading:
      self.settled = True
      self.failed = method == 'GUI.OnSkinLoadFailed'


class SkinReloadMonitor(xbmc.Monitor):
  def __init__(self, unloading: Callable[[], None], settled: Callable[[], None]) -> None:
    super().__init__()
    self._unloading = unloading
    self._settled = settled
    self._skin_reloading = False

  def onNotification(self, sender: str, method: str, _data: str) -> None:  # noqa: N802
    if sender != 'xbmc':
      return
    if method == 'GUI.OnSkinUnloading':
      self._skin_reloading = True
      self._unloading()
    elif method in {'GUI.OnSkinLoaded', 'GUI.OnSkinLoadFailed'} and self._skin_reloading:
      self._skin_reloading = False
      self._settled()


def activate_companion_skin(
  home: xbmcgui.Window,
  *,
  home_timeout: float = HOME_TIMEOUT_SECONDS,
  skin_timeout: float = SKIN_TIMEOUT_SECONDS,
) -> bool:
  active = compatible_active_skin()
  if active is not None:
    return True

  target = preferred_installed_skin()
  if target is None:
    xbmcgui.Dialog().ok(
      'jelq companion skin unavailable',
      'Install or update the jelq skin from the jelq repository, then launch jelq again.',
    )
    return False

  if home.getProperty(ACTIVATION_PROPERTY):
    xbmcgui.Dialog().notification('jelq', 'jelq is already activating its companion skin.')
    return False

  return _activate_installed_skin(home, target, home_timeout, skin_timeout)


def _activate_installed_skin(
  home: xbmcgui.Window,
  target: CompanionSkin,
  home_timeout: float,
  skin_timeout: float,
) -> bool:
  monitor = SkinChangeMonitor()
  home.setProperty(ACTIVATION_PROPERTY, target.identifier)
  try:
    xbmc.executebuiltin('ActivateWindow(Home)')
    if not _wait_for_home(monitor, home_timeout):
      xbmcgui.Dialog().ok(
        'jelq could not switch skins',
        'Close open Kodi dialogs, return to Home, and launch jelq again.',
      )
      return False
    if not _request_skin(target.identifier):
      xbmcgui.Dialog().ok(
        'jelq could not switch skins',
        'Select a compatible jelq skin in Settings > Interface > Skin, then launch jelq again.',
      )
      return False
    if not _wait_for_skin_change(monitor, target.identifier, skin_timeout):
      return False
    return compatible_active_skin() is not None
  finally:
    home.clearProperty(ACTIVATION_PROPERTY)


def compatible_active_skin() -> CompanionSkin | None:
  active_identifier = xbmc.getSkinDir()
  return next(
    (skin for skin in _installed_compatible_skins() if skin.identifier == active_identifier),
    None,
  )


def preferred_installed_skin() -> CompanionSkin | None:
  return next(iter(_installed_compatible_skins()), None)


def _installed_compatible_skins() -> tuple[CompanionSkin, ...]:
  compatible = []
  for skin in COMPATIBLE_SKINS:
    if not skin.applicable():
      continue
    try:
      version = xbmcaddon.Addon(skin.identifier).getAddonInfo('version')
    except RuntimeError:
      continue
    if _version_at_least(version, skin.minimum_version):
      compatible.append(skin)
  return tuple(compatible)


def _request_skin(identifier: str) -> bool:
  request = {
    'jsonrpc': '2.0',
    'id': 1,
    'method': 'Settings.SetSettingValue',
    'params': {'setting': 'lookandfeel.skin', 'value': identifier},
  }
  try:
    response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
  except (RuntimeError, TypeError, ValueError):
    event('Kodi rejected the companion-skin activation request.', error=True)
    return False
  if response.get('result') is not True:
    event('Kodi did not accept the companion-skin activation request.', error=True)
    return False
  return True


def _wait_for_home(monitor: SkinChangeMonitor, timeout: float) -> bool:
  deadline = time.monotonic() + timeout
  while time.monotonic() <= deadline and not monitor.abortRequested():
    if xbmcgui.getCurrentWindowId() == HOME_WINDOW_ID:
      return True
    monitor.waitForAbort(POLL_SECONDS)
  return False


def _wait_for_skin_change(
  monitor: SkinChangeMonitor,
  target_identifier: str,
  timeout: float,
) -> bool:
  deadline = time.monotonic() + timeout
  confirmation_seen = False
  target_seen_at: float | None = None
  while time.monotonic() <= deadline and not monitor.abortRequested():
    if xbmc.getSkinDir() == target_identifier and target_seen_at is None:
      target_seen_at = time.monotonic()
    dialog_open = _skin_confirmation_open()
    if monitor.settled and dialog_open:
      confirmation_seen = True
    elif (
      monitor.settled
      and (
        confirmation_seen
        or monitor.failed
        or monitor.reloads > 1
        or xbmcgui.getCurrentWindowId() == SKIN_ACCEPTED_WINDOW_ID
      )
    ) or (
      target_seen_at is not None
      and time.monotonic() - target_seen_at >= CONFIRMATION_TIMEOUT_SECONDS
    ):
      if monitor.waitForAbort(SETTLE_SECONDS):
        return False
      if not _skin_confirmation_open():
        return True
    monitor.waitForAbort(POLL_SECONDS)
  return False


def _skin_confirmation_open() -> bool:
  return (
    xbmc.getCondVisibility('Window.IsActive(yesnodialog)')
    or (xbmcgui.getCurrentWindowId() == SKIN_CONFIRMATION_DIALOG_ID)
    or (xbmcgui.getCurrentWindowDialogId() == SKIN_CONFIRMATION_DIALOG_ID)
  )


def _version_at_least(installed: str, required: str) -> bool:
  try:
    installed_parts = tuple(int(value) for value in installed.split('.'))
    required_parts = tuple(int(value) for value in required.split('.'))
  except ValueError:
    return False
  width = max(len(installed_parts), len(required_parts))
  return installed_parts + (0,) * (width - len(installed_parts)) >= required_parts + (0,) * (
    width - len(required_parts)
  )
