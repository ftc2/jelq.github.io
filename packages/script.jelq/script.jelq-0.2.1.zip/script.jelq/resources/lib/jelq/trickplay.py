"""Pure selection and sprite-cropping helpers for Jellyfin trickplay previews."""

from __future__ import annotations

import json
from dataclasses import dataclass
from hashlib import sha256
from io import BytesIO
from typing import Any

from PIL import Image, UnidentifiedImageError

from jelq.client import ApiError, JellyfinClient
from jelq.models import TICKS_PER_SECOND, MediaItem, integer

MILLISECONDS_PER_SECOND = 1000
TICKS_PER_MILLISECOND = TICKS_PER_SECOND // MILLISECONDS_PER_SECOND
# A 10-by-10 sheet of 640-by-360 previews is about 23 million pixels. These
# bounds leave headroom for that case without accepting hostile image geometry.
MAX_TRICKPLAY_SPRITE_DIMENSION = 8192
MAX_TRICKPLAY_SPRITE_PIXELS = 32 * 1024 * 1024

DECODE_ERROR = 'The trickplay preview could not be decoded.'
SPRITE_TOO_LARGE_ERROR = 'The trickplay sprite is too large to decode safely.'


@dataclass(frozen=True)
class TrickplayFrame:
  """One thumbnail cell inside a Jellyfin trickplay sprite sheet."""

  url: str
  key: str
  sheet_key: str
  width: int
  height: int
  column: int
  row: int


def _positive(value: object) -> int:
  parsed = integer(value)
  return max(0, parsed)


def _source_manifest(item: MediaItem, media_source_id: str) -> dict[str, Any] | None:
  exact = item.trickplay.get(media_source_id)
  if isinstance(exact, dict):
    return exact
  manifests = [value for value in item.trickplay.values() if isinstance(value, dict)]
  return manifests[0] if len(manifests) == 1 else None


def select_trickplay_frame(
  client: JellyfinClient,
  item: MediaItem,
  media_source_id: str,
  target_ticks: int,
) -> TrickplayFrame | None:
  """Select the bounded sprite cell nearest to a seek target."""
  manifest = _source_manifest(item, media_source_id)
  if manifest is None:
    return None
  candidates = []
  for width_key, raw in manifest.items():
    if not isinstance(raw, dict):
      continue
    width = _positive(raw.get('Width')) or _positive(width_key)
    height = _positive(raw.get('Height'))
    columns = _positive(raw.get('TileWidth'))
    rows = _positive(raw.get('TileHeight'))
    interval = _positive(raw.get('Interval'))
    count = _positive(raw.get('ThumbnailCount'))
    if width and height and columns and rows and interval and count:
      candidates.append((width, height, columns, rows, interval, count))
  if not candidates:
    return None
  width, height, columns, rows, interval, count = min(candidates)
  target_ms = max(0, integer(target_ticks)) // TICKS_PER_MILLISECOND
  thumbnail = min(count - 1, target_ms // interval)
  capacity = columns * rows
  tile_index, tile_offset = divmod(thumbnail, capacity)
  row, column = divmod(tile_offset, columns)
  url = client.trickplay_tile_url(item.id, width, tile_index, media_source_id)
  sheet_identity = json.dumps(
    (
      client.base_url,
      client.user_id,
      item.id,
      media_source_id,
      width,
      height,
      tile_index,
    ),
    ensure_ascii=False,
    separators=(',', ':'),
  )
  sheet_key = sha256(sheet_identity.encode('utf-8')).hexdigest()
  identity = json.dumps(
    (
      sheet_key,
      row,
      column,
    ),
    ensure_ascii=False,
    separators=(',', ':'),
  )
  return TrickplayFrame(
    url=url,
    key=sha256(identity.encode('utf-8')).hexdigest(),
    sheet_key=sheet_key,
    width=width,
    height=height,
    column=column,
    row=row,
  )


def crop_trickplay_frame(content: bytes, frame: TrickplayFrame) -> bytes:
  """Decode a JPEG sprite and return the selected cell as a compact JPEG."""
  try:
    image = Image.open(BytesIO(content))
  except (Image.DecompressionBombError, OSError, UnidentifiedImageError, ValueError):
    raise ApiError(DECODE_ERROR) from None
  width, height = image.size
  if (
    width > MAX_TRICKPLAY_SPRITE_DIMENSION
    or height > MAX_TRICKPLAY_SPRITE_DIMENSION
    or width * height > MAX_TRICKPLAY_SPRITE_PIXELS
  ):
    image.close()
    raise ApiError(SPRITE_TOO_LARGE_ERROR)
  try:
    image.load()
  except (Image.DecompressionBombError, OSError, UnidentifiedImageError, ValueError):
    image.close()
    raise ApiError(DECODE_ERROR) from None
  left = frame.column * frame.width
  top = frame.row * frame.height
  right = left + frame.width
  bottom = top + frame.height
  if right > image.width or bottom > image.height:
    image.close()
    raise ApiError('The trickplay sprite does not match its server metadata.')
  try:
    preview = image.crop((left, top, right, bottom)).convert('RGB')
    output = BytesIO()
    preview.save(output, format='JPEG', quality=88)
  except (Image.DecompressionBombError, OSError, ValueError):
    raise ApiError(DECODE_ERROR) from None
  finally:
    image.close()
  return output.getvalue()
