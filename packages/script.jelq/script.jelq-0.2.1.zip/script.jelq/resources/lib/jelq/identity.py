"""Stable client identity shared by Jellyfin requests and release metadata tests."""

VERSION = '0.2.1'
USER_AGENT = 'jelq/' + VERSION
