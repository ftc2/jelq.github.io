from __future__ import annotations

import json
import queue
import threading
import time
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Callable
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

import xbmc
import xbmcgui

from jelq.client import ApiError, AuthError, JellyfinClient
from jelq.episode_browser import EpisodeBrowser, EpisodeChoice, SeasonGroup
from jelq.kodi.log import event
from jelq.kodi.player_window import (
  AUDIO,
  CAPTURE,
  CHAPTERS,
  EPISODES,
  INFO,
  MORE,
  NEXT_EPISODE,
  PANEL_BACK,
  PANEL_LIST,
  PLAY_PAUSE,
  PREVIOUS_EPISODE,
  SEEK_SLIDER,
  SEGMENT_SKIP,
  SUBTITLES,
  UP_NEXT_HIDE,
  UP_NEXT_START,
  PlayerView,
)
from jelq.kodi.preview import (
  TrickplayPreviewCache,
  load_trickplay_preview,
  remove_trickplay_previews,
)
from jelq.kodi.urls import authenticated_url
from jelq.models import TICKS_PER_SECOND, MediaItem, Segment, integer, text
from jelq.player_preferences import (
  AccountScope,
  MediaSegmentPolicies,
  NetworkContext,
  PlayerPreferences,
  SegmentPolicy,
)
from jelq.player_state import (
  PlaybackIntent,
  PlaybackPhase,
  PlayerEventKind,
  PlayerState,
  PlayerSurface,
  highest_priority_event,
)
from jelq.player_ui import (
  StreamChoice,
  audio_choices,
  chapter_preview,
  diagnostic_rows,
  format_time,
  matching_stream_index,
  playback_badge,
  segments_at,
  subtitle_choices,
)
from jelq.trickplay import select_trickplay_frame

REPORT_INTERVAL = 10
REPORT_TIMEOUT = 3.0
START_TIMEOUT = 45
STOP_CALLBACK_TIMEOUT = 2.0
END_TOLERANCE_TICKS = 2 * TICKS_PER_SECOND
TERMINAL_SEGMENT_END_GRACE_SECONDS = 10.0
SEEK_STEP_TICKS = 5 * TICKS_PER_SECOND
SEEK_COMMIT_DELAY = 0.8
OSD_HIDE_DELAY = 5.0
PROMPT_HIDE_DELAY = 6.0
UP_NEXT_WINDOW_TICKS = 60 * TICKS_PER_SECOND
UP_NEXT_MINIMUM_PROMPT_TICKS = 8 * TICKS_PER_SECOND
VIEW_UPDATE_INTERVAL = 0.2
STREAM_STATE_STABILIZATION_SECONDS = 1.0
BACK_ACTIONS = {9, 10, 92}
LEFT_ACTIONS = {1}
RIGHT_ACTIONS = {2}
UP_ACTIONS = {3}
DOWN_ACTIONS = {4}
SELECT_ACTIONS = {7}
# A Python WindowXMLDialog callback observes actions but cannot mark an otherwise
# unhandled action consumed. Kodi therefore continues these through its native
# player after onAction returns. Never replay them here: doing so double-pauses,
# double-seeks, or applies track/delay changes twice. Player callbacks reconcile
# lifecycle state after Kodi performs the action.
NATIVE_PLAYBACK_ACTIONS = {
  11,  # Show information
  12,  # Pause / PlayPause
  13,  # Stop
  14,  # Next item
  15,  # Previous item
  16,  # Legacy forward (not normally emitted by Kodi 21 keymaps)
  17,  # Legacy rewind (not normally emitted by Kodi 21 keymaps)
  20,  # Step forward
  21,  # Step back
  22,  # Big step forward
  23,  # Big step back
  25,  # Toggle subtitles
  26,  # Next subtitle
  27,  # Codec information
  52,  # Subtitle delay minus
  53,  # Subtitle delay plus
  56,  # Next audio language
  69,  # Player process information
  76,  # Small step back
  77,  # Player forward
  78,  # Player rewind
  79,  # Player play
  97,  # Chapter or big step forward
  98,  # Chapter or big step back
  99,  # Cycle subtitle
  113,  # Analog fast-forward
  114,  # Analog rewind
  124,  # Analog seek forward
  125,  # Analog seek back
  162,  # Subtitle delay dialog
  229,  # Player PlayPause
  262,  # Player debug
}
TOGGLE_OSD_ACTIONS = {24}
SHOW_OSD_ACTIONS = {163, 243}

_EVENT_KINDS = {
  'started': PlayerEventKind.PLAYBACK_STATE,
  'paused': PlayerEventKind.PLAYBACK_STATE,
  'resumed': PlayerEventKind.PLAYBACK_STATE,
  'seek': PlayerEventKind.POSITION_UPDATE,
  'streams': PlayerEventKind.POSITION_UPDATE,
  'stopped': PlayerEventKind.PLAYBACK_STATE,
  'ended': PlayerEventKind.NATURAL_COMPLETION,
  'error': PlayerEventKind.FAILURE,
}

_UI_SURFACES = {
  PlayerSurface.CLEAN: 'clean',
  PlayerSurface.SOSD: 'sosd',
  PlayerSurface.MAIN_OSD: 'main',
  PlayerSurface.NERD_STATS: 'stats',
  PlayerSurface.SEGMENT_PROMPT: 'prompt',
  PlayerSurface.UP_NEXT: 'upnext',
}

_PANEL_SURFACES = {
  'audio': PlayerSurface.AUDIO,
  'subtitles': PlayerSurface.SUBTITLES,
  'chapters': PlayerSurface.CHAPTERS,
  'episode-seasons': PlayerSurface.EPISODES,
  'episode-items': PlayerSurface.EPISODES,
  'more': PlayerSurface.PLAYER_MENU,
}


def media_address(url: str) -> str:
  if '|' in url:
    raise ApiError('The server returned an invalid media address.')
  return url


def current_audio_index() -> int:
  """Read Kodi's selected track before asking it to restart the audio stream."""
  request = {
    'jsonrpc': '2.0',
    'id': 1,
    'method': 'Player.GetProperties',
    'params': {'playerid': 1, 'properties': ['currentaudiostream']},
  }
  try:
    response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
  except (AttributeError, TypeError, ValueError, RuntimeError):
    return -1
  result = response.get('result') if isinstance(response, dict) else None
  current = result.get('currentaudiostream') if isinstance(result, dict) else None
  return integer(current.get('index'), -1) if isinstance(current, dict) else -1


def _current_subtitle_state() -> tuple[int, bool] | None:
  request = {
    'jsonrpc': '2.0',
    'id': 1,
    'method': 'Player.GetProperties',
    'params': {
      'playerid': 1,
      'properties': ['currentsubtitle', 'subtitleenabled'],
    },
  }
  try:
    response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
  except (AttributeError, TypeError, ValueError, RuntimeError):
    return None
  result = response.get('result') if isinstance(response, dict) else None
  if not isinstance(result, dict) or not isinstance(result.get('subtitleenabled'), bool):
    return None
  current = result.get('currentsubtitle')
  index = integer(current.get('index'), -1) if isinstance(current, dict) else -1
  return index, result.get('subtitleenabled') is True


def current_subtitle_state() -> tuple[int, bool]:
  state = _current_subtitle_state()
  return state if state is not None else (-1, False)


def format_ticks(ticks: int) -> str:
  return format_time(max(0, ticks))


def format_finish_time(value: datetime) -> str:
  """Format a local finish time without platform-specific strftime directives."""
  return value.strftime('%I:%M %p').lstrip('0')


def _segment_key(segment: Segment) -> tuple[str, int, int]:
  return segment.type, segment.start_ticks, segment.end_ticks


@dataclass
class PreparedPlayback:
  client: JellyfinClient = field(repr=False)
  item: MediaItem
  source: dict[str, Any] = field(repr=False)
  session_id: str
  path: str = field(repr=False)
  method: str
  start_ticks: int
  segments: tuple[Segment, ...]
  playback_info: dict[str, Any] = field(default_factory=dict, repr=False)
  episode_sequence: tuple[MediaItem, ...] = ()
  autoplay_next: bool = True
  subtitles: list[str] = field(default_factory=list, repr=False)
  kodi_subtitle_server_indices: tuple[int, ...] = ()
  subtitle_delivery_method: str = ''
  timeline_offset_ticks: int = 0

  @property
  def duration_ticks(self) -> int:
    return max(0, integer(self.source.get('RunTimeTicks'), self.item.runtime_ticks))

  @property
  def sequence_index(self) -> int:
    return next(
      (index for index, value in enumerate(self.episode_sequence) if value.id == self.item.id),
      -1,
    )

  @property
  def previous_episode(self) -> MediaItem | None:
    index = self.sequence_index
    return self.episode_sequence[index - 1] if index > 0 else None

  @property
  def next_episode(self) -> MediaItem | None:
    index = self.sequence_index
    return self.episode_sequence[index + 1] if 0 <= index < len(self.episode_sequence) - 1 else None


def select_source(sources: list[Any]) -> tuple[dict[str, Any], str]:
  valid = [source for source in sources if isinstance(source, dict) and text(source.get('Id'))]
  for method, supported, address in (
    ('DirectPlay', 'SupportsDirectPlay', ''),
    ('DirectStream', 'SupportsDirectStream', 'DirectStreamUrl'),
    ('Transcode', '', 'TranscodingUrl'),
  ):
    for source in valid:
      if (not supported or source.get(supported) is True) and (
        not address or text(source.get(address))
      ):
        return source, method
  raise ApiError('The server could not negotiate a playable stream for Kodi.')


def playback_timeline(path: str, method: str) -> tuple[str, int]:
  """HLS exposes the full title timeline; only progressive encodes use an offset."""
  parts = urlsplit(path)
  query = parse_qsl(parts.query, keep_blank_values=True)
  if parts.path.lower().endswith('.m3u8'):
    # Jellyfin's dynamic HLS variant lists the full runtime. Kodi seeks to its
    # matching segment; StartTimeTicks must not propagate to segment requests.
    query = [(key, value) for key, value in query if key.lower() != 'starttimeticks']
    return urlunsplit(parts._replace(query=urlencode(query))), 0
  offset = next((integer(value) for key, value in query if key.lower() == 'starttimeticks'), 0)
  return path, max(0, offset) if method == 'Transcode' else 0


def media_streams(source: dict[str, Any], kind: str) -> list[dict[str, Any]]:
  streams = source.get('MediaStreams')
  if not isinstance(streams, list):
    return []
  return [stream for stream in streams if isinstance(stream, dict) and stream.get('Type') == kind]


def subtitle_tracks(source: dict[str, Any]) -> list[dict[str, Any]]:
  """Kodi loads ListItem's external subtitles before opening the embedded streams."""
  tracks = media_streams(source, 'Subtitle')
  internal = [stream for stream in tracks if not stream.get('IsExternal')]
  external = [
    stream for stream in tracks if stream.get('IsExternal') and text(stream.get('DeliveryUrl'))
  ]
  return external + internal


def _stream_at_kodi_index(streams: list[dict[str, Any]], kodi_index: int) -> dict[str, Any] | None:
  return streams[kodi_index] if 0 <= kodi_index < len(streams) else None


def _stream_at_server_index(
  streams: list[dict[str, Any]], server_index: int
) -> dict[str, Any] | None:
  if server_index < 0:
    return None
  return next(
    (stream for stream in streams if integer(stream.get('Index'), -1) == server_index),
    None,
  )


def _server_index_at_kodi_index(streams: list[dict[str, Any]], kodi_index: int) -> int:
  stream = _stream_at_kodi_index(streams, kodi_index)
  return integer(stream.get('Index'), -1) if stream is not None else -1


def _kodi_index_at_server_index(streams: list[dict[str, Any]], server_index: int) -> int:
  if server_index < 0:
    return -1
  return next(
    (
      kodi_index
      for kodi_index, stream in enumerate(streams)
      if integer(stream.get('Index'), -1) == server_index
    ),
    -1,
  )


def _stream_server_index(stream: dict[str, Any] | None) -> int:
  return integer(stream.get('Index'), -1) if stream is not None else -1


def _subtitle_delivery(
  client: JellyfinClient,
  source: dict[str, Any],
  method: str,
  *,
  subtitle_off: bool,
) -> tuple[list[str], tuple[int, ...], str]:
  if subtitle_off:
    return [], (), ''
  if method == 'DirectPlay':
    subtitles = []
    for stream in subtitle_tracks(source):
      if stream.get('IsExternal'):
        delivery = text(stream.get('DeliveryUrl'))
        if delivery:
          subtitles.append(media_address(client.media_url(delivery)))
    return subtitles, (), ''
  selected = _stream_at_server_index(
    media_streams(source, 'Subtitle'),
    integer(source.get('DefaultSubtitleStreamIndex'), -1),
  )
  if selected is None:
    return [], (), ''
  delivery_method = text(selected.get('DeliveryMethod')).casefold()
  if not delivery_method and selected.get('IsExternal') is True:
    delivery_method = 'external'
  server_index = integer(selected.get('Index'), -1)
  if delivery_method == 'embed':
    return [], (server_index,), delivery_method
  delivery = text(selected.get('DeliveryUrl'))
  if delivery_method != 'external' or not delivery:
    return [], (), delivery_method
  return [media_address(client.media_url(delivery))], (server_index,), delivery_method


def prepare(  # noqa: C901, PLR0913 - one explicit negotiation transaction.
  client: JellyfinClient,
  item: MediaItem,
  *,
  resume: bool,
  start_ticks: int | None = None,
  audio_index: int | None = None,
  subtitle_index: int | None = None,
  max_streaming_bitrate: int | None = None,
  preferred_audio: dict[str, Any] | None = None,
  preferred_subtitle: dict[str, Any] | None = None,
  subtitle_off: bool = False,
) -> PreparedPlayback:
  requested_ticks = item.position_ticks if resume else 0
  if start_ticks is not None:
    requested_ticks = max(0, start_ticks)
  info = client.playback_info(
    item.id,
    start_ticks=requested_ticks,
    audio_index=audio_index,
    subtitle_index=subtitle_index,
    max_streaming_bitrate=max_streaming_bitrate,
  )
  sources = info.get('MediaSources')
  if not isinstance(sources, list) or not sources:
    raise ApiError('No playable source is available for this title.')
  source, method = select_source(sources)
  carried_audio = (
    matching_stream_index(preferred_audio, media_streams(source, 'Audio'))
    if preferred_audio is not None
    else None
  )
  carried_subtitle = (
    matching_stream_index(preferred_subtitle, media_streams(source, 'Subtitle'))
    if preferred_subtitle is not None and not subtitle_off
    else -1
    if subtitle_off
    else None
  )
  requested_audio = audio_index if audio_index is not None else carried_audio
  requested_subtitle = subtitle_index if subtitle_index is not None else carried_subtitle
  if requested_audio is not None or requested_subtitle is not None:
    info = client.playback_info(
      item.id,
      start_ticks=requested_ticks,
      media_source_id=text(source.get('Id')),
      audio_index=requested_audio,
      subtitle_index=requested_subtitle,
      max_streaming_bitrate=max_streaming_bitrate,
    )
    sources = info.get('MediaSources')
    if not isinstance(sources, list) or not sources:
      raise ApiError('No playable source is available for the selected streams.')
    source, method = select_source(sources)
  source_id = text(source.get('Id'))
  if method == 'DirectPlay':
    path = client.stream_url(item.id, source_id)
  elif method == 'DirectStream':
    path = client.media_url(text(source.get('DirectStreamUrl')))
  else:
    path = client.media_url(text(source.get('TranscodingUrl')))
  path, timeline_offset = playback_timeline(path, method)
  try:
    segments = client.segments(item.id)
  except AuthError:
    raise
  except ApiError:
    segments = ()
  episode_sequence: tuple[MediaItem, ...] = ()
  autoplay_next = True
  if item.type == 'Episode' and item.series_id:
    try:
      episode_sequence = client.episode_sequence(item.series_id)
      autoplay_next = client.user_autoplay_enabled()
    except AuthError:
      raise
    except ApiError:
      # Optional series context must not prevent the selected item from playing.
      episode_sequence = (item,)
  subtitles, kodi_subtitle_server_indices, subtitle_delivery_method = _subtitle_delivery(
    client, source, method, subtitle_off=subtitle_off
  )
  return PreparedPlayback(
    client=client,
    item=item,
    source=source,
    session_id=text(info.get('PlaySessionId')),
    path=media_address(path),
    method=method,
    start_ticks=requested_ticks,
    segments=segments,
    playback_info=info,
    episode_sequence=episode_sequence,
    autoplay_next=autoplay_next,
    subtitles=subtitles,
    kodi_subtitle_server_indices=kodi_subtitle_server_indices,
    subtitle_delivery_method=subtitle_delivery_method,
    timeline_offset_ticks=timeline_offset,
  )


class KodiPlayer(xbmc.Player):
  def __init__(self, events: queue.Queue[str]) -> None:
    super().__init__()
    self.events = events
    self.seek_generation = 0
    self.last_seek_time = -1

  def onAVStarted(self) -> None:  # noqa: N802 - Kodi callback name.
    self.events.put('started')

  def onPlayBackPaused(self) -> None:  # noqa: N802 - Kodi callback name.
    self.events.put('paused')

  def onPlayBackResumed(self) -> None:  # noqa: N802 - Kodi callback name.
    self.events.put('resumed')

  def onPlayBackSeek(self, time: int, seekOffset: int) -> None:  # noqa: N802, N803, ARG002 - Kodi callback signature.
    self.last_seek_time = time
    self.seek_generation += 1
    self.events.put('seek')

  def onAVChange(self) -> None:  # noqa: N802 - Kodi callback name.
    self.events.put('streams')

  def onPlayBackStopped(self) -> None:  # noqa: N802 - Kodi callback name.
    self.events.put('stopped')

  def onPlayBackEnded(self) -> None:  # noqa: N802 - Kodi callback name.
    self.events.put('ended')

  def onPlayBackError(self) -> None:  # noqa: N802 - Kodi callback name.
    self.events.put('error')


class PlaybackController:
  def __init__(  # noqa: PLR0915 - explicit ownership of one player-session state.
    self,
    addon_path: str,
    finished: Callable[[str], None],
    preferences_changed: Callable[[], None] | None = None,
  ) -> None:
    self.events: queue.Queue[str] = queue.Queue()
    self.player = KodiPlayer(self.events)
    self.addon_path = addon_path
    self.finished = finished
    self.preferences_changed = preferences_changed or (lambda: None)
    self.preferences = PlayerPreferences()
    self.account_scope: AccountScope | None = None
    self.network_context = NetworkContext.REMOTE
    self.current: PreparedPlayback | None = None
    self._active_audio_stream: dict[str, Any] | None = None
    self._active_subtitle_stream: dict[str, Any] | None = None
    self._active_subtitle_off = True
    self._active_stream_state_pending = False
    self._active_stream_state_pending_until = 0.0
    self.report_client: JellyfinClient | None = None
    self.reporter = ThreadPoolExecutor(max_workers=1)
    self.loader = ThreadPoolExecutor(max_workers=1)
    self.preview_loader = ThreadPoolExecutor(max_workers=1)
    self.reports: list[Future[bool]] = []
    self.replacement_future: Future[PreparedPlayback] | None = None
    self.preview_future: Future[str] | None = None
    self.preview_future_key = ''
    self.preview_requested_key = ''
    self.preview_displayed_key = ''
    self.preview_cache: TrickplayPreviewCache | None = None
    self.preview_cache_scope = ''
    self.preview_paths: set[str] = set()
    self.queued_replacement: PreparedPlayback | None = None
    self.replacement_reason = ''
    self.replacement_pause_applied = False
    self.replacement_stopping = False
    self.quality_limit: int | None = None
    self.screensaver_inhibited = False
    self.shutdown = threading.Event()
    self.started = False
    self.finishing = False
    self.stop_requested = False
    self.state = PlayerState()
    self.position = 0
    self.terminal_segment_end_deadline = 0.0
    self.terminal_segment_end_seek_generation = -1
    self.last_report = 0.0
    self.requested_at = 0.0
    self.stop_requested_at = 0.0
    self.view = PlayerView(addon_path, startup_visibility_seconds=START_TIMEOUT)
    self.panel_kind = ''
    self.panel_origin_control = PLAY_PAUSE
    self.episode_browser: EpisodeBrowser | None = None
    self.selected_season_index = -1
    self.session_start_item_id = ''
    self.seek_deadline = 0.0
    self.osd_deadline = 0.0
    self.prompt_deadline = 0.0
    self.prompt_segment: Segment | None = None
    self.handled_segments: set[tuple[str, int, int]] = set()
    self.up_next_hidden = False
    self.up_next_started = False
    self.last_up_next_second = -1
    self.last_view_update = 0.0
    self.sync_failed = False

  def configure_preferences(
    self,
    preferences: PlayerPreferences,
    account_scope: AccountScope,
    network_context: NetworkContext,
  ) -> None:
    if self.active:
      raise RuntimeError('Player preferences cannot change during an active session.')
    self.preferences = preferences
    self.account_scope = account_scope
    self.network_context = network_context
    self.quality_limit = preferences.bitrate_limits.for_context(network_context)

  @property
  def paused(self) -> bool:
    return self.state.playback_intent is PlaybackIntent.PAUSED

  @property
  def pending_seek(self) -> int | None:
    pending = self.state.pending_seek
    return pending.target_ticks if pending is not None else None

  @property
  def surface(self) -> str:
    visible = self.state.visible_surface
    return _UI_SURFACES.get(visible, 'panel')

  def _clear_terminal_segment_end(self) -> None:
    self.terminal_segment_end_deadline = 0.0
    self.terminal_segment_end_seek_generation = -1

  def _set_screensaver_inhibited(self, *, inhibited: bool) -> None:
    if inhibited == self.screensaver_inhibited:
      return
    xbmc.executebuiltin(f'InhibitScreensaver({str(inhibited).lower()})')
    self.screensaver_inhibited = inhibited

  @property
  def active(self) -> bool:
    return self.current is not None and not self.finishing

  @property
  def busy(self) -> bool:
    """A title still owns this controller until its final report completes."""
    return self.current is not None

  def _media_url(self, client: JellyfinClient, address: str) -> str:
    return authenticated_url(client, address)

  def _optional_media_url(self, client: JellyfinClient, address: str) -> str:
    try:
      return self._media_url(client, address)
    except ApiError:
      return ''

  @staticmethod
  def _stop_player() -> bool:
    """Queue Kodi's stop without blocking the controller loop."""
    try:
      xbmc.executebuiltin('PlayerControl(Stop)', wait=False)
    except (AttributeError, RuntimeError):
      return False
    return True

  @property
  def active_audio_server_index(self) -> int:
    """Return the generation-safe Jellyfin index for the active audio stream."""
    return _stream_server_index(self._active_audio_stream)

  @property
  def active_subtitle_server_index(self) -> int:
    """Return the generation-safe Jellyfin index for the active subtitle stream."""
    return -1 if self._active_subtitle_off else _stream_server_index(self._active_subtitle_stream)

  @property
  def active_subtitle_off(self) -> bool:
    return self._active_subtitle_off

  @property
  def active_stream_state_pending(self) -> bool:
    return self._active_stream_state_pending

  def _seed_active_stream_state(self, prepared: PreparedPlayback) -> None:
    source = prepared.source
    audio = _stream_at_server_index(
      media_streams(source, 'Audio'), integer(source.get('DefaultAudioStreamIndex'), -1)
    )
    subtitle = _stream_at_server_index(
      media_streams(source, 'Subtitle'), integer(source.get('DefaultSubtitleStreamIndex'), -1)
    )
    self._active_audio_stream = dict(audio) if audio is not None else None
    self._active_subtitle_stream = dict(subtitle) if subtitle is not None else None
    self._active_subtitle_off = subtitle is None

  def _pending_stream_state_matches(
    self,
    audio: dict[str, Any] | None,
    subtitle: dict[str, Any] | None,
    *,
    subtitle_enabled: bool,
  ) -> bool:
    expected_audio_index = self.active_audio_server_index
    audio_matches = expected_audio_index < 0 or _stream_server_index(audio) == expected_audio_index
    if self._active_subtitle_off:
      subtitle_matches = not subtitle_enabled
    else:
      expected_subtitle_index = self.active_subtitle_server_index
      subtitle_matches = (
        subtitle_enabled
        and expected_subtitle_index >= 0
        and _stream_server_index(subtitle) == expected_subtitle_index
      )
    return audio_matches and subtitle_matches

  def _refresh_active_stream_state(self, *, confirmed: bool = False) -> None:
    current = self.current
    if current is None:
      return
    now = time.monotonic()
    pending = self._active_stream_state_pending
    if pending and not confirmed and now < self._active_stream_state_pending_until:
      # A replacement starts a new Kodi player, but Player.GetProperties can
      # briefly continue returning the released player's streams. Preserve the
      # negotiated selection during that handoff.
      return
    if current.method != 'DirectPlay' and current.subtitle_delivery_method == 'encode':
      # An encoded subtitle is burned into the video. Kodi has no subtitle
      # stream to disable or identify, so its subtitleenabled value cannot
      # supersede the server's negotiated semantic selection.
      if pending:
        self._active_stream_state_pending = False
        self._active_stream_state_pending_until = 0.0
      return
    self._refresh_selectable_stream_state(current, now=now, pending=pending)

  def _refresh_selectable_stream_state(
    self, current: PreparedPlayback, *, now: float, pending: bool
  ) -> None:
    direct_play = current.method == 'DirectPlay'
    audio = (
      _stream_at_kodi_index(media_streams(current.source, 'Audio'), current_audio_index())
      if direct_play
      else self._active_audio_stream
    )
    subtitle_state = _current_subtitle_state()
    if subtitle_state is None:
      return
    subtitle_index, subtitle_enabled = subtitle_state
    subtitle = (
      _stream_at_kodi_index(subtitle_tracks(current.source), subtitle_index)
      if direct_play and subtitle_enabled
      else self._active_subtitle_stream
      if subtitle_enabled
      else None
    )
    if (
      pending
      and now < self._active_stream_state_pending_until
      and not self._pending_stream_state_matches(audio, subtitle, subtitle_enabled=subtitle_enabled)
    ):
      # onAVChange can be delivered before the replacement player becomes the
      # authoritative JSON-RPC generation. A valid-but-stale response is not
      # confirmation. A later matching callback wins; after the short bound,
      # ordinary refresh accepts Kodi's state so native user changes are not
      # hidden indefinitely.
      return
    if pending:
      self._active_stream_state_pending = False
      self._active_stream_state_pending_until = 0.0
    if direct_play and audio is not None:
      self._active_audio_stream = dict(audio)
    if not subtitle_enabled:
      if direct_play:
        self._active_subtitle_stream = None
      self._active_subtitle_off = True
      return
    if direct_play:
      self._active_subtitle_stream = dict(subtitle) if subtitle is not None else None
    self._active_subtitle_off = False

  def _clear_active_stream_state(self) -> None:
    self._active_audio_stream = None
    self._active_subtitle_stream = None
    self._active_subtitle_off = True
    self._active_stream_state_pending = False
    self._active_stream_state_pending_until = 0.0

  def start(  # noqa: PLR0915 - reset every item-scoped field before handing off to Kodi.
    self, prepared: PreparedPlayback
  ) -> None:
    if self.busy or self.shutdown.is_set():
      raise RuntimeError('Stop the current playback before starting another title.')
    try:
      kodi_path = self._media_url(prepared.client, prepared.path)
      kodi_subtitles = [self._media_url(prepared.client, address) for address in prepared.subtitles]
    except ApiError as error:
      xbmcgui.Dialog().ok('Playback failed', str(error))
      return
    self._drain_player_commands()
    self._clear_trickplay_previews()
    # Each Kodi Player retains its own callback queue. Late callbacks from an old
    # item cannot finish a new item or send updates to a newly selected account.
    self.events = queue.Queue()
    self.player = KodiPlayer(self.events)
    self.current = prepared
    self._seed_active_stream_state(prepared)
    self._active_stream_state_pending = bool(self.session_start_item_id)
    # A replacement can take longer than the stabilization window to start.
    # Arm the bounded guard from onAVStarted, when Kodi first exposes the new
    # player generation, rather than from this earlier play request.
    self._active_stream_state_pending_until = 0.0
    client = prepared.client
    self.report_client = JellyfinClient(
      client.base_url,
      client.device_id,
      client.token,
      client.user_id,
      transport=client.transport,
      timeout=min(client.timeout, REPORT_TIMEOUT),
    )
    self.started = False
    self.finishing = False
    self.stop_requested = False
    self.stop_requested_at = 0.0
    self.state = PlayerState()
    self.sync_failed = False
    self.replacement_future = None
    self.queued_replacement = None
    self.replacement_reason = ''
    self.replacement_pause_applied = False
    self.replacement_stopping = False
    self.position = prepared.start_ticks
    self._clear_terminal_segment_end()
    self.panel_kind = ''
    self.panel_origin_control = PLAY_PAUSE
    self.episode_browser = None
    self.selected_season_index = -1
    self.preview_cache = TrickplayPreviewCache()
    self.preview_cache_scope = self.preview_cache.scope
    if not self.session_start_item_id:
      self.session_start_item_id = prepared.item.id
    self.seek_deadline = 0.0
    self.osd_deadline = 0.0
    self.prompt_deadline = 0.0
    self.prompt_segment = None
    self.handled_segments.clear()
    self.up_next_hidden = False
    self.up_next_started = False
    self.last_up_next_second = -1
    self.last_view_update = 0.0
    self.requested_at = time.monotonic()
    entry = xbmcgui.ListItem(label=prepared.item.name, path=kodi_path)
    metadata = entry.getVideoInfoTag()
    metadata.setTitle(prepared.item.name)
    metadata.setMediaType('episode' if prepared.item.type == 'Episode' else 'movie')
    metadata.setDuration(prepared.duration_ticks // TICKS_PER_SECOND)
    metadata.setPlot(prepared.item.overview)
    # Only the explicit Jellyfin subtitle URLs should precede embedded streams.
    # Kodi scans/adds ListItem subtitles before creating the media demuxer.
    entry.setProperty('no-ext-subs-scan', 'true')
    offset = max(0, prepared.start_ticks - prepared.timeline_offset_ticks)
    if offset:
      entry.setProperty('StartOffset', str(offset / TICKS_PER_SECOND))
    entry.setSubtitles(kodi_subtitles)
    xbmcgui.Window(10000).setProperty('jelq.playing', 'true')
    self._set_screensaver_inhibited(inhibited=True)
    try:
      self.player.play(kodi_path, entry, windowed=False)
    except RuntimeError:
      self._event('error')

  def poll(self) -> None:  # noqa: C901, PLR0912 - explicit turn-priority pipeline.
    # Losing the owned dialog is an EXIT event and outranks every queued Kodi
    # callback, including natural completion/autoplay in the same controller turn.
    if self.current and self.started and not self.view.playback_visible():
      self._request_exit()
    if self.current and self.view.consume_exit_request():
      self._request_exit()
    pending_events: list[str] = []
    while not self.events.empty():
      pending_events.append(self.events.get_nowait())
    while pending_events:
      selected_kind = highest_priority_event(
        self._player_event_kind(kind) for kind in pending_events
      )
      selected_index = next(
        index
        for index, kind in enumerate(pending_events)
        if self._player_event_kind(kind) is selected_kind
      )
      self._event(pending_events.pop(selected_index))

    # Apply the documented priority across controller work as well as callback
    # collisions: exit/failure and completed replacement work preempt user
    # input; user input preempts timers; timers preempt contextual prompts.
    if self.stop_requested:
      self._drain_player_commands()
      self._stop_watchdog()
      self._finish_reports()
      return
    if self._poll_replacement():
      self._drain_player_commands()
      self._finish_reports()
      return
    if self.replacement_stopping:
      self._drain_player_commands()
      self._stop_watchdog()
      self._finish_reports()
      return
    self._player_commands()
    if self.stop_requested:
      self._stop_watchdog()
      self._finish_reports()
      return
    if (
      self.replacement_future is not None
      or self.queued_replacement is not None
      or self.replacement_stopping
    ):
      self._drain_player_commands()
      self._finish_reports()
      return
    self._poll_preview()
    if not self.current:
      return
    if self.started and not self.finishing:
      if (
        self._active_stream_state_pending
        and self._active_stream_state_pending_until > 0.0
        and time.monotonic() >= self._active_stream_state_pending_until
      ):
        # A matching onAVChange normally confirms the negotiated generation.
        # If Kodi emits no usable callback, reconcile once after the short
        # guard so native player changes do not remain hidden indefinitely.
        self._refresh_active_stream_state()
      self._position()
      self._sync_buffering_phase()
      self._timers()
      self._segment_runtime()
      self._up_next()
      self._update_view()
      if time.monotonic() - self.last_report >= REPORT_INTERVAL:
        self._report('progress')
    elif not self.finishing and time.monotonic() - self.requested_at > START_TIMEOUT:
      self._stop_player()
      self._event('error')
    self._finish_reports()

  def _player_event_kind(self, kind: str) -> PlayerEventKind:
    if kind != 'stopped':
      return _EVENT_KINDS[kind]
    if self.stop_requested:
      return PlayerEventKind.EXIT
    if (
      self.replacement_stopping
      or self.replacement_future is not None
      or self.queued_replacement is not None
    ):
      return PlayerEventKind.ITEM_REPLACEMENT
    return PlayerEventKind.PLAYBACK_STATE

  def _finish_reports(self) -> None:
    for future in list(self.reports):
      if future.done():
        self.reports.remove(future)
        if not future.result():
          self.sync_failed = True
    if self.current is not None and self.finishing and not self.reports:
      item_id = self.current.item.id
      replacement = self.queued_replacement
      if replacement is None and self.replacement_future is not None:
        return
      self.current = None
      self.report_client = None
      self.finishing = False
      self.stop_requested = False
      self.stop_requested_at = 0.0
      self.queued_replacement = None
      self.replacement_stopping = False
      if replacement is None:
        self._set_screensaver_inhibited(inhibited=False)
      if self.sync_failed:
        xbmcgui.Dialog().ok(
          'Watch progress',
          'Jellyfin could not save all playback updates. Watch progress may be out of date.',
        )
      if replacement is not None:
        self.start(replacement)
      else:
        self._clear_active_stream_state()
        self._clear_trickplay_previews()
        self.session_start_item_id = ''
        self.finished(item_id)

  def _stop_watchdog(self) -> None:
    if self.finishing or not (self.stop_requested or self.replacement_stopping):
      return
    if not self.stop_requested_at:
      self.stop_requested_at = time.monotonic()
      return
    if time.monotonic() - self.stop_requested_at >= STOP_CALLBACK_TIMEOUT:
      self._event('stopped')

  def _event(  # noqa: C901, PLR0912 - lifecycle callbacks converge here.
    self, kind: str
  ) -> None:
    if self.current is None or self.finishing:
      return
    if self.stop_requested:
      if kind in {'stopped', 'ended', 'error'}:
        kind = 'stopped'
      else:
        return
    if kind == 'error' and (self.replacement_stopping or self.queued_replacement is not None):
      # Kodi may report an error instead of Stopped after the controller has
      # deliberately released the old player for an already-prepared item.
      kind = 'stopped'
    elif kind == 'error' and self.replacement_future is not None:
      # A real player failure outranks an in-flight replacement preparation.
      self.replacement_future.cancel()
      self.replacement_future = None
      self.queued_replacement = None
      self.replacement_reason = ''
      self.replacement_pause_applied = False
    if kind == 'started':
      if self.started:
        return
      self.started = True
      if self._active_stream_state_pending:
        self._active_stream_state_pending_until = (
          time.monotonic() + STREAM_STATE_STABILIZATION_SECONDS
        )
      self.state.change_phase(PlaybackPhase.PLAYING)
      self._position()
      self._defaults()
      self.view.show()
      if self.view.ready:
        # Replacements retain the same dialog, so onInit does not run again.
        self._configure_view()
      self._set_surface('clean')
      self._report('start')
    elif kind == 'streams':
      if self.started:
        self._refresh_active_stream_state(confirmed=True)
    elif kind in {'paused', 'resumed', 'seek'}:
      if not self.started:
        return
      if kind != 'seek':
        self.state.change_phase(PlaybackPhase.PAUSED if kind == 'paused' else PlaybackPhase.PLAYING)
      self._position()
      self._report('progress')
    elif kind in {'stopped', 'ended', 'error'}:
      ended_normally = kind == 'ended' and self._ended_normally()
      if (
        ended_normally
        and self.current.next_episode is not None
        and self.current.autoplay_next
        and self.replacement_future is None
        and self.queued_replacement is None
      ):
        self.up_next_started = True
        self._request_replacement(
          self.current.next_episode,
          0,
          'next episode',
          refresh_active_streams=False,
        )
      self._stopped(kind, ended_normally=ended_normally)

  def _ended_normally(self) -> bool:
    if self.current is None:
      return False
    duration = self.current.duration_ticks
    tolerance = min(END_TOLERANCE_TICKS, duration // 20)
    terminal_segment_end = (
      self.terminal_segment_end_deadline > 0.0
      and time.monotonic() <= self.terminal_segment_end_deadline
    )
    terminal_segment_superseded = False
    if (
      terminal_segment_end
      and self.player.seek_generation != self.terminal_segment_end_seek_generation
    ):
      callback_time = self.player.last_seek_time
      callback_position = callback_time * TICKS_PER_SECOND // 1000
      terminal_segment_end = callback_time >= 0 and abs(callback_position - duration) <= tolerance
      terminal_segment_superseded = not terminal_segment_end
    self._clear_terminal_segment_end()
    if (
      not self.started
      or duration <= 0
      or terminal_segment_superseded
      or (self.position < duration - tolerance and not terminal_segment_end)
    ):
      return False
    self.position = duration
    return True

  def _stopped(  # noqa: C901, PLR0912 - converges all terminal player callbacks.
    self, kind: str, *, ended_normally: bool = False
  ) -> None:
    if self.current is None:
      return
    self.finishing = True
    self.stop_requested_at = 0.0
    replacing = self.queued_replacement is not None or self.replacement_future is not None
    if self.state.phase is not PlaybackPhase.EXITING:
      if replacing:
        phase = PlaybackPhase.TRANSITIONING
      elif ended_normally:
        phase = PlaybackPhase.COMPLETING
      elif kind == 'stopped':
        phase = PlaybackPhase.EXITING
      else:
        phase = PlaybackPhase.FAILED
      self.state.change_phase(phase)
      if replacing:
        # Transitioning is non-interactive and clears the model's surface stack.
        # Keep the still-open dialog synchronized instead of showing stale main UI.
        self._present_surface()
    if not replacing:
      self.view.close()
      self._clear_trickplay_previews()
      self._set_screensaver_inhibited(inhibited=False)
    self.prompt_segment = None
    self.seek_deadline = 0.0
    if not replacing:
      xbmcgui.Window(10000).clearProperty('jelq.playing')
    failure = ''
    if kind == 'ended' and not ended_normally and not replacing:
      failure = 'Playback ended before the title finished. You can resume or retry.'
    if self.started:
      self._report('stop')
    if kind == 'error' and not replacing:
      failure = 'Kodi could not play this title. You can retry or choose another title.'
    if failure:
      xbmcgui.Dialog().ok('Playback failed', failure)

  def _position(self) -> None:
    try:
      seconds = self.player.getTime()
    except RuntimeError:
      return
    if self.current:
      seconds += self.current.timeline_offset_ticks / TICKS_PER_SECOND
    self.position = max(0, int(seconds * TICKS_PER_SECOND))

  def _sync_buffering_phase(self) -> None:
    try:
      buffering = bool(xbmc.getCondVisibility('Player.Caching'))
    except (AttributeError, RuntimeError):
      return
    phase = self.state.phase
    if buffering and phase in {PlaybackPhase.PLAYING, PlaybackPhase.PAUSED}:
      self.state.change_phase(PlaybackPhase.BUFFERING)
    elif not buffering and phase is PlaybackPhase.BUFFERING:
      target = (
        PlaybackPhase.PAUSED
        if self.state.playback_intent is PlaybackIntent.PAUSED
        else PlaybackPhase.PLAYING
      )
      self.state.change_phase(target)

  def _defaults(self) -> None:
    if not self.current:
      return
    if self.current.method != 'DirectPlay':
      self._non_direct_defaults()
      return
    source = self.current.source
    current_audio = current_audio_index()
    for stream_type, key in (
      ('Audio', 'DefaultAudioStreamIndex'),
      ('Subtitle', 'DefaultSubtitleStreamIndex'),
    ):
      target = integer(source.get(key), -1)
      tracks = media_streams(source, 'Audio') if stream_type == 'Audio' else subtitle_tracks(source)
      match = next(
        (
          index
          for index, value in enumerate(tracks)
          if target >= 0 and integer(value.get('Index'), -1) == target
        ),
        None,
      )
      try:
        if stream_type == 'Audio':
          if match is not None and current_audio >= 0 and match != current_audio:
            # Kodi closes/reopens audio and seeks even when selecting the same
            # stream. Leave its selection alone until the current index is known.
            self.player.setAudioStream(match)
        elif stream_type == 'Subtitle':
          if match is not None:
            self.player.setSubtitleStream(match)
          self.player.showSubtitles(match is not None)
      except RuntimeError:
        event('A default playback track was unavailable.')

  def _non_direct_defaults(self) -> None:
    if self.current is None:
      return
    try:
      if self.current.kodi_subtitle_server_indices:
        # A negotiated External sidecar or Embed output exposes exactly one
        # selectable subtitle. Its Kodi ordinal is therefore deterministic
        # and must not be reconciled against the source MediaStreams ordering.
        self.player.setSubtitleStream(0)
        self.player.showSubtitles(True)
      elif self.active_subtitle_off:
        self.player.showSubtitles(False)
    except RuntimeError:
      event('A default playback track was unavailable.')

  def _player_commands(self) -> None:
    if self.replacement_future is not None:
      self._drain_player_commands()
      return
    while True:
      try:
        kind, value, extra, amount = self.view.commands.get_nowait()
      except queue.Empty:
        break
      try:
        if kind == 'ready':
          self.view.mark_ready(value)
          self._configure_view()
          self.view.surface(self.surface)
        elif not self.current or self.finishing:
          continue
        elif kind == 'action':
          self._action(value, extra, amount)
        elif kind == 'click':
          self._click(value, extra)
      finally:
        self.view.finish_command(kind)
      if self.stop_requested or self.finishing or self.replacement_future is not None:
        # EXIT and ITEM_REPLACEMENT outrank later input from the same GUI turn.
        # Discard stale callbacks captured against the superseded surface/item.
        self._drain_player_commands()
        break

  def _drain_player_commands(self) -> None:
    while True:
      try:
        kind, _, _, _ = self.view.commands.get_nowait()
      except queue.Empty:
        return
      self.view.finish_command(kind)

  def _configure_view(self) -> None:
    current = self.current
    if not current:
      return
    item = current.item
    subtitle = ''
    if item.type == 'Episode':
      numbers = f'S{item.parent_index_number:02d}E{item.index_number:02d}'
      subtitle = ' · '.join(value for value in (item.series_name, numbers) if value)
    self.view.context(
      title=item.name,
      subtitle=subtitle,
      year=item.year,
      duration_ticks=current.duration_ticks,
      status=playback_badge(current.method, current.playback_info.get('TranscodingInfo')),
      chapters=getattr(item, 'chapters', ()),
      segments=current.segments,
    )
    self.view.hide_conditional('previous', current.previous_episode is None)
    self.view.hide_conditional('episodes', item.type != 'Episode')
    self.view.hide_conditional('next', current.next_episode is None)
    self.view.hide_conditional('audio', len(media_streams(current.source, 'Audio')) <= 1)
    self.view.hide_conditional('subtitles', not media_streams(current.source, 'Subtitle'))
    self.view.hide_conditional('chapters', not getattr(item, 'chapters', ()))
    self.view.playing(self.paused)
    self._update_view(force=True)

  def _set_surface(  # noqa: C901, PLR0912 - one adapter for the state-model surfaces.
    self, surface: str
  ) -> bool:
    if not self.state.is_interactive:
      return False
    if surface == 'clean':
      self.state.hide_surfaces()
    elif surface == 'main':
      self.state.return_to_main_osd()
    elif surface == 'panel':
      panel = _PANEL_SURFACES.get(self.panel_kind)
      if panel is None:
        return False
      self.state.return_to_main_osd()
      self.state.push_panel(panel)
    elif surface == 'stats':
      self.state.return_to_main_osd()
      self.state.push_panel(PlayerSurface.NERD_STATS)
    elif surface == 'prompt':
      if not self.state.show_contextual_prompt(PlayerSurface.SEGMENT_PROMPT):
        return False
    elif surface == 'upnext':
      if not self.state.show_contextual_prompt(PlayerSurface.UP_NEXT):
        return False
    elif surface == 'sosd':
      if self.state.visible_surface is not PlayerSurface.SOSD:
        return False
    else:
      message = f'Unknown player surface: {surface}'
      raise ValueError(message)
    self._present_surface()
    return True

  def _present_surface(self) -> None:
    surface = self.surface
    now = time.monotonic()
    self.osd_deadline = now + OSD_HIDE_DELAY if surface == 'main' else 0.0
    if surface != 'prompt':
      self.prompt_segment = None
      self.prompt_deadline = 0.0
    self.view.surface(surface)

  def _action(  # noqa: C901, PLR0911, PLR0912, PLR0915 - centralized state/action router.
    self, action: int, focus: int, _amount: float
  ) -> None:
    if action in NATIVE_PLAYBACK_ACTIONS:
      return
    if action in TOGGLE_OSD_ACTIONS:
      self._toggle_main_osd()
      return
    if action in SHOW_OSD_ACTIONS:
      self._set_surface('main')
      return
    # Kodi sends both onClick and onAction for Select on a focused control.
    # Let onClick own actionable controls so a surface change (for example,
    # Skip -> clean) cannot reinterpret the same press as clean-frame pause.
    if action in SELECT_ACTIONS and focus not in {CAPTURE, SEEK_SLIDER}:
      return
    if self.surface == 'clean':
      if action in LEFT_ACTIONS:
        self._begin_seek(-SEEK_STEP_TICKS, 'clean')
      elif action in RIGHT_ACTIONS:
        self._begin_seek(SEEK_STEP_TICKS, 'clean')
      elif action in UP_ACTIONS | DOWN_ACTIONS:
        self._set_surface('main')
      elif action in SELECT_ACTIONS:
        self._toggle_pause()
      elif action in BACK_ACTIONS:
        self.state.back()
        self._exit_player()
      return
    if self.surface == 'prompt':
      if action in SELECT_ACTIONS:
        self._skip_prompt_segment()
      elif action in LEFT_ACTIONS:
        self._dismiss_prompt(handled=True)
        self._begin_seek(-SEEK_STEP_TICKS, 'clean')
      elif action in RIGHT_ACTIONS:
        self._dismiss_prompt(handled=True)
        self._begin_seek(SEEK_STEP_TICKS, 'clean')
      elif action in UP_ACTIONS | DOWN_ACTIONS:
        self._dismiss_prompt(handled=True)
        self._set_surface('main')
      elif action in BACK_ACTIONS:
        self.state.back()
        self._exit_player()
      return
    if self.surface == 'sosd':
      if action in LEFT_ACTIONS:
        self._adjust_seek(-SEEK_STEP_TICKS)
      elif action in RIGHT_ACTIONS:
        self._adjust_seek(SEEK_STEP_TICKS)
      elif action in SELECT_ACTIONS:
        self._commit_seek()
      elif action in BACK_ACTIONS:
        self._cancel_seek()
      elif action in UP_ACTIONS | DOWN_ACTIONS:
        self._abort_seek_to_main()
      return
    if self.surface == 'main':
      self.osd_deadline = time.monotonic() + OSD_HIDE_DELAY
      if focus == SEEK_SLIDER and action in LEFT_ACTIONS:
        self._begin_or_adjust_main_seek(-SEEK_STEP_TICKS)
        return
      if focus == SEEK_SLIDER and action in RIGHT_ACTIONS:
        self._begin_or_adjust_main_seek(SEEK_STEP_TICKS)
        return
      if focus == SEEK_SLIDER and action in SELECT_ACTIONS and self.pending_seek is not None:
        self._commit_seek()
        return
      if focus == SEEK_SLIDER and action in BACK_ACTIONS and self.pending_seek is not None:
        self._cancel_seek()
        return
      if action in BACK_ACTIONS:
        self.state.back()
        self._present_surface()
      return
    if self.surface in {'panel', 'stats'}:
      self.osd_deadline = time.monotonic() + OSD_HIDE_DELAY
      if action in BACK_ACTIONS:
        self._panel_back()
      return
    if self.surface == 'upnext' and action in BACK_ACTIONS:
      self.up_next_hidden = True
      self.state.back()
      self._present_surface()

  def _click(  # noqa: C901, PLR0912 - maps the fixed XML control contract to transactions.
    self, control_id: int, selected: int
  ) -> None:
    if control_id == PLAY_PAUSE:
      self._toggle_pause()
      self._set_surface('main')
    elif control_id == PREVIOUS_EPISODE:
      self._select_episode(self.current.previous_episode if self.current else None)
    elif control_id == NEXT_EPISODE:
      self._select_episode(self.current.next_episode if self.current else None)
    elif control_id == EPISODES:
      self._open_episodes()
    elif control_id == AUDIO:
      self._open_audio()
    elif control_id == SUBTITLES:
      self._open_subtitles()
    elif control_id == CHAPTERS:
      self._open_chapters()
    elif control_id == MORE:
      self._open_more()
    elif control_id == INFO:
      self._open_stats()
    elif control_id == PANEL_BACK:
      self._panel_back()
    elif control_id == PANEL_LIST:
      self._choose_panel(selected)
    elif control_id == SEGMENT_SKIP:
      self._skip_prompt_segment()
    elif control_id == UP_NEXT_HIDE:
      self.up_next_hidden = True
      self._set_surface('clean')
    elif control_id == UP_NEXT_START:
      self._select_episode(self.current.next_episode if self.current else None)

  def _toggle_pause(self) -> None:
    try:
      self.player.pause()
    except (AttributeError, RuntimeError):
      event('Kodi could not change the playback pause state.', error=True)

  def _toggle_main_osd(self) -> None:
    if self.state.surface_stack[:1] == (PlayerSurface.MAIN_OSD,):
      self._set_surface('clean')
    else:
      self._set_surface('main')

  def _begin_seek(self, delta: int, return_surface: str) -> None:
    if not self.current:
      return
    self._clear_terminal_segment_end()
    if return_surface == 'main':
      self.state.return_to_main_osd()
    else:
      self.state.hide_surfaces()
    self.state.start_seek(self.position, self.current.duration_ticks)
    self.state.adjust_seek(delta)
    self.seek_deadline = time.monotonic() + SEEK_COMMIT_DELAY
    self._present_surface()
    if return_surface == 'main':
      self.view.focus(SEEK_SLIDER)
    self._update_view(force=True)

  def _begin_or_adjust_main_seek(self, delta: int) -> None:
    if self.pending_seek is None:
      self._begin_seek(delta, 'main')
    else:
      self._adjust_seek(delta)

  def _adjust_seek(self, delta: int) -> None:
    if self.pending_seek is None:
      return
    self.state.adjust_seek(delta)
    self.seek_deadline = time.monotonic() + SEEK_COMMIT_DELAY
    self._update_view(force=True)

  def _clamp_seek(self, ticks: int) -> int:
    duration = self.current.duration_ticks if self.current else 0
    return min(max(0, ticks), duration) if duration else max(0, ticks)

  def _commit_seek(self) -> None:
    if self.pending_seek is None or not self.current:
      return
    self._clear_terminal_segment_end()
    resolved = self.state.commit_seek()
    target = resolved.position_ticks
    destination = max(0, target - self.current.timeline_offset_ticks) / TICKS_PER_SECOND
    try:
      self.player.seekTime(destination)
    except RuntimeError:
      event('Kodi could not seek to the selected position.', error=True)
    self.position = target
    self.seek_deadline = 0.0
    self._present_surface()
    self._report('progress')

  def _cancel_seek(self) -> None:
    if self.pending_seek is None:
      return
    resolved = self.state.cancel_seek()
    self.seek_deadline = 0.0
    self.position = resolved.position_ticks
    self._present_surface()
    self._update_view(force=True)

  def _abort_seek_to_main(self) -> None:
    if self.pending_seek is None:
      return
    resolved = self.state.abort_seek_to_main_osd()
    self.seek_deadline = 0.0
    self.position = resolved.position_ticks
    self._present_surface()
    self._update_view(force=True)

  def _exit_player(self) -> None:
    if not self.current or self.finishing or self.stop_requested:
      return
    if self.state.phase is not PlaybackPhase.EXITING:
      self.state.change_phase(PlaybackPhase.EXITING)
    self.stop_requested = True
    self.stop_requested_at = time.monotonic()
    if self.replacement_future is not None:
      self.replacement_future.cancel()
    self.replacement_future = None
    self.queued_replacement = None
    self.replacement_stopping = False
    self._position()
    if not self._stop_player():
      self._event('stopped')

  def _request_exit(self) -> None:
    if not self.current:
      return
    if not self.finishing:
      self._exit_player()
      return
    if not (
      self.replacement_future is not None
      or self.queued_replacement is not None
      or self.replacement_stopping
    ):
      return
    if self.replacement_future is not None:
      self.replacement_future.cancel()
    self.replacement_future = None
    self.queued_replacement = None
    self.replacement_reason = ''
    self.replacement_pause_applied = False
    self.replacement_stopping = False
    if self.state.phase is PlaybackPhase.TRANSITIONING:
      self.state.change_phase(PlaybackPhase.EXITING)
    self.view.close()
    self._clear_active_stream_state()
    self._clear_trickplay_previews()
    self._set_screensaver_inhibited(inhibited=False)
    xbmcgui.Window(10000).clearProperty('jelq.playing')

  def _timers(self) -> None:
    now = time.monotonic()
    if self.pending_seek is not None and self.seek_deadline and now >= self.seek_deadline:
      self._commit_seek()
    if self.surface == 'main' and self.osd_deadline and now >= self.osd_deadline:
      self._set_surface('clean')
    if self.surface == 'prompt' and self.prompt_deadline and now >= self.prompt_deadline:
      self._dismiss_prompt(handled=True)

  def _update_view(self, *, force: bool = False) -> None:
    if not self.current or not self.view.visible:
      return
    now = time.monotonic()
    if not force and now - self.last_view_update < VIEW_UPDATE_INTERVAL:
      return
    self.last_view_update = now
    self.view.playing(self.paused)
    self.view.timeline(self.position, self.current.duration_ticks, self.pending_seek)
    selected = self.position if self.pending_seek is None else self.pending_seek
    chapter_name = ''
    for chapter in getattr(self.current.item, 'chapters', ()):
      if integer(getattr(chapter, 'start_ticks', -1), -1) <= selected:
        chapter_name = text(getattr(chapter, 'name', ''))
      else:
        break
    names = [segment.type for segment in segments_at(self.current.segments, selected)]
    self.view.seeking_context(chapter_name, names)
    self._seek_preview(selected)
    remaining_seconds = max(0, self.current.duration_ticks - self.position) // TICKS_PER_SECOND
    finish = datetime.now(timezone.utc).astimezone() + timedelta(seconds=remaining_seconds)
    self.view.property('finish', format_finish_time(finish))

  def _seek_preview(self, target_ticks: int) -> None:
    current = self.current
    if current is None or self.pending_seek is None:
      self.preview_requested_key = ''
      self.preview_displayed_key = ''
      self.view.seek_preview('')
      return
    frame = select_trickplay_frame(
      current.client,
      current.item,
      text(current.source.get('Id')),
      target_ticks,
    )
    if frame is not None:
      self.preview_requested_key = frame.key
      if frame.key == self.preview_displayed_key:
        return
      if self.preview_future is None and self.preview_cache is not None:
        self.preview_future_key = frame.key
        self.preview_future = self.preview_loader.submit(
          load_trickplay_preview,
          self.preview_cache,
          current.client,
          frame,
        )
      return
    self.preview_requested_key = ''
    self.preview_displayed_key = ''
    preview = chapter_preview(current.item.chapters, target_ticks)
    if preview is None:
      self.view.seek_preview('')
      return
    url = current.client.chapter_image_url(current.item, preview)
    self.view.seek_preview(self._optional_media_url(current.client, url), preview.name)

  def _poll_preview(self) -> None:
    future = self.preview_future
    if future is None or not future.done():
      return
    key = self.preview_future_key
    self.preview_future = None
    self.preview_future_key = ''
    try:
      path = future.result()
    except (ApiError, OSError, ValueError):
      path = ''
    except Exception:  # noqa: BLE001 - optional preview failures degrade silently.
      path = ''
    if path:
      self.preview_paths.add(path)
      if self.preview_cache is not None:
        self.preview_paths.update(self.preview_cache.paths)
    if (
      key == self.preview_requested_key
      and self.current is not None
      and self.pending_seek is not None
    ):
      if path:
        self.preview_displayed_key = key
        self.view.seek_preview(path, 'Trickplay preview')
      else:
        preview = chapter_preview(self.current.item.chapters, self.pending_seek)
        if preview is not None:
          url = self.current.client.chapter_image_url(self.current.item, preview)
          self.view.seek_preview(self._optional_media_url(self.current.client, url), preview.name)
        else:
          self.view.seek_preview('')

  def _clear_trickplay_previews(self) -> None:
    paths = self.preview_paths
    self.preview_paths = set()
    cache = self.preview_cache
    self.preview_cache = None
    if cache is not None:
      cache.close()
    if paths:
      remove_trickplay_previews(paths)
    future = self.preview_future
    self.preview_future = None
    self.preview_future_key = ''
    self.preview_requested_key = ''
    self.preview_displayed_key = ''
    self.preview_cache_scope = ''
    if future is not None and not future.cancel():
      future.add_done_callback(self._remove_completed_preview)

  @staticmethod
  def _remove_completed_preview(future: Future[str]) -> None:
    try:
      path = future.result()
    except Exception:  # noqa: BLE001 - optional preview cleanup is best effort.
      return
    remove_trickplay_previews({path})

  def _open_audio(self) -> None:
    if not self.current:
      return
    streams = media_streams(self.current.source, 'Audio')
    selected = (
      current_audio_index()
      if self.current.method == 'DirectPlay'
      else _kodi_index_at_server_index(streams, self.active_audio_server_index)
    )
    choices = audio_choices(
      streams,
      integer(self.current.source.get('DefaultAudioStreamIndex'), -1),
      selected,
    )
    self.panel_kind = 'audio'
    self.panel_origin_control = AUDIO
    self._set_surface('panel')
    self.view.panel('Audio', choices, [value.label for value in choices])

  def _open_subtitles(self) -> None:
    if not self.current:
      return
    streams = (
      subtitle_tracks(self.current.source)
      if self.current.method == 'DirectPlay'
      else media_streams(self.current.source, 'Subtitle')
    )
    if self.current.method == 'DirectPlay':
      selected, enabled = current_subtitle_state()
    else:
      selected = _kodi_index_at_server_index(streams, self.active_subtitle_server_index)
      enabled = not self.active_subtitle_off
    choices = subtitle_choices(
      streams,
      integer(self.current.source.get('DefaultSubtitleStreamIndex'), -1),
      selected,
      enabled,
    )
    self.panel_kind = 'subtitles'
    self.panel_origin_control = SUBTITLES
    self._set_surface('panel')
    self.view.panel('Subtitles', choices, [value.label for value in choices])

  def _open_chapters(self) -> None:
    if not self.current:
      return
    chapters = tuple(getattr(self.current.item, 'chapters', ()))
    labels = [text(getattr(chapter, 'name', ''), 'Chapter') or 'Chapter' for chapter in chapters]
    timestamps = [format_ticks(integer(getattr(chapter, 'start_ticks', 0))) for chapter in chapters]
    thumbnails = [
      self._optional_media_url(
        self.current.client, self.current.client.chapter_image_url(self.current.item, chapter)
      )
      if getattr(chapter, 'has_image', False)
      else ''
      for chapter in chapters
    ]
    self.panel_kind = 'chapters'
    self.panel_origin_control = CHAPTERS
    self._set_surface('panel')
    self.view.panel(
      'Chapters',
      chapters,
      labels,
      details=timestamps,
      thumbnails=thumbnails,
    )

  def _open_episodes(self) -> None:
    if not self.current:
      return
    browser = EpisodeBrowser.build(
      self.current.episode_sequence,
      self.current.item.id,
      self.session_start_item_id,
    )
    self.episode_browser = browser
    self.panel_origin_control = EPISODES
    self.panel_kind = 'episode-seasons'
    self._set_surface('panel')
    self.view.panel(
      self.current.item.series_name or 'Episodes',
      browser.seasons,
      [value.label + ('  • Playing' if value.current else '') for value in browser.seasons],
      selected=max(0, browser.current_season_index),
    )

  def _open_more(self) -> None:
    values: tuple[tuple[str, int], ...] = (
      ('quality', 0),
      ('quality', 40_000_000),
      ('quality', 20_000_000),
      ('quality', 10_000_000),
      ('quality', 5_000_000),
      ('subtitle-delay', -1),
      ('subtitle-delay', 1),
    )
    labels = (
      'Quality: Original / Maximum',
      'Quality: 40 Mbps',
      'Quality: 20 Mbps',
      'Quality: 10 Mbps',
      'Quality: 5 Mbps',
      'Subtitle timing: Earlier',
      'Subtitle timing: Later',
    )
    selected_limit = self.quality_limit or 0
    selected = next(
      (index for index, value in enumerate(values) if value == ('quality', selected_limit)),
      0,
    )
    self.panel_kind = 'more'
    self.panel_origin_control = MORE
    self._set_surface('panel')
    self.view.panel('More', values, labels, selected=selected)

  def _open_stats(self) -> None:
    if not self.current:
      return
    source = self.current.source
    if self.current.method == 'DirectPlay':
      audio_index = _server_index_at_kodi_index(
        media_streams(source, 'Audio'), current_audio_index()
      )
      subtitle_kodi_index, subtitle_enabled = current_subtitle_state()
      subtitle_index = _server_index_at_kodi_index(subtitle_tracks(source), subtitle_kodi_index)
    else:
      audio_index = self.active_audio_server_index
      subtitle_index = self.active_subtitle_server_index
      subtitle_enabled = not self.active_subtitle_off
    values = diagnostic_rows(
      method=self.current.method,
      playback_info=self.current.playback_info,
      source=source,
      session_id=self.current.session_id,
      position_ticks=self.position,
      duration_ticks=self.current.duration_ticks,
      paused=self.paused,
      audio_index=audio_index,
      subtitle_index=subtitle_index,
      subtitle_enabled=subtitle_enabled,
    )
    lines = [value.label + ': ' + value.value for value in values]
    self.panel_kind = 'stats'
    self.panel_origin_control = INFO
    self._set_surface('stats')
    self.view.nerd_stats('[CR]'.join(lines))

  def _choose_panel(self, selected: int) -> None:  # noqa: C901 - heterogeneous row router.
    value = self.view.selected_panel_value(selected)
    if value is None:
      return
    if self.panel_kind == 'audio' and isinstance(value, StreamChoice):
      self._request_replacement(
        self.current.item if self.current else None,
        self.position,
        'audio track',
        audio_index=value.server_index,
      )
    elif self.panel_kind == 'subtitles' and isinstance(value, StreamChoice):
      self._request_replacement(
        self.current.item if self.current else None,
        self.position,
        'subtitle track',
        subtitle_index=-1 if value.off else value.server_index,
        subtitle_off=value.off,
      )
    elif self.panel_kind == 'chapters':
      target = integer(getattr(value, 'start_ticks', 0))
      if not self.current:
        return
      self.state.return_to_main_osd()
      self.state.start_seek(self.position, self.current.duration_ticks)
      self.state.adjust_seek(self._clamp_seek(target) - self.position)
      self._commit_seek()
    elif self.panel_kind == 'episode-seasons' and isinstance(value, SeasonGroup):
      self._open_season(value)
    elif self.panel_kind == 'episode-items' and isinstance(value, EpisodeChoice):
      self._select_episode(value.item)
    elif self.panel_kind == 'more' and isinstance(value, tuple):
      kind, amount = value
      if kind == 'subtitle-delay':
        xbmc.executebuiltin('Action(SubtitleDelay{})'.format('Minus' if amount < 0 else 'Plus'))
        self._set_surface('main')
      elif kind == 'quality':
        self._quality_selected(amount)

  def _open_season(self, season: SeasonGroup) -> None:
    browser = self.episode_browser
    if browser is None:
      return
    season_index = next(
      (index for index, value in enumerate(browser.seasons) if value.key == season.key),
      -1,
    )
    if season_index < 0:
      return
    self.selected_season_index = season_index
    self.panel_kind = 'episode-items'
    labels = []
    for choice in season.episodes:
      suffix = []
      if choice.current:
        suffix.append('Playing')
      if choice.session_start and not choice.current:
        suffix.append('Started here')
      labels.append(choice.label + ('  • ' + ' · '.join(suffix) if suffix else ''))
    self.view.panel(
      season.label,
      season.episodes,
      labels,
      selected=max(0, season.current_episode_index),
    )

  def _panel_back(self) -> None:
    if self.panel_kind == 'episode-items' and self.episode_browser is not None:
      browser = self.episode_browser
      self.panel_kind = 'episode-seasons'
      self.view.panel(
        self.current.item.series_name if self.current else 'Episodes',
        browser.seasons,
        [value.label + ('  • Playing' if value.current else '') for value in browser.seasons],
        selected=max(0, self.selected_season_index),
      )
      return
    self._set_surface('main')
    self.view.focus(self.panel_origin_control)

  def _select_episode(self, item: MediaItem | None) -> None:
    if item is None or not self.current or item.id == self.current.item.id:
      self._set_surface('main')
      return
    self.up_next_started = True
    self._request_replacement(item, 0, 'episode')

  def _quality_selected(self, bitrate: int) -> None:
    if not self.current:
      return
    self.quality_limit = bitrate if bitrate > 0 else None
    self.preferences.set_bitrate_limit(self.network_context, self.quality_limit)
    self.preferences_changed()
    self._request_replacement(self.current.item, self.position, 'streaming quality')

  def _request_replacement(  # noqa: PLR0913 - explicit stream transaction state.
    self,
    item: MediaItem | None,
    start_ticks: int,
    reason: str,
    *,
    audio_index: int | None = None,
    subtitle_index: int | None = None,
    subtitle_off: bool = False,
    refresh_active_streams: bool = True,
  ) -> None:
    if (
      item is None
      or self.current is None
      or self.replacement_future is not None
      or self.queued_replacement is not None
    ):
      return
    current = self.current
    if refresh_active_streams:
      self._refresh_active_stream_state()
    preferred_audio = (
      dict(self._active_audio_stream)
      if audio_index is None and self._active_audio_stream is not None
      else None
    )
    preferred_subtitle = (
      dict(self._active_subtitle_stream)
      if (
        subtitle_index is None
        and not self._active_subtitle_off
        and self._active_subtitle_stream is not None
      )
      else None
    )
    carry_off = subtitle_off or (subtitle_index is None and self._active_subtitle_off)
    self.replacement_reason = reason
    self.replacement_pause_applied = False
    self.view.property('method', 'Switching stream…')
    self.view.property('method.tone', 'neutral')
    self._set_surface('main')
    if not self.paused:
      try:
        self.player.pause()
        self.state.change_phase(PlaybackPhase.PAUSED)
        self.replacement_pause_applied = True
      except (AttributeError, RuntimeError):
        pass
    self.replacement_future = self.loader.submit(
      prepare,
      current.client,
      item,
      resume=False,
      start_ticks=max(0, start_ticks),
      audio_index=audio_index,
      subtitle_index=subtitle_index,
      max_streaming_bitrate=self.quality_limit,
      preferred_audio=preferred_audio,
      preferred_subtitle=preferred_subtitle,
      subtitle_off=carry_off,
    )

  def _poll_replacement(self) -> bool:
    future = self.replacement_future
    if future is None or not future.done():
      return False
    self.replacement_future = None
    try:
      prepared = future.result()
    except (ApiError, OSError, ValueError) as error:
      self._replacement_failed(str(error))
      return True
    except Exception:  # noqa: BLE001 - Contain worker failures without secret-bearing details.
      event('A playback replacement failed.', error=True)
      self._replacement_failed('The replacement stream could not be prepared.')
      return True
    self.queued_replacement = prepared
    if self.finishing:
      return True
    self.replacement_stopping = True
    self.stop_requested_at = time.monotonic()
    self._position()
    if not self._stop_player():
      self._event('stopped')
    return True

  def _replacement_failed(self, message: str) -> None:
    reason = self.replacement_reason or 'playback change'
    self.replacement_reason = ''
    self.queued_replacement = None
    self.replacement_stopping = False
    if self.finishing:
      self.view.close()
      xbmcgui.Window(10000).clearProperty('jelq.playing')
    else:
      if self.replacement_pause_applied:
        try:
          self.player.pause()
          self.state.change_phase(PlaybackPhase.PLAYING)
        except (AttributeError, RuntimeError):
          pass
      self._configure_view()
      self._set_surface('main')
    self.replacement_pause_applied = False
    xbmcgui.Dialog().ok('Could not change ' + reason, message)

  def _segment_runtime(self) -> None:
    if (
      not self.current
      or self.pending_seek is not None
      or self.replacement_future is not None
      or self.queued_replacement is not None
      or self.replacement_stopping
    ):
      return
    if (
      self.surface == 'prompt'
      and self.prompt_segment is not None
      and not self.prompt_segment.contains(self.position)
    ):
      self._dismiss_prompt(handled=True)
    for segment in self.current.segments:
      if not segment.contains(self.position):
        continue
      key = _segment_key(segment)
      if key in self.handled_segments:
        continue
      policy = (
        self.preferences.media_segment_policy(self.account_scope, segment.type)
        if self.account_scope is not None
        else MediaSegmentPolicies().for_type(segment.type)
      )
      if policy is SegmentPolicy.INACTIVE:
        self.handled_segments.add(key)
        continue
      if policy is SegmentPolicy.AUTOMATIC:
        self.handled_segments.add(key)
        self._seek_to_segment_end(segment)
        return
      if self.surface == 'clean':
        self.prompt_segment = segment
        self.prompt_deadline = time.monotonic() + PROMPT_HIDE_DELAY
        self.view.prompt('Skip ' + segment.type.lower(), segment.start_ticks, segment.end_ticks)
        self._set_surface('prompt')
      return

  def _skip_prompt_segment(self) -> None:
    segment = self.prompt_segment
    if segment is None:
      self._set_surface('clean')
      return
    self.handled_segments.add(_segment_key(segment))
    self._seek_to_segment_end(segment)
    self._set_surface('clean')

  def _seek_to_segment_end(self, segment: Segment) -> None:
    if not self.current:
      return
    self._clear_terminal_segment_end()
    target = self._clamp_seek(segment.end_ticks)
    seek_generation = self.player.seek_generation
    try:
      self.player.seekTime(max(0, target - self.current.timeline_offset_ticks) / TICKS_PER_SECOND)
    except RuntimeError:
      event('Kodi could not skip a media segment.', error=True)
      return
    self.position = target
    duration = self.current.duration_ticks
    tolerance = min(END_TOLERANCE_TICKS, duration // 20)
    if duration > 0 and target >= duration - tolerance:
      # Kodi applies seekTime asynchronously. Preserve the controller's explicit
      # terminal-skip intent if an intervening getTime still reports the old
      # position before onPlayBackEnded arrives, but do not mask a later EOF.
      self.terminal_segment_end_deadline = time.monotonic() + TERMINAL_SEGMENT_END_GRACE_SECONDS
      self.terminal_segment_end_seek_generation = seek_generation
    self._report('progress')

  def _dismiss_prompt(self, *, handled: bool) -> None:
    if handled and self.prompt_segment is not None:
      self.handled_segments.add(_segment_key(self.prompt_segment))
    self.prompt_segment = None
    self.prompt_deadline = 0.0
    self._set_surface('clean')

  def _up_next(self) -> None:
    if not self.current or not self.current.next_episode or self.up_next_started:
      return
    remaining = max(0, self.current.duration_ticks - self.position)
    if remaining < UP_NEXT_MINIMUM_PROMPT_TICKS or self.up_next_hidden:
      if self.surface == 'upnext':
        self.state.dismiss_contextual_prompt()
        self._present_surface()
      if remaining < UP_NEXT_MINIMUM_PROMPT_TICKS:
        self.up_next_hidden = True
      return
    if remaining > UP_NEXT_WINDOW_TICKS:
      if self.surface == 'upnext':
        self.state.dismiss_contextual_prompt()
        self._present_surface()
      return
    seconds = remaining // TICKS_PER_SECOND
    if seconds == self.last_up_next_second:
      return
    next_item = self.current.next_episode
    context = f'S{next_item.parent_index_number:02d}E{next_item.index_number:02d}'
    countdown = seconds if self.current.autoplay_next else None
    if self.surface != 'upnext' and not self._set_surface('upnext'):
      return
    self.last_up_next_second = seconds
    self.view.up_next(next_item.name, context, countdown)

  def _report(self, action: str) -> None:
    if self.current is None or self.report_client is None:
      return
    if action == 'progress' and any(not future.done() for future in self.reports):
      # A slow/offline server must not accumulate an unbounded queue of obsolete
      # positions. Start/stop are always retained; progress takes a fresh snapshot.
      self.last_report = time.monotonic()
      return
    current = self.current
    payload: dict[str, Any] = {
      'ItemId': current.item.id,
      'MediaSourceId': text(current.source.get('Id')),
      'PlaySessionId': current.session_id,
      'PositionTicks': self.position,
      'IsPaused': self.paused,
      'CanSeek': True,
      'PlayMethod': current.method,
    }
    audio_index = self.active_audio_server_index
    if audio_index >= 0:
      payload['AudioStreamIndex'] = audio_index
    subtitle_index = self.active_subtitle_server_index
    if self.active_subtitle_off:
      payload['SubtitleStreamIndex'] = -1
    elif subtitle_index >= 0:
      payload['SubtitleStreamIndex'] = subtitle_index
    function = {
      'start': self.report_client.report_start,
      'progress': self.report_client.report_progress,
      'stop': self.report_client.report_stop,
    }[action]
    self.reports.append(self.reporter.submit(self._send, function, payload))
    self.last_report = time.monotonic()

  def _send(self, function: Callable[[dict[str, Any]], None], payload: dict[str, Any]) -> bool:
    for delay in (0, 1, 3):
      if delay and self.shutdown.wait(delay):
        return False
      try:
        function(payload)
      except AuthError:
        return False
      except ApiError:
        continue
      except Exception:  # noqa: BLE001 - Contain reporter failures without exposing HTTP credentials.
        event('A playback update failed.', error=True)
        return False
      else:
        return True
    return False

  def close(self) -> None:
    self._set_screensaver_inhibited(inhibited=False)
    self._clear_trickplay_previews()
    self.view.close()
    xbmcgui.Window(10000).clearProperty('jelq.playing')
    if self.replacement_future is not None:
      self.replacement_future.cancel()
    self.replacement_future = None
    self.queued_replacement = None
    if self.current and not self.finishing:
      self._position()
      self._stop_player()
      self._event('stopped')
    self._clear_active_stream_state()
    self.shutdown.set()
    if any(not future.done() for future in self.reports):
      xbmcgui.Dialog().notification('Watch progress', 'Finishing watch progress in the background.')
    # Keep the final stop, but never make the window wait for the network. The
    # original account snapshot has a short timeout; shutdown suppresses retries.
    self.reporter.shutdown(wait=False)
    self.loader.shutdown(wait=False)
    self.preview_loader.shutdown(wait=False)
