from __future__ import annotations

import queue
import time
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import dataclass
from functools import partial
from typing import Any, Callable, cast
from uuid import uuid4

import xbmc
import xbmcaddon
import xbmcgui

from jelq.accounts import Account, AccountStore, Server, normalize_url
from jelq.client import ApiError, AuthError, JellyfinClient
from jelq.kodi.dev_state import DevelopmentState
from jelq.kodi.log import event
from jelq.kodi.playback import PlaybackController, PreparedPlayback, prepare
from jelq.kodi.settings_window import SettingsController, SettingsWindow
from jelq.kodi.skin import activate_companion_skin
from jelq.kodi.storage import PreferenceStorage, ProfileStorage
from jelq.kodi.urls import authenticated_url
from jelq.models import MediaItem, Page, text
from jelq.navigation import Navigation, Screen
from jelq.preferences import AccountScope, NetworkContext, Preferences
from jelq.server_settings import ServerSettingsCache

LIST = 100
BACK = 201
USER = 202
SERVER = 203
ADDON_SETTINGS = 204
EXIT = 205
SETTINGS = 206
BACK_ACTIONS = {9, 10, 92}
ACTIVE_PROPERTY = 'jelq.active'
PLAYING_PROPERTY = 'jelq.playing'
# The claim is refreshed while jelq runs so an instance that loses its window,
# and therefore can no longer be exited from the UI, stops blocking a relaunch.
CLAIM_HEARTBEAT_SECONDS = 1.0
CLAIM_STALE_SECONDS = 5.0
# Launching jelq while it already runs asks the running instance to come forward
# rather than replacing it; only an instance that cannot answer is restarted.
FRONT_PROPERTY = 'jelq.front'
FRONT_WAIT_SECONDS = 2.5
MODAL_DIALOG = 'System.HasActiveModalDialog'


def _claim_text(token: str) -> str:
  return token + ':' + repr(time.monotonic())


def _claim_parts(value: str) -> tuple[str, float] | None:
  """Read a claim, treating anything unrecognised as abandoned."""
  token, separator, stamp = value.partition(':')
  if not token or not separator:
    return None
  try:
    return token, float(stamp)
  except ValueError:
    return None


def claim_single_instance(home: xbmcgui.Window, *, force: bool = False) -> str | None:
  """
  Take the single-instance claim, or return None if a live instance holds it.

  Staleness only catches an instance whose loop has stopped. One that has lost
  its window keeps its claim fresh while being unreachable, so `force` exists to
  let the user hand the claim over; the displaced instance stands down when it
  next sees a token that is not its own.
  """
  parts = _claim_parts(home.getProperty(ACTIVE_PROPERTY))
  if not force and parts is not None and time.monotonic() - parts[1] <= CLAIM_STALE_SECONDS:
    return None
  token = uuid4().hex
  home.setProperty(ACTIVE_PROPERTY, _claim_text(token))
  return token


def holds_claim(home: xbmcgui.Window, token: str) -> bool:
  parts = _claim_parts(home.getProperty(ACTIVE_PROPERTY))
  return parts is None or parts[0] == token


def ask_running_instance_forward(home: xbmcgui.Window) -> bool:
  """Ask the running instance to show itself, and report whether it answered."""
  home.setProperty(FRONT_PROPERTY, '1')
  monitor = xbmc.Monitor()
  deadline = time.monotonic() + FRONT_WAIT_SECONDS
  while time.monotonic() < deadline:
    if monitor.waitForAbort(0.1):
      return True
    if not home.getProperty(FRONT_PROPERTY):
      return True
  home.clearProperty(FRONT_PROPERTY)
  return False


def network_context(is_in_network: object) -> NetworkContext:
  """Map Jellyfin's endpoint result; every absent/invalid value is conservative."""
  return NetworkContext.IN_NETWORK if is_in_network is True else NetworkContext.REMOTE


def prepare_with_fresh_network_context(
  client: JellyfinClient,
  item: MediaItem,
  preferences: Preferences,
  *,
  resume: bool,
) -> tuple[NetworkContext, PreparedPlayback]:
  try:
    context = network_context(client.endpoint_is_in_network())
  except (ApiError, OSError, ValueError):
    context = NetworkContext.REMOTE
    event('Jellyfin endpoint classification was unavailable; using Internet quality.')
  prepared = prepare(
    client,
    item,
    resume=resume,
    max_streaming_bitrate=preferences.player.bitrate_limits.for_context(context),
  )
  return context, prepared


@dataclass
class Row:
  label: str
  secondary: str
  action: Callable[[], None]
  item: MediaItem | None = None


@dataclass
class Task:
  generation: int
  done: Callable[[Any], None]
  retry: Callable[[], None]


class ApplicationWindow(xbmcgui.WindowXML):
  commands: queue.Queue[tuple[str, int]]
  initialised = False

  def onInit(self) -> None:  # noqa: N802 - Kodi callback name.
    # Kodi calls onInit again after a skin reload, on this same Python object but
    # against freshly built controls. That is the only notice jelq gets: Kodi 21.3
    # announces neither GUI.OnSkinUnloading nor GUI.OnSkinLoaded.
    if self.initialised:
      self.commands.put(('rebuilt', 0))
      return
    self.initialised = True
    self.commands.put(('ready', 0))

  def onClick(self, control_id: int) -> None:  # noqa: N802 - Kodi callback name.
    self.commands.put(('click', control_id))

  def onAction(self, action: xbmcgui.Action) -> None:  # noqa: N802 - Kodi callback name.
    if action.getId() in BACK_ACTIONS:
      self.commands.put(('click', BACK))


class Application:
  def __init__(
    self,
    addon: xbmcaddon.Addon,
    window: ApplicationWindow,
    *,
    home: xbmcgui.Window | None = None,
    token: str = '',
  ) -> None:
    self.addon = addon
    self.window = window
    self.home = home
    self.token = token
    self.claim_due = 0.0
    self.expect_reinit = False
    self.show_pending = False
    self.monitor = xbmc.Monitor()
    self.storage = ProfileStorage(addon.getAddonInfo('profile'))
    self.preference_storage = PreferenceStorage(addon.getAddonInfo('profile'))
    self.store = AccountStore()
    self.preferences = Preferences()
    self.server_settings_cache = ServerSettingsCache()
    self.navigation = Navigation()
    self.navigation.reset(Screen('boot', 'Welcome'))
    self.workers = ThreadPoolExecutor(max_workers=3)
    self.disk = ThreadPoolExecutor(max_workers=1)
    self.tasks: dict[Future[Any], Task] = {}
    self.saves: list[Future[None]] = []
    self.rows: list[Row] = []
    self.server: Server | None = None
    self.account: Account | None = None
    self.client: JellyfinClient | None = None
    self.busy = False
    self.closed = False
    self.render_pending = False
    self.ready = False
    self.last_selected = -1
    self.retry: Callable[[], None] | None = None
    self.playback = PlaybackController(
      addon.getAddonInfo('path'),
      self._playback_finished,
      self._persist_preferences,
    )
    self.playback_generation: int | None = None

  def run(self) -> None:
    self.window.show()
    try:
      while not self.closed and not self.monitor.abortRequested():
        if not self._hold_claim():
          break
        self._honour_front_request()
        self._show_when_unobstructed()
        if self.render_pending:
          self._render()
        self._commands()
        self._results()
        self._poll_playback()
        if self.ready and not self.playback.active:
          self._selection()
        self.monitor.waitForAbort(0.05)
    finally:
      self.playback.close()
      self.window.close()
      # In-flight requests have bounded timeouts; queued UI work cannot become visible again.
      for future in self.tasks:
        future.cancel()
      self.workers.shutdown(wait=False)
      self.disk.shutdown(wait=True)

  def _commands(self) -> None:
    while not self.window.commands.empty():
      kind, value = self.window.commands.get_nowait()
      if kind == 'ready':
        self.last_selected = -1
        self._render()
        if not self.ready:
          self.ready = True
          self._submit(self._load_saved_state, self._loaded)
      elif kind == 'rebuilt':
        if self.expect_reinit:
          self.expect_reinit = False
          self.last_selected = -1
          self._render()
        else:
          self._replace_window()
      elif kind == 'click':
        self._click(value)

  def _submit(self, work: Callable[[], Any], done: Callable[[Any], None]) -> None:
    self.busy = True
    self.retry = None
    self._status('Loading…')
    future = self.workers.submit(work)
    self.tasks[future] = Task(self.navigation.generation, done, lambda: self._submit(work, done))

  def _results(self) -> None:
    for future, task in list(self.tasks.items()):
      if not future.done():
        continue
      del self.tasks[future]
      if task.generation != self.navigation.generation:
        continue
      self.busy = False
      self._complete(future, task)
    for future in list(self.saves):
      if future.done():
        self.saves.remove(future)
        if future.exception() is not None:
          self._status('Could not save local data. Your changes may not survive a restart.')

  def _complete(self, future: Future[Any], task: Task) -> None:
    try:
      value = future.result()
    except AuthError:
      self._status('This sign-in has expired or was not accepted. Please sign in again.')
      self.retry = partial(self._login, self.account.user_name) if self.account else task.retry
      self._render_retry()
    except (ApiError, OSError, ValueError) as error:
      self._status(str(error))
      self.retry = task.retry
      self._render_retry()
    except Exception:  # noqa: BLE001 - Worker boundary; never dump secret-bearing exception objects.
      event('A background operation failed.', error=True)
      self._status('Something went wrong. Retry or return to the previous screen.')
      self.retry = task.retry
      self._render_retry()
    else:
      task.done(value)

  def _persist(self) -> None:
    self.saves.append(self.disk.submit(self.storage.write, self.store.to_json()))

  def _persist_preferences(self) -> None:
    self.saves.append(self.disk.submit(self.preference_storage.write, self.preferences.to_json()))

  def _load_saved_state(self) -> tuple[AccountStore, Preferences]:
    store = AccountStore.from_json(self.storage.read())
    serialized_preferences = self.preference_storage.read()
    preferences = Preferences.from_json(serialized_preferences)
    if not serialized_preferences.strip():
      self.preference_storage.write(preferences.to_json())
    return store, preferences

  def _loaded(self, state: tuple[AccountStore, Preferences]) -> None:
    store, self.preferences = state
    self.store = store
    server = next((s for s in store.servers if s.url == store.last_server_url), None)
    if server:
      self._select_server(server)
    else:
      self._servers()

  def _reset(self, screen: Screen) -> None:
    self.navigation.reset(screen)
    self.busy = False
    self.retry = None
    self.last_selected = -1
    self._render()

  def _servers(self) -> None:
    self.client = None
    self.account = None
    self.server = None
    self._reset(Screen('servers', 'Choose a server'))

  def _select_server(self, server: Server) -> None:
    self.server = server
    self.store.last_server_url = server.url
    self._persist()
    self._users()

  def _users(self) -> None:
    self.client = None
    self.account = None
    self._reset(Screen('users', "Who's watching?"))

  def _add_server(self) -> None:
    address = xbmcgui.Dialog().input('Jellyfin server address', defaultt='https://')
    if not address:
      return
    try:
      address = normalize_url(address)
    except ValueError as error:
      self._status(str(error))
      return
    client = JellyfinClient(address, self.store.device_id)

    def connected(info: dict[str, Any]) -> None:
      server = Server(address, text(info.get('Id')), text(info.get('ServerName'), 'Jellyfin'))
      self.store.add_server(server)
      self._select_server(server)

    self._submit(client.public_info, connected)

  def _login(self, name: str = '') -> None:
    if self.server is None:
      return
    name = xbmcgui.Dialog().input('Username', defaultt=name)
    if not name:
      return
    password = xbmcgui.Dialog().input(
      'Password', type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT
    )
    if not password:
      return
    client = JellyfinClient(self.server.url, self.store.device_id)

    def authenticated(account: Account) -> None:
      self.store.save_account(account)
      self._persist()
      self._use_account(account, validate=False)

    # Password exists only for this bounded authentication call; retries ask for it again.
    self._submit(partial(client.authenticate, name, password), authenticated)
    future = next(reversed(self.tasks))
    self.tasks[future].retry = partial(self._login, name)

  def _use_account(self, account: Account, *, validate: bool = True) -> None:
    self.account = account
    self.client = JellyfinClient(
      account.server_url, account.device_id, account.token, account.user_id
    )
    self.playback.configure_preferences(
      self.preferences.player,
      self._account_scope(account),
      NetworkContext.REMOTE,
    )
    if validate:
      self._submit(self.client.current_user, lambda _user: self._libraries())
    else:
      self._libraries()

  def _account_scope(self, account: Account) -> AccountScope:
    server_id = account.server_id or (self.server.id if self.server else '') or account.server_url
    return AccountScope(server_id, account.user_id)

  def _libraries(self) -> None:
    self._reset(Screen('libraries', 'Your libraries'))
    if self.client:
      self._submit(self.client.libraries, self._library_results)

  def _library_results(self, items: tuple[MediaItem, ...]) -> None:
    screen = self.navigation.current
    screen.items = [
      item for item in items if text(item.raw.get('CollectionType')) in {'movies', 'tvshows', ''}
    ]
    screen.loaded = True
    self._render()

  def _open_library(self, item: MediaItem) -> None:
    self._remember()
    kind = 'Series' if item.raw.get('CollectionType') == 'tvshows' else 'Movie'
    self.navigation.push(Screen('items', item.name, parent_id=item.id, item_type=kind))
    self._render()
    self._load_page()

  def _load_page(self) -> None:
    if self.client is None:
      return
    screen = self.navigation.current
    client = self.client
    if screen.kind == 'episodes':
      work = partial(client.episodes, screen.series_id, screen.parent_id, len(screen.items))
    elif screen.kind == 'seasons':
      work = partial(client.seasons, screen.parent_id)
    else:
      work = partial(client.items, screen.parent_id, screen.item_type, len(screen.items))
    self._submit(work, self._page_results)

  def _page_results(self, page: Page) -> None:
    screen = self.navigation.current
    screen.items.extend(page.items)
    screen.total = page.total if page.items else len(screen.items)
    screen.loaded = True
    self._render()

  def _open_item(self, item: MediaItem) -> None:
    self._remember()
    if item.type == 'Season':
      screen = Screen('episodes', item.name, parent_id=item.id, series_id=item.series_id)
      self.navigation.push(screen)
      self._render()
      self._load_page()
      return
    self.navigation.push(Screen('details', item.name, detail=item))
    self._render()
    if self.client:
      self._submit(partial(self.client.item, item.id), self._details_result)

  def _details_result(self, item: MediaItem) -> None:
    self.navigation.current.detail = item
    self._render()

  def _seasons(self, item: MediaItem) -> None:
    self._remember()
    self.navigation.push(Screen('seasons', item.name, parent_id=item.id))
    self._render()
    self._load_page()

  def _play(self, item: MediaItem, *, resume: bool) -> None:
    if not self.client:
      return
    if self.playback.busy:
      self._status('Watch progress is still syncing. Please wait before playing another title.')
      return
    self._remember()
    self._submit(
      partial(
        prepare_with_fresh_network_context,
        self.client,
        item,
        self.preferences,
        resume=resume,
      ),
      self._start_playback,
    )

  def _start_playback(self, result: tuple[NetworkContext, PreparedPlayback]) -> None:
    context, prepared = result
    if self.account is None:
      return
    self.playback.configure_preferences(
      self.preferences.player,
      self._account_scope(self.account),
      context,
    )
    self.playback_generation = self.navigation.generation
    self.playback.start(prepared)

  def _poll_playback(self) -> None:
    was_active = self.playback.active
    self.playback.poll()
    if was_active and not self.playback.active and not self.closed:
      self.window.show()
      if self.playback.busy:
        self._status('Saving watch progress… You can browse or exit.')

  def _playback_finished(self, item_id: str) -> None:
    generation = self.playback_generation
    self.playback_generation = None
    if self.closed or generation != self.navigation.generation:
      return
    self.window.show()
    if self.client:
      self._submit(partial(self.client.item, item_id), self._refresh_item)

  def _refresh_item(self, item: MediaItem) -> None:
    for screen in self.navigation.screens:
      screen.items = [item if previous.id == item.id else previous for previous in screen.items]
      if screen.detail and screen.detail.id == item.id:
        screen.detail = item
    self._render()

  def _sign_out(self) -> None:
    if self.account is None or self.client is None:
      return
    account = self.account
    client = self.client
    if not xbmcgui.Dialog().yesno('Sign out', 'Remove this saved sign-in from this device?'):
      return

    def logout() -> str:
      try:
        client.logout()
      except ApiError:
        return 'Saved sign-in removed. Server logout could not be confirmed.'
      return 'Signed out.'

    self.store.remove_account(account.server_url, account.user_id)
    self._persist()
    self._users()
    self._submit(logout, self._status)

  def _click(self, control_id: int) -> None:  # noqa: C901 - explicit control routing.
    # Abandoning profile loading would let a new sign-in overwrite saved accounts
    # with this instance's empty store. Keep Retry and Exit available during boot.
    if self.playback.active or (
      self.navigation.current.kind == 'boot' and control_id in {SERVER, USER}
    ):
      return
    if control_id == EXIT:
      self.closed = True
    elif control_id == BACK:
      self._back()
    elif control_id == USER and self.server:
      self._users()
    elif control_id == SERVER:
      self._servers()
    elif control_id == ADDON_SETTINGS:
      self.addon.openSettings()
      self._render()
      self.window.setFocusId(ADDON_SETTINGS)
    elif control_id == SETTINGS and self._authenticated_library_context():
      self._open_settings()
    elif control_id == LIST and not self.busy and self._controls_live():
      index = self._list().getSelectedPosition()
      if 0 <= index < len(self.rows):
        if self.retry is None:
          self.navigation.current.selected = index
        self.rows[index].action()

  def _authenticated_library_context(self) -> bool:
    return (
      self.account is not None
      and self.client is not None
      and self.server is not None
      and self.navigation.current.kind in {'libraries', 'items', 'seasons', 'episodes', 'details'}
    )

  def _open_settings(self) -> None:
    if self.account is None or self.client is None or self.server is None:
      return
    self._remember()
    window = SettingsWindow(
      'script-jelq-settings.xml', self.addon.getAddonInfo('path'), 'Default', '1080i'
    )
    window.commands = queue.Queue()
    controller = SettingsController(
      self.addon,
      window,
      self.client,
      self._account_scope(self.account),
      self.server.name,
      self.account.user_name,
      self.preferences,
      self._persist_preferences,
      self.server_settings_cache,
    )
    controller.run()
    if not self.closed:
      self.window.show()
      self._render()
      self.window.setFocusId(SETTINGS)

  def _back(self) -> None:
    if self.navigation.back():
      self.busy = False
      self.retry = None
      self._render()
      if not self.navigation.current.loaded and self.navigation.current.kind in {
        'items',
        'seasons',
        'episodes',
      }:
        self._load_page()
    elif self.navigation.current.kind == 'users':
      self._servers()
    elif self.navigation.current.kind == 'libraries':
      self._users()
    else:
      self.closed = xbmcgui.Dialog().yesno('Exit jelq', 'Return to Kodi?')

  def _remember(self) -> None:
    if not self._controls_live():
      return
    self.navigation.current.selected = max(0, self._list().getSelectedPosition())

  def _list(self) -> xbmcgui.ControlList:
    return cast('xbmcgui.ControlList', self.window.getControl(LIST))

  def _status(self, value: str) -> None:
    if not self._controls_live():
      return
    cast('xbmcgui.ControlLabel', self.window.getControl(11)).setLabel(value)

  def _image(self, item: MediaItem) -> str:
    if not self.client:
      return ''
    address = self.client.image_url(item)
    if not address:
      return ''
    try:
      return authenticated_url(self.client, address)
    except ApiError:
      return ''

  def _render(self) -> None:
    if not self._controls_live():
      self.render_pending = True
      return
    self.render_pending = False
    screen = self.navigation.current
    cast('xbmcgui.ControlLabel', self.window.getControl(10)).setLabel(screen.title)
    self.rows = self._screen_rows(screen)
    self._render_rows()
    if self.account and self.server:
      status = self.account.user_name + ' · ' + self.server.name
      if screen.kind == 'items':
        status += ' · ' + (
          'Latest episode added' if screen.item_type == 'Series' else 'Newest added'
        )
      self._status(status)
    elif self.server and screen.kind == 'users':
      self._status(self.server.name + ' · Select a saved user or sign in')
    else:
      self._status('Choose a saved server or add your Jellyfin server')
    self._render_footer()
    self.window.setFocusId(LIST if self.rows else EXIT)
    self.last_selected = -1
    self._selection()

  def _render_footer(self) -> None:
    if not self._controls_live():
      return
    self.window.getControl(SETTINGS).setVisible(self._authenticated_library_context())

  def _screen_rows(self, screen: Screen) -> list[Row]:
    if screen.kind == 'servers':
      rows = [
        Row(s.name, 'Saved server', partial(self._select_server, s)) for s in self.store.servers
      ]
      return [*rows, Row('Add server', 'Enter a Jellyfin server address', self._add_server)]
    if screen.kind == 'users' and self.server:
      rows = [
        Row(a.user_name, 'Saved sign-in', partial(self._use_account, a))
        for a in self.store.accounts_for(self.server.url)
      ]
      return [*rows, Row('Sign in as another user', '', self._login)]
    if screen.kind == 'details' and screen.detail:
      return self._detail_rows(screen.detail)
    rows = [
      Row(
        self._item_title(item),
        self._item_summary(item),
        partial(self._open_library if screen.kind == 'libraries' else self._open_item, item),
        item,
      )
      for item in screen.items
    ]
    if screen.has_more:
      rows.append(
        Row('Load more', str(len(screen.items)) + ' of ' + str(screen.total), self._load_page)
      )
    elif screen.loaded and not screen.items:
      rows.append(Row('Nothing here yet', 'Refresh to check again', self._reload))
    if screen.kind == 'libraries':
      rows.append(Row('Sign out', 'Remove the current saved sign-in', self._sign_out))
    return rows

  def _detail_rows(self, item: MediaItem) -> list[Row]:
    if item.type == 'Series':
      return [
        Row('Seasons and episodes', self._item_summary(item), partial(self._seasons, item), item)
      ]
    rows = []
    if item.position_ticks:
      minutes = item.position_ticks // 600_000_000
      rows.append(
        Row(
          'Resume',
          'Continue from ' + str(minutes) + ' min',
          partial(self._play, item, resume=True),
          item,
        )
      )
    rows.append(
      Row(
        'Play from beginning',
        self._item_summary(item),
        partial(self._play, item, resume=False),
        item,
      )
    )
    return rows

  def _reload(self) -> None:
    if self.navigation.current.kind == 'libraries':
      self._libraries()
    else:
      self._load_page()

  def _render_rows(self) -> None:
    if not self._controls_live():
      return
    control = self._list()
    control.reset()
    for row in self.rows:
      entry = xbmcgui.ListItem(label=row.label, label2=row.secondary)
      if row.item:
        entry.setArt({'icon': self._image(row.item), 'thumb': self._image(row.item)})
      control.addItem(entry)
    if self.rows:
      control.selectItem(min(self.navigation.current.selected, len(self.rows) - 1))

  def _render_retry(self) -> None:
    if self.retry:
      self.rows = [Row('Retry', 'Your saved server and account are preserved', self.retry)]
      self._render_rows()
      self.window.setFocusId(LIST)

  def _selection(self) -> None:
    position = self._selected_position()
    if position is None or position == self.last_selected:
      return
    self.last_selected = position
    if self.retry is None and not self.busy:
      self.navigation.current.selected = max(0, position)
    item = self.rows[position].item if 0 <= position < len(self.rows) else None
    item = self.navigation.current.detail or item
    cast('xbmcgui.ControlImage', self.window.getControl(12)).setImage(
      self._image(item) if item else ''
    )
    cast('xbmcgui.ControlLabel', self.window.getControl(13)).setLabel(item.name if item else '')
    cast('xbmcgui.ControlTextBox', self.window.getControl(14)).setText(
      item.overview if item else ''
    )

  def _honour_front_request(self) -> None:
    """Re-show the window when another launch asks jelq to come forward."""
    if self.home is None or not self.home.getProperty(FRONT_PROPERTY):
      return
    self.home.clearProperty(FRONT_PROPERTY)
    # Showing an existing window makes Kodi run onInit again, which is the same
    # signal a skin reload gives; do not mistake this one for a rebuild.
    self.expect_reinit = True
    self._request_show()

  def _request_show(self) -> None:
    """
    Show the window, or arrange to once nothing is covering it.

    Showing while a modal dialog owns the screen is silently lost: the window
    never becomes active, and because the main window is `LOAD_ON_GUI_INIT` Kodi then
    never runs `onInit` on it, costing jelq the signal it needs for the next
    reload. Waiting also avoids taking focus from the dialog, which after a skin
    change is Kodi's own Keep skin? confirmation.
    """
    self.show_pending = True
    self._show_when_unobstructed()

  def _show_when_unobstructed(self) -> None:
    if not self.show_pending or xbmc.getCondVisibility(MODAL_DIALOG):
      return
    self.show_pending = False
    self.window.show()

  def _hold_claim(self) -> bool:
    """
    Refresh this instance's claim, and stand down if a newer one took over.

    An instance whose window is gone cannot be exited from the UI and ignores
    StopScript, because the loop only watches `abortRequested`. Yielding the
    claim means relaunching jelq reaps it, instead of the user needing to
    restart Kodi.
    """
    if self.home is None or not self.token:
      return True
    now = time.monotonic()
    if now < self.claim_due:
      return True
    if not holds_claim(self.home, self.token):
      event('Another jelq instance took over; stopping this one.')
      return False
    self.home.setProperty(ACTIVE_PROPERTY, _claim_text(self.token))
    self.claim_due = now + CLAIM_HEARTBEAT_SECONDS
    return True

  def _replace_window(self) -> None:
    """
    Swap in a fresh window after Kodi rebuilt this one.

    Kodi reloads the window XML and re-runs `onInit`, but the Python `Window`
    keeps its `vecControls` cache, so every wrapper still points at the controls
    the reload freed. Nothing in the Python API clears that cache, and touching
    any of those wrappers segfaults Kodi, so the only recovery is a new `Window`.
    Application state is untouched, so the rebuilt window re-renders in place.
    """
    replacement = ApplicationWindow(
      'script-jelq-main.xml', self.addon.getAddonInfo('path'), 'Default', '1080i'
    )
    replacement.commands = self.window.commands
    stale, self.window = self.window, replacement
    stale.close()
    self._request_show()
    event('Rebuilt the jelq window after a skin reload.')

  def _controls_live(self) -> bool:
    """
    Report whether this window's controls are safe to touch.

    Kodi's Python `Window` caches `Control` wrappers and never invalidates them
    (`Window::GetControlById` returns the cached entry), while the control
    methods dereference the cached raw `pGUIControl` behind only a null check.
    After a skin reload frees the window's controls every wrapper stays poisoned
    until the script restarts, so re-fetching the control does not help. The info
    manager resolves the container live instead, and reports nothing once the
    window is gone or no longer in front.
    """
    return bool(xbmc.getInfoLabel(f'Container({LIST}).NumItems'))

  def _selected_position(self) -> int | None:
    """
    Read the selection without touching a cached control wrapper.

    Kodi's Python `Window` caches `Control` wrappers and never invalidates them
    (`Window::GetControlById` returns the cached entry), while
    `ControlList::getSelectedPosition` dereferences the cached raw `pGUIControl`
    behind only a null check. After a skin reload frees the window's controls
    that pointer dangles, so every wrapper stays poisoned until the script
    restarts. Kodi's info manager resolves the container live instead, and
    reports nothing once the window is gone or no longer in front.
    """
    current = xbmc.getInfoLabel(f'Container({LIST}).CurrentItem')
    if not current:
      return None
    try:
      return int(current) - 1
    except ValueError:
      return None

  @staticmethod
  def _item_title(item: MediaItem) -> str:
    if item.type == 'Episode':
      return str(item.index_number) + '. ' + item.name
    if item.type == 'Season' and item.index_number == 0:
      return 'Specials'
    return item.name

  @staticmethod
  def _item_summary(item: MediaItem) -> str:
    values = []
    if item.year:
      values.append(str(item.year))
    if item.runtime_ticks:
      values.append(str(item.runtime_ticks // 600_000_000) + ' min')
    if item.position_ticks:
      values.append('In progress')
    elif item.played:
      values.append('Watched')
    if item.type == 'CollectionFolder':
      values.append(text(item.raw.get('CollectionType'), 'Library').capitalize())
    return ' · '.join(values)


def acquire_claim(home: xbmcgui.Window) -> str | None:
  """Claim the instance slot, preferring to surface whatever is already running."""
  token = claim_single_instance(home)
  if token is not None:
    return token
  if ask_running_instance_forward(home):
    return None
  if not xbmcgui.Dialog().yesno(
    'Restart jelq?',
    'jelq is already running but is not responding.',
    defaultbutton=xbmcgui.DLG_YESNO_YES_BTN,
  ):
    return None
  token = claim_single_instance(home, force=True)
  if token is not None:
    # Let the displaced instance notice and release its window first.
    xbmc.Monitor().waitForAbort(CLAIM_HEARTBEAT_SECONDS + 0.5)
  return token


def run() -> None:
  home = xbmcgui.Window(10000)
  token = acquire_claim(home)
  if token is None:
    return
  development: DevelopmentState | None = None
  window: ApplicationWindow | None = None
  try:
    if not activate_companion_skin(home):
      return
    development = DevelopmentState(home)
    development.start_application()
    addon = xbmcaddon.Addon()
    window = ApplicationWindow(
      'script-jelq-main.xml', addon.getAddonInfo('path'), 'Default', '1080i'
    )
    window.commands = queue.Queue()
    Application(addon, window, home=home, token=token).run()
  except Exception:  # noqa: BLE001 - Top-level Kodi boundary; never log secret-bearing exception objects.
    event('The application stopped unexpectedly.', error=True)
    xbmcgui.Dialog().ok('jelq', 'jelq stopped unexpectedly. You can launch it again from Kodi.')
  finally:
    # A superseded instance must not clear state the newer one now owns.
    if holds_claim(home, token):
      if development is not None:
        development.clear()
      home.clearProperty(ACTIVE_PROPERTY)
      home.clearProperty(PLAYING_PROPERTY)
    if window is not None:
      window.close()
