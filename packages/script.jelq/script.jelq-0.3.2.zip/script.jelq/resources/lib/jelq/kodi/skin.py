from __future__ import annotations

import json
import time
from dataclasses import dataclass
from typing import Callable

import xbmc
import xbmcaddon
import xbmcgui

from jelq.kodi.log import event

HOME_WINDOW_ID = 10000
SKIN_CONFIRMATION_DIALOG_ID = 10100
POLL_SECONDS = 0.05
# Long enough for a declined confirmation's revert to take effect before the
# caller re-reads the active skin.
SETTLE_SECONDS = 0.3
# How long the target skin must stay selected with no confirmation in sight
# before concluding Kodi is not going to ask.
CONFIRMATION_GRACE_SECONDS = 1.5
HOME_TIMEOUT_SECONDS = 2.0
SKIN_TIMEOUT_SECONDS = 20.0
ACTIVATION_PROPERTY = 'jelq.skin.activating'


def _always() -> bool:
  return True


@dataclass(frozen=True)
class CompanionSkin:
  identifier: str
  minimum_version: str
  applicable: Callable[[], bool] = _always


# Order is preference order. Future device variants belong here with an applicability predicate.
# Each minimum is a contract floor; skin.jelq's must match tools.package.COMPANION_SKIN_MIN_VERSION.
COMPATIBLE_SKINS = (CompanionSkin('skin.jelq', '0.3.2'),)


def activate_companion_skin(
  home: xbmcgui.Window,
  *,
  home_timeout: float = HOME_TIMEOUT_SECONDS,
  skin_timeout: float = SKIN_TIMEOUT_SECONDS,
) -> bool:
  active = compatible_active_skin()
  if active is not None:
    return True

  target = preferred_installed_skin()
  if target is None:
    xbmcgui.Dialog().ok(
      'jelq companion skin unavailable',
      'Install or update the jelq skin from the jelq repository, then launch jelq again.',
    )
    return False

  if home.getProperty(ACTIVATION_PROPERTY):
    xbmcgui.Dialog().notification('jelq', 'jelq is already activating its companion skin.')
    return False

  if not _confirm_switch():
    return False

  return _activate_installed_skin(home, target, home_timeout, skin_timeout)


def _confirm_switch() -> bool:
  """Ask before Kodi's own confirmation, which never says which skin it means."""
  return bool(
    xbmcgui.Dialog().yesno(
      'Switch skins?',
      'jelq requires its skin to run.',
      defaultbutton=xbmcgui.DLG_YESNO_YES_BTN,
    )
  )


def _activate_installed_skin(
  home: xbmcgui.Window,
  target: CompanionSkin,
  home_timeout: float,
  skin_timeout: float,
) -> bool:
  monitor = xbmc.Monitor()
  home.setProperty(ACTIVATION_PROPERTY, target.identifier)
  try:
    xbmc.executebuiltin('ActivateWindow(Home)')
    if not _wait_for_home(monitor, home_timeout):
      xbmcgui.Dialog().ok(
        'jelq could not switch skins',
        'Close open Kodi dialogs, return to Home, and launch jelq again.',
      )
      return False
    if not _request_skin(target.identifier):
      xbmcgui.Dialog().ok(
        'jelq could not switch skins',
        'Select a compatible jelq skin in Settings > Interface > Skin, then launch jelq again.',
      )
      return False
    if not _wait_for_skin_change(monitor, target.identifier, skin_timeout):
      return False
    return compatible_active_skin() is not None
  finally:
    home.clearProperty(ACTIVATION_PROPERTY)


def compatible_active_skin() -> CompanionSkin | None:
  active_identifier = xbmc.getSkinDir()
  return next(
    (skin for skin in _installed_compatible_skins() if skin.identifier == active_identifier),
    None,
  )


def preferred_installed_skin() -> CompanionSkin | None:
  return next(iter(_installed_compatible_skins()), None)


def _installed_compatible_skins() -> tuple[CompanionSkin, ...]:
  compatible = []
  for skin in COMPATIBLE_SKINS:
    if not skin.applicable():
      continue
    try:
      version = xbmcaddon.Addon(skin.identifier).getAddonInfo('version')
    except RuntimeError:
      continue
    if _version_at_least(version, skin.minimum_version):
      compatible.append(skin)
  return tuple(compatible)


def _request_skin(identifier: str) -> bool:
  request = {
    'jsonrpc': '2.0',
    'id': 1,
    'method': 'Settings.SetSettingValue',
    'params': {'setting': 'lookandfeel.skin', 'value': identifier},
  }
  try:
    response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
  except (RuntimeError, TypeError, ValueError):
    event('Kodi rejected the companion-skin activation request.', error=True)
    return False
  if response.get('result') is not True:
    event('Kodi did not accept the companion-skin activation request.', error=True)
    return False
  return True


def _wait_for_home(monitor: xbmc.Monitor, timeout: float) -> bool:
  deadline = time.monotonic() + timeout
  while time.monotonic() <= deadline and not monitor.abortRequested():
    if xbmcgui.getCurrentWindowId() == HOME_WINDOW_ID:
      return True
    monitor.waitForAbort(POLL_SECONDS)
  return False


def _wait_for_skin_change(
  monitor: xbmc.Monitor,
  target_identifier: str,
  timeout: float,
) -> bool:
  """
  Wait for Kodi's skin confirmation to resolve, by observing it.

  Kodi 21.3 announces neither `GUI.OnSkinUnloading` nor `GUI.OnSkinLoaded`, so
  there is nothing to await. Watch instead for the confirmation appearing and
  then closing, or for the target skin staying selected without one. An earlier
  version depended on those notifications and could only fall through a fixed
  timeout, which cost about ten seconds on every launch under another skin.
  """
  deadline = time.monotonic() + timeout
  confirmation_seen = False
  target_seen_at: float | None = None
  while time.monotonic() <= deadline and not monitor.abortRequested():
    if _skin_confirmation_open():
      confirmation_seen = True
    elif confirmation_seen:
      return _confirmation_settled(monitor)
    elif xbmc.getSkinDir() == target_identifier:
      now = time.monotonic()
      if target_seen_at is None:
        target_seen_at = now
      elif now - target_seen_at >= CONFIRMATION_GRACE_SECONDS:
        return _confirmation_settled(monitor)
    else:
      target_seen_at = None
    monitor.waitForAbort(POLL_SECONDS)
  return False


def _confirmation_settled(monitor: xbmc.Monitor) -> bool:
  """Let a revert from a declined confirmation land before reporting back."""
  if monitor.waitForAbort(SETTLE_SECONDS):
    return False
  return not _skin_confirmation_open()


def _skin_confirmation_open() -> bool:
  return (
    xbmc.getCondVisibility('Window.IsActive(yesnodialog)')
    or (xbmcgui.getCurrentWindowId() == SKIN_CONFIRMATION_DIALOG_ID)
    or (xbmcgui.getCurrentWindowDialogId() == SKIN_CONFIRMATION_DIALOG_ID)
  )


def _version_at_least(installed: str, required: str) -> bool:
  try:
    installed_parts = tuple(int(value) for value in installed.split('.'))
    required_parts = tuple(int(value) for value in required.split('.'))
  except ValueError:
    return False
  width = max(len(installed_parts), len(required_parts))
  return installed_parts + (0,) * (width - len(installed_parts)) >= required_parts + (0,) * (
    width - len(required_parts)
  )
