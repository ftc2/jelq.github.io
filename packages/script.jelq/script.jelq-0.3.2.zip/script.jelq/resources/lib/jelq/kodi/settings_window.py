"""Remote-first full-screen Settings controller."""

from __future__ import annotations

import queue
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import dataclass
from functools import partial
from typing import Callable, cast

import xbmc
import xbmcaddon
import xbmcgui

from jelq.client import ApiError, AuthError, JellyfinClient
from jelq.kodi.log import event
from jelq.kodi.settings import AddonSettings, KodiSettingsPage, open_kodi_settings
from jelq.preferences import (
  BITRATE_LIMITS_BPS,
  AccountScope,
  MediaSegmentType,
  NetworkContext,
  Preferences,
  SegmentPolicy,
  format_bitrate,
)
from jelq.server_settings import (
  SUBTITLE_MODE_LABELS,
  LanguageOption,
  ServerSettingsCache,
  SubtitleMode,
  UserConfiguration,
  UserSetting,
)

CATEGORIES = 300
ROWS = 301
HEADING = 302
IDENTITY = 303
STATUS = 304
HELP = 305
BACK_ACTIONS = {9, 10, 92}

POLICY_LABELS = {
  SegmentPolicy.AUTOMATIC: 'Automatically skip',
  SegmentPolicy.PROMPT: 'Ask to skip',
  SegmentPolicy.INACTIVE: 'Do nothing',
}


@dataclass(frozen=True)
class SettingsServerState:
  network_context: NetworkContext
  configuration: UserConfiguration
  languages: tuple[LanguageOption, ...]


@dataclass
class SettingRow:
  label: str
  value: str
  description: str
  action: Callable[[], None] | None
  server_setting: UserSetting | None = None


@dataclass(frozen=True)
class Category:
  name: str
  rows: Callable[[], list[SettingRow]]


class SettingsWindow(xbmcgui.WindowXML):
  commands: queue.Queue[tuple[str, int]]

  def onInit(self) -> None:  # noqa: N802 - Kodi callback name.
    self.commands.put(('ready', 0))

  def onClick(self, control_id: int) -> None:  # noqa: N802 - Kodi callback name.
    self.commands.put(('click', control_id))

  def onAction(self, action: xbmcgui.Action) -> None:  # noqa: N802 - Kodi callback name.
    if action.getId() in BACK_ACTIONS:
      self.commands.put(('back', 0))


class SettingsController:
  def __init__(  # noqa: PLR0913, PLR0917 - explicit authority/context dependencies.
    self,
    addon: xbmcaddon.Addon,
    window: SettingsWindow,
    client: JellyfinClient,
    scope: AccountScope,
    server_name: str,
    user_name: str,
    preferences: Preferences,
    persist_preferences: Callable[[], None],
    cache: ServerSettingsCache,
  ) -> None:
    self.window = window
    self.client = client
    self.scope = scope
    self.server_name = server_name
    self.user_name = user_name
    self.preferences = preferences
    self.persist_preferences = persist_preferences
    self.cache = cache
    self.addon_settings = AddonSettings(addon)
    self.monitor = xbmc.Monitor()
    self.workers = ThreadPoolExecutor(max_workers=2)
    self.load_future: Future[SettingsServerState] | None = None
    self.update_future: Future[UserConfiguration] | None = None
    self.pending_setting: UserSetting | None = None
    self._pending_retry: tuple[UserSetting, str | bool] | None = None
    self.retry_update: tuple[UserSetting, str | bool] | None = None
    self.configuration: UserConfiguration | None = None
    self.languages: tuple[LanguageOption, ...] = ()
    self.network_context = NetworkContext.REMOTE
    self.server_error = ''
    self.closed = False
    self.ready = False
    self.category_index = 0
    self.last_category_position = -1
    self.last_row_position = -1
    self.rows: list[SettingRow] = []
    self.categories = (
      Category('General', self._general_rows),
      Category('Playback', self._playback_rows),
      Category('Segment actions', self._segment_rows),
      Category('Episodes', self._episode_rows),
      Category('Kodi settings', self._kodi_rows),
      Category('Diagnostics', self._diagnostic_rows),
    )

  def run(self) -> None:
    self.window.show()
    try:
      while not self.closed and not self.monitor.abortRequested():
        self._commands()
        self._results()
        if self.ready:
          self._selection()
        self.monitor.waitForAbort(0.05)
    finally:
      self.closed = True
      if self.load_future is not None:
        self.load_future.cancel()
      if self.update_future is not None:
        self.update_future.cancel()
      self.workers.shutdown(wait=False)
      self.window.close()

  def _commands(self) -> None:
    while not self.window.commands.empty():
      kind, control_id = self.window.commands.get_nowait()
      if kind == 'ready' and not self.ready:
        self.ready = True
        cast('xbmcgui.ControlLabel', self.window.getControl(HEADING)).setLabel('Settings')
        cast('xbmcgui.ControlLabel', self.window.getControl(IDENTITY)).setLabel(
          self.server_name + ' · ' + self.user_name
        )
        self._render_categories()
        self._render_rows()
        self.window.setFocusId(CATEGORIES)
        self._start_load(refresh=False)
      elif kind == 'back':
        self.closed = True
      elif kind == 'click' and control_id == CATEGORIES:
        self._set_category(self._category_list().getSelectedPosition(), focus_rows=True)
      elif kind == 'click' and control_id == ROWS:
        position = self._row_list().getSelectedPosition()
        if 0 <= position < len(self.rows):
          action = self.rows[position].action
          if action is not None:
            action()

  def _selection(self) -> None:
    category_position = self._category_list().getSelectedPosition()
    if category_position != self.last_category_position:
      self.last_category_position = category_position
      self._set_category(category_position, focus_rows=False)
    row_position = self._row_list().getSelectedPosition()
    if row_position != self.last_row_position:
      self.last_row_position = row_position
      description = (
        self.rows[row_position].description if 0 <= row_position < len(self.rows) else ''
      )
      cast('xbmcgui.ControlTextBox', self.window.getControl(HELP)).setText(description)

  def _set_category(self, index: int, *, focus_rows: bool) -> None:
    if not 0 <= index < len(self.categories):
      return
    self.category_index = index
    self.last_row_position = -1
    self._render_rows()
    if focus_rows and self.rows:
      self.window.setFocusId(ROWS)

  def _start_load(self, *, refresh: bool) -> None:
    if self.load_future is not None or self.update_future is not None:
      return
    self.server_error = ''
    self.retry_update = None
    cast('xbmcgui.ControlLabel', self.window.getControl(STATUS)).setLabel(
      'Loading Jellyfin user settings…'
    )
    self._render_rows()
    self.load_future = self.workers.submit(self._load_server_state, refresh)

  def _load_server_state(
    self,
    refresh: bool,  # noqa: FBT001 - submitted background-job argument.
  ) -> SettingsServerState:
    try:
      context = (
        NetworkContext.IN_NETWORK if self.client.endpoint_is_in_network() else NetworkContext.REMOTE
      )
    except (ApiError, OSError, ValueError):
      context = NetworkContext.REMOTE
      event('Jellyfin endpoint classification was unavailable; using Internet quality.')
    configuration = self.cache.user_configuration(
      self.scope, self.client.user_configuration, refresh=refresh
    )
    languages = self.cache.languages(self.scope, self.client.language_options, refresh=refresh)
    return SettingsServerState(context, configuration, languages)

  def _start_update(
    self,
    setting: UserSetting,
    value: str | bool,  # noqa: FBT001 - typed value union.
  ) -> None:
    if self.update_future is not None or self.load_future is not None:
      return
    self.pending_setting = setting
    self.server_error = ''
    self.retry_update = None
    self._render_rows()
    self.update_future = self.workers.submit(self.client.update_user_setting, setting, value)

  def _results(self) -> None:  # noqa: C901 - explicit asynchronous result boundaries.
    if self.closed:
      return
    load = self.load_future
    if load is not None and load.done():
      self.load_future = None
      try:
        state = load.result()
      except (ApiError, AuthError, OSError, ValueError) as error:
        self.server_error = str(error)
        cast('xbmcgui.ControlLabel', self.window.getControl(STATUS)).setLabel(
          'Jellyfin settings unavailable · Select a server-owned row to retry'
        )
      except Exception:  # noqa: BLE001 - worker boundary; keep secrets out of logs.
        event('Loading Jellyfin user settings failed.', error=True)
        self.server_error = 'Jellyfin settings are unavailable.'
        cast('xbmcgui.ControlLabel', self.window.getControl(STATUS)).setLabel(
          'Jellyfin settings unavailable · Select a server-owned row to retry'
        )
      else:
        self.configuration = state.configuration
        self.languages = state.languages
        self.network_context = state.network_context
        self.server_error = ''
        cast('xbmcgui.ControlLabel', self.window.getControl(STATUS)).setLabel(
          'Current connection: '
          + ('Home network' if state.network_context is NetworkContext.IN_NETWORK else 'Internet')
        )
      self._render_rows()

    update = self.update_future
    if update is not None and update.done():
      setting = self.pending_setting
      retry = self.retry_update
      self.update_future = None
      self.pending_setting = None
      try:
        configuration = update.result()
      except (ApiError, AuthError, OSError, ValueError) as error:
        self.server_error = str(error)
        if setting is not None and retry is None:
          # The intended value is captured by _server_update before submission.
          retry = self._pending_retry
        self.retry_update = retry
        cast('xbmcgui.ControlLabel', self.window.getControl(STATUS)).setLabel(
          'Jellyfin did not save the change · Select a server-owned row to retry'
        )
      except Exception:  # noqa: BLE001 - worker boundary; keep secrets out of logs.
        event('Updating Jellyfin user settings failed.', error=True)
        self.server_error = 'Jellyfin did not save the change.'
        self.retry_update = self._pending_retry
      else:
        self.configuration = configuration
        self.cache.store_user_configuration(self.scope, configuration)
        self.retry_update = None
        self.server_error = ''
        cast('xbmcgui.ControlLabel', self.window.getControl(STATUS)).setLabel('Saved to Jellyfin')
      self._pending_retry = None
      self._render_rows()

  def _server_update(
    self,
    setting: UserSetting,
    value: str | bool,  # noqa: FBT001 - typed value union.
  ) -> None:
    self._pending_retry = (setting, value)
    self._start_update(setting, value)

  def _server_action(
    self, setting: UserSetting, action: Callable[[], None]
  ) -> Callable[[], None] | None:
    if self.pending_setting is not None:
      return None
    if self.server_error:
      if self.retry_update is not None and self.retry_update[0] is setting:
        return partial(self._server_update, *self.retry_update)
      return partial(self._start_load, refresh=True)
    return action if self.configuration is not None else partial(self._start_load, refresh=True)

  def _server_value(self, setting: UserSetting, confirmed: str) -> str:
    if self.pending_setting is setting:
      return 'Saving…'
    if self.server_error or self.configuration is None:
      return (confirmed + ' · ' if confirmed else '') + 'Unavailable · Retry'
    return confirmed

  def _render_categories(self) -> None:
    control = self._category_list()
    control.reset()
    for category in self.categories:
      control.addItem(xbmcgui.ListItem(label=category.name))
    control.selectItem(self.category_index)

  def _render_rows(self) -> None:
    self.rows = self.categories[self.category_index].rows()
    control = self._row_list()
    selected = max(0, control.getSelectedPosition())
    control.reset()
    for row in self.rows:
      item = xbmcgui.ListItem(label=row.label, label2=row.value)
      if row.action is None:
        item.setProperty('disabled', 'true')
      control.addItem(item)
    if self.rows:
      control.selectItem(min(selected, len(self.rows) - 1))
    self.last_row_position = -1

  def _general_rows(self) -> list[SettingRow]:
    enabled = self.addon_settings.launch_on_start
    return [
      SettingRow(
        'Launch on Kodi startup',
        _enabled(enabled),
        'Kodi stores this for the active Kodi profile. The native add-on settings dialog '
        'edits the same value.',
        partial(self._set_launch_on_start, not enabled),
      )
    ]

  def _playback_rows(self) -> list[SettingRow]:
    configuration = self.configuration
    audio = configuration.audio_language if configuration else ''
    subtitle = configuration.subtitle_language if configuration else ''
    mode = configuration.subtitle_mode if configuration else SubtitleMode.DEFAULT
    default_audio = configuration.play_default_audio if configuration else True
    return [
      self._quality_row('Home network quality', NetworkContext.IN_NETWORK),
      self._quality_row('Internet quality', NetworkContext.REMOTE),
      SettingRow(
        'Preferred audio language',
        self._server_value(UserSetting.AUDIO_LANGUAGE, self._language_name(audio)),
        'Stored in this Jellyfin user configuration and shared with other Jellyfin clients.',
        self._server_action(
          UserSetting.AUDIO_LANGUAGE,
          partial(self._select_language, UserSetting.AUDIO_LANGUAGE),
        ),
        UserSetting.AUDIO_LANGUAGE,
      ),
      SettingRow(
        'Play source-default audio regardless of language',
        self._server_value(UserSetting.PLAY_DEFAULT_AUDIO, _enabled(default_audio)),
        'Stored in this Jellyfin user configuration. A source-default track can take '
        'priority over the preferred language.',
        self._server_action(
          UserSetting.PLAY_DEFAULT_AUDIO,
          partial(self._server_update, UserSetting.PLAY_DEFAULT_AUDIO, not default_audio),
        ),
        UserSetting.PLAY_DEFAULT_AUDIO,
      ),
      SettingRow(
        'Preferred subtitle language',
        self._server_value(UserSetting.SUBTITLE_LANGUAGE, self._language_name(subtitle)),
        'Stored in this Jellyfin user configuration and shared with other Jellyfin clients.',
        self._server_action(
          UserSetting.SUBTITLE_LANGUAGE,
          partial(self._select_language, UserSetting.SUBTITLE_LANGUAGE),
        ),
        UserSetting.SUBTITLE_LANGUAGE,
      ),
      SettingRow(
        'Subtitle mode',
        self._server_value(UserSetting.SUBTITLE_MODE, SUBTITLE_MODE_LABELS[mode]),
        'Jellyfin uses this mode with the preferred subtitle language and stream metadata.',
        self._server_action(UserSetting.SUBTITLE_MODE, self._select_subtitle_mode),
        UserSetting.SUBTITLE_MODE,
      ),
    ]

  def _quality_row(self, label: str, context: NetworkContext) -> SettingRow:
    value = self.preferences.player.bitrate_limits.for_context(context)
    applicable = context is self.network_context and self.configuration is not None
    rendered = format_bitrate(value) + (' · Current connection' if applicable else '')
    return SettingRow(
      label,
      rendered,
      'This installation-local value caps Jellyfin negotiation for this connection '
      "profile. Unlimited removes jelq's selected cap; it does not promise Direct Play.",
      partial(self._select_quality, context),
    )

  def _segment_rows(self) -> list[SettingRow]:
    result = []
    for segment_type in MediaSegmentType:
      policy = self.preferences.player.media_segment_policy(self.scope, segment_type)
      result.append(
        SettingRow(
          segment_type.value,
          POLICY_LABELS[policy],
          'Stored only on this Kodi profile for this Jellyfin server and user.',
          partial(self._select_segment_policy, segment_type),
        )
      )
    return result

  def _episode_rows(self) -> list[SettingRow]:
    configuration = self.configuration
    autoplay = configuration.next_episode_autoplay if configuration else True
    return [
      SettingRow(
        'Play next episode automatically',
        self._server_value(UserSetting.NEXT_EPISODE_AUTOPLAY, _enabled(autoplay)),
        'Stored in this Jellyfin user configuration. Playback fetches a fresh value '
        'before deciding whether to advance.',
        self._server_action(
          UserSetting.NEXT_EPISODE_AUTOPLAY,
          partial(self._server_update, UserSetting.NEXT_EPISODE_AUTOPLAY, not autoplay),
        ),
        UserSetting.NEXT_EPISODE_AUTOPLAY,
      )
    ]

  def _kodi_rows(self) -> list[SettingRow]:
    return [
      SettingRow(
        'Caching',
        'Open Kodi Services / Caching',
        "Opens Kodi's native cache controls. jelq does not read or change those values.",
        partial(open_kodi_settings, KodiSettingsPage.CACHING),
      ),
      SettingRow(
        'Video playback',
        'Open Kodi Player / Videos',
        "Opens Kodi's native video playback controls without changing them.",
        partial(open_kodi_settings, KodiSettingsPage.VIDEO_PLAYBACK),
      ),
      SettingRow(
        'Audio output',
        'Open Kodi System / Audio',
        "Opens Kodi's native audio output controls without changing them.",
        partial(open_kodi_settings, KodiSettingsPage.AUDIO_OUTPUT),
      ),
    ]

  def _diagnostic_rows(self) -> list[SettingRow]:
    enabled = self.addon_settings.debug_logging
    return [
      SettingRow(
        'jelq debug logging',
        _enabled(enabled),
        "Adds jelq-specific diagnostic messages. Kodi's global debug setting is not changed.",
        partial(self._set_debug_logging, not enabled),
      )
    ]

  def _set_launch_on_start(self, enabled: bool) -> None:  # noqa: FBT001 - callback value.
    self.addon_settings.launch_on_start = enabled
    self._render_rows()

  def _set_debug_logging(self, enabled: bool) -> None:  # noqa: FBT001 - callback value.
    self.addon_settings.debug_logging = enabled
    self._render_rows()

  def _select_quality(self, context: NetworkContext) -> None:
    current = self.preferences.player.bitrate_limits.for_context(context)
    preselect = BITRATE_LIMITS_BPS.index(current) if current in BITRATE_LIMITS_BPS else 0
    selected = xbmcgui.Dialog().select(
      'Select quality limit',
      [format_bitrate(value) for value in BITRATE_LIMITS_BPS],
      preselect=preselect,
    )
    if 0 <= selected < len(BITRATE_LIMITS_BPS):
      self.preferences.player.set_bitrate_limit(context, BITRATE_LIMITS_BPS[selected])
      self.persist_preferences()
      self._render_rows()

  def _select_segment_policy(self, segment_type: MediaSegmentType) -> None:
    policies = tuple(SegmentPolicy)
    current = self.preferences.player.media_segment_policy(self.scope, segment_type)
    selected = xbmcgui.Dialog().select(
      segment_type.value + ' action',
      [POLICY_LABELS[value] for value in policies],
      preselect=policies.index(current),
    )
    if 0 <= selected < len(policies):
      self.preferences.player.set_media_segment_policy(self.scope, segment_type, policies[selected])
      self.persist_preferences()
      self._render_rows()

  def _language_choices(self, setting: UserSetting) -> tuple[LanguageOption, ...]:
    choices = [LanguageOption('No preference', '')]
    if setting is UserSetting.AUDIO_LANGUAGE:
      choices.append(LanguageOption('Original language', 'OriginalLanguage'))
    choices.extend(self.languages)
    current = ''
    if self.configuration is not None:
      current_value = self.configuration.value(setting)
      current = current_value if isinstance(current_value, str) else ''
    if current and all(option.value != current for option in choices):
      choices.insert(1, LanguageOption('Current server value (' + current + ')', current))
    deduplicated: dict[str, LanguageOption] = {}
    for option in choices:
      deduplicated.setdefault(option.value, option)
    return tuple(deduplicated.values())

  def _select_language(self, setting: UserSetting) -> None:
    if self.configuration is None:
      return
    choices = self._language_choices(setting)
    current = cast('str', self.configuration.value(setting))
    selected = xbmcgui.Dialog().select(
      'Select language',
      [choice.name for choice in choices],
      preselect=next((index for index, choice in enumerate(choices) if choice.value == current), 0),
    )
    if 0 <= selected < len(choices) and choices[selected].value != current:
      self._server_update(setting, choices[selected].value)

  def _select_subtitle_mode(self) -> None:
    if self.configuration is None:
      return
    modes = tuple(SubtitleMode)
    current = self.configuration.subtitle_mode
    selected = xbmcgui.Dialog().select(
      'Select subtitle mode',
      [SUBTITLE_MODE_LABELS[mode] for mode in modes],
      preselect=modes.index(current),
    )
    if 0 <= selected < len(modes) and modes[selected] is not current:
      self._server_update(UserSetting.SUBTITLE_MODE, modes[selected].value)

  def _language_name(self, value: str) -> str:
    if not value:
      return 'No preference'
    if value == 'OriginalLanguage':
      return 'Original language'
    return next((choice.name for choice in self.languages if choice.value == value), value)

  def _category_list(self) -> xbmcgui.ControlList:
    return cast('xbmcgui.ControlList', self.window.getControl(CATEGORIES))

  def _row_list(self) -> xbmcgui.ControlList:
    return cast('xbmcgui.ControlList', self.window.getControl(ROWS))


def _enabled(value: bool) -> str:  # noqa: FBT001 - formatter input.
  return 'Enabled' if value else 'Disabled'
