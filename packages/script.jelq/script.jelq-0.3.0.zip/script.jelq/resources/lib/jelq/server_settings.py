"""Typed Jellyfin-owned settings and their bounded in-memory session cache."""

# ruff: noqa: TRY004 - malformed server payloads are value errors at this boundary.

from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING, Any, Callable

if TYPE_CHECKING:
  from jelq.preferences import AccountScope

SERVER_SETTINGS_TTL_SECONDS = 60.0


class UserSetting(str, Enum):
  AUDIO_LANGUAGE = 'AudioLanguagePreference'
  PLAY_DEFAULT_AUDIO = 'PlayDefaultAudioTrack'
  SUBTITLE_LANGUAGE = 'SubtitleLanguagePreference'
  SUBTITLE_MODE = 'SubtitleMode'
  NEXT_EPISODE_AUTOPLAY = 'EnableNextEpisodeAutoPlay'


class SubtitleMode(str, Enum):
  NONE = 'None'
  DEFAULT = 'Default'
  SMART = 'Smart'
  ALWAYS = 'Always'
  ONLY_FORCED = 'OnlyForced'


SUBTITLE_MODE_LABELS = {
  SubtitleMode.NONE: 'Off',
  SubtitleMode.DEFAULT: 'Default',
  SubtitleMode.SMART: 'Smart',
  SubtitleMode.ALWAYS: 'Always play',
  SubtitleMode.ONLY_FORCED: 'Forced subtitles only',
}


@dataclass(frozen=True)
class LanguageOption:
  name: str
  value: str

  @classmethod
  def from_dict(cls, value: Any) -> LanguageOption:
    if not isinstance(value, dict):
      raise ValueError('The server returned an invalid language option.')
    name, code = value.get('Name'), value.get('Value')
    if not isinstance(name, str) or not name.strip() or not isinstance(code, str) or not code:
      raise ValueError('The server returned an invalid language option.')
    return cls(name, code)


@dataclass(frozen=True)
class UserConfiguration:
  audio_language: str = ''
  play_default_audio: bool = True
  subtitle_language: str = ''
  subtitle_mode: SubtitleMode = SubtitleMode.DEFAULT
  next_episode_autoplay: bool = True

  @classmethod
  def from_user(cls, user: Any) -> UserConfiguration:
    if not isinstance(user, dict):
      raise ValueError('The server returned invalid user settings.')
    raw = user.get('Configuration')
    if not isinstance(raw, dict):
      raise ValueError('The server returned invalid user settings.')
    return cls(
      audio_language=_optional_text(raw, UserSetting.AUDIO_LANGUAGE, ''),
      play_default_audio=_optional_bool(raw, UserSetting.PLAY_DEFAULT_AUDIO, True),
      subtitle_language=_optional_text(raw, UserSetting.SUBTITLE_LANGUAGE, ''),
      subtitle_mode=_optional_subtitle_mode(raw),
      next_episode_autoplay=_optional_bool(raw, UserSetting.NEXT_EPISODE_AUTOPLAY, True),
    )

  def value(self, setting: UserSetting) -> str | bool:
    if setting is UserSetting.AUDIO_LANGUAGE:
      return self.audio_language
    if setting is UserSetting.PLAY_DEFAULT_AUDIO:
      return self.play_default_audio
    if setting is UserSetting.SUBTITLE_LANGUAGE:
      return self.subtitle_language
    if setting is UserSetting.SUBTITLE_MODE:
      return self.subtitle_mode.value
    if setting is UserSetting.NEXT_EPISODE_AUTOPLAY:
      return self.next_episode_autoplay
    raise TypeError('Unsupported Jellyfin user setting.')


def _optional_text(raw: dict[str, Any], setting: UserSetting, default: str) -> str:
  value = raw.get(setting.value, default)
  if not isinstance(value, str):
    raise ValueError('The server returned invalid user settings.')
  return value


def _optional_bool(
  raw: dict[str, Any],
  setting: UserSetting,
  default: bool,  # noqa: FBT001 - server default.
) -> bool:
  value = raw.get(setting.value, default)
  if not isinstance(value, bool):
    raise ValueError('The server returned invalid user settings.')
  return value


def _optional_subtitle_mode(raw: dict[str, Any]) -> SubtitleMode:
  value = raw.get(UserSetting.SUBTITLE_MODE.value, SubtitleMode.DEFAULT.value)
  if not isinstance(value, str):
    raise ValueError('The server returned invalid user settings.')
  try:
    return SubtitleMode(value)
  except ValueError:
    raise ValueError('The server returned an unsupported subtitle mode.') from None


def validated_setting_value(setting: UserSetting, value: object) -> str | bool:
  """Validate an intended narrow update before touching the server payload."""
  if setting in {UserSetting.PLAY_DEFAULT_AUDIO, UserSetting.NEXT_EPISODE_AUTOPLAY}:
    if not isinstance(value, bool):
      raise TypeError('This Jellyfin user setting requires a boolean value.')
    return value
  if not isinstance(value, str):
    raise TypeError('This Jellyfin user setting requires text.')
  if setting is UserSetting.SUBTITLE_MODE:
    try:
      return SubtitleMode(value).value
    except ValueError:
      raise ValueError('The selected subtitle mode is unsupported.') from None
  return value


@dataclass(frozen=True)
class _ConfigurationEntry:
  expires_at: float
  value: UserConfiguration


@dataclass(frozen=True)
class _LanguageEntry:
  expires_at: float
  value: tuple[LanguageOption, ...]


class ServerSettingsCache:
  """One-minute, server/user/resource-keyed cache that never touches disk."""

  def __init__(
    self,
    ttl_seconds: float = SERVER_SETTINGS_TTL_SECONDS,
    *,
    clock: Callable[[], float] = time.monotonic,
  ) -> None:
    if ttl_seconds <= 0:
      raise ValueError('The server-setting cache lifetime must be positive.')
    self.ttl_seconds = ttl_seconds
    self.clock = clock
    self.lock = threading.Lock()
    self._configurations: dict[AccountScope, _ConfigurationEntry] = {}
    self._languages: dict[AccountScope, _LanguageEntry] = {}

  def user_configuration(
    self,
    scope: AccountScope,
    loader: Callable[[], UserConfiguration],
    *,
    refresh: bool = False,
  ) -> UserConfiguration:
    with self.lock:
      entry = self._configurations.get(scope)
      if not refresh and entry is not None and entry.expires_at > self.clock():
        return entry.value
    value = loader()
    self.store_user_configuration(scope, value)
    return value

  def store_user_configuration(self, scope: AccountScope, value: UserConfiguration) -> None:
    if not isinstance(value, UserConfiguration):
      raise TypeError('Cached user settings are invalid.')
    with self.lock:
      self._configurations[scope] = _ConfigurationEntry(self.clock() + self.ttl_seconds, value)

  def languages(
    self,
    scope: AccountScope,
    loader: Callable[[], tuple[LanguageOption, ...]],
    *,
    refresh: bool = False,
  ) -> tuple[LanguageOption, ...]:
    with self.lock:
      entry = self._languages.get(scope)
      if not refresh and entry is not None and entry.expires_at > self.clock():
        return entry.value
    value = loader()
    if not isinstance(value, tuple) or any(not isinstance(item, LanguageOption) for item in value):
      raise TypeError('Cached language choices are invalid.')
    with self.lock:
      self._languages[scope] = _LanguageEntry(self.clock() + self.ttl_seconds, value)
    return value

  def invalidate(self, scope: AccountScope) -> None:
    with self.lock:
      self._configurations.pop(scope, None)
      self._languages.pop(scope, None)
