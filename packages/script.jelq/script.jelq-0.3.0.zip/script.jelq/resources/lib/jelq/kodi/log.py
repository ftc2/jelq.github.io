from __future__ import annotations

import xbmc
import xbmcaddon

from jelq.kodi.settings import DEBUG_LOGGING_SETTING


def event(message: str, *, error: bool = False) -> None:
  """Log fixed diagnostic descriptions, never HTTP objects or user data."""
  xbmc.log('[jelq] ' + message, xbmc.LOGERROR if error else xbmc.LOGINFO)


def debug(message: str) -> None:
  """Emit optional jelq detail without changing Kodi's global debug setting."""
  try:
    enabled = xbmcaddon.Addon().getSettingBool(DEBUG_LOGGING_SETTING)
  except (AttributeError, RuntimeError):
    enabled = False
  if enabled:
    xbmc.log('[jelq] ' + message, xbmc.LOGDEBUG)
