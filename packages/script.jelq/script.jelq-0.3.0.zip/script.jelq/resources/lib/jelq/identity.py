"""Stable client identity shared by Jellyfin requests and release metadata tests."""

VERSION = '0.3.0'
USER_AGENT = 'jelq/' + VERSION
