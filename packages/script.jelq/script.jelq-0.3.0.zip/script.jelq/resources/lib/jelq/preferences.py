"""Versioned jelq preferences independent of Kodi storage and presentation."""

from __future__ import annotations

import json
from dataclasses import dataclass, field, replace
from enum import Enum
from typing import Any, cast

PREFERENCE_SCHEMA_VERSION = 1
MAX_STREAMING_BITRATE_BPS = 2_147_483_647
BITS_PER_MEGABIT = 1_000_000

# One authoritative ladder shared by Settings and the in-player selector.
BITRATE_LIMITS_BPS: tuple[int | None, ...] = (
  None,
  120_000_000,
  80_000_000,
  60_000_000,
  40_000_000,
  20_000_000,
  15_000_000,
  10_000_000,
  8_000_000,
  6_000_000,
  4_000_000,
  3_000_000,
  2_000_000,
  1_500_000,
  1_000_000,
  720_000,
  420_000,
)


class PreferenceFormatError(ValueError):
  """Saved preferences are malformed and must be preserved for recovery."""


class UnsupportedPreferenceVersionError(PreferenceFormatError):
  """Saved preferences require an unavailable migration or newer jelq version."""


class MediaSegmentType(str, Enum):
  INTRO = 'Intro'
  OUTRO = 'Outro'
  PREVIEW = 'Preview'
  RECAP = 'Recap'
  COMMERCIAL = 'Commercial'


class SegmentPolicy(str, Enum):
  AUTOMATIC = 'automatic'
  PROMPT = 'prompt'
  INACTIVE = 'inactive'


class NetworkContext(str, Enum):
  IN_NETWORK = 'in_network'
  REMOTE = 'remote'


def format_bitrate(bits_per_second: int | None) -> str:
  """Format a ladder value using consistent conventional bitrate units."""
  if bits_per_second is None:
    return 'Unlimited'
  if bits_per_second >= BITS_PER_MEGABIT:
    megabits = bits_per_second / BITS_PER_MEGABIT
    return f'{megabits:g} Mbps'
  return f'{bits_per_second // 1000} kbps'


def _policy(value: Any, path: str) -> SegmentPolicy:
  if not isinstance(value, str):
    message = f'{path} must be a MediaSegment policy name.'
    raise PreferenceFormatError(message)
  try:
    return SegmentPolicy(value)
  except ValueError:
    message = f'{path} contains an unsupported MediaSegment policy.'
    raise PreferenceFormatError(message) from None


def _bitrate(value: Any, path: str) -> int | None:
  if value is None:
    return None
  if (
    isinstance(value, bool)
    or not isinstance(value, int)
    or not 1 <= value <= MAX_STREAMING_BITRATE_BPS
  ):
    message = (
      f'{path} must be null or a bitrate from 1 through '
      f'{MAX_STREAMING_BITRATE_BPS} bits per second.'
    )
    raise PreferenceFormatError(message)
  return cast('int', value)


def _object(value: Any, path: str) -> dict[str, Any]:
  if not isinstance(value, dict) or any(not isinstance(key, str) for key in value):
    message = f'{path} must be a JSON object.'
    raise PreferenceFormatError(message)
  return value


def _array(value: Any, path: str) -> list[Any]:
  if not isinstance(value, list):
    message = f'{path} must be a JSON array.'
    raise PreferenceFormatError(message)
  return value


def _exact_keys(data: dict[str, Any], expected: frozenset[str], path: str) -> None:
  keys = frozenset(data)
  if keys == expected:
    return
  missing = sorted(expected - keys)
  unknown = sorted(keys - expected)
  details = []
  if missing:
    details.append('missing ' + ', '.join(missing))
  if unknown:
    details.append('unknown ' + ', '.join(unknown))
  message = f'{path} has invalid fields ({"; ".join(details)}).'
  raise PreferenceFormatError(message)


def _identity(value: Any, path: str) -> str:
  if not isinstance(value, str) or not value.strip():
    message = f'{path} must be non-empty text.'
    raise PreferenceFormatError(message)
  return value


@dataclass(frozen=True)
class AccountScope:
  """Stable non-secret Jellyfin server and user identity."""

  server_id: str
  user_id: str

  def __post_init__(self) -> None:
    _identity(self.server_id, 'Server identifier')
    _identity(self.user_id, 'User identifier')


@dataclass(frozen=True)
class MediaSegmentPolicies:
  """Per-type defaults; unknown server types are always inactive."""

  intro: SegmentPolicy = SegmentPolicy.AUTOMATIC
  outro: SegmentPolicy = SegmentPolicy.AUTOMATIC
  preview: SegmentPolicy = SegmentPolicy.PROMPT
  recap: SegmentPolicy = SegmentPolicy.PROMPT
  commercial: SegmentPolicy = SegmentPolicy.PROMPT

  def __post_init__(self) -> None:
    if any(
      not isinstance(value, SegmentPolicy)
      for value in (self.intro, self.outro, self.preview, self.recap, self.commercial)
    ):
      raise TypeError('MediaSegment policy values must be SegmentPolicy members.')

  def for_type(self, segment_type: object) -> SegmentPolicy:
    try:
      known_type = MediaSegmentType(segment_type)
    except (TypeError, ValueError):
      return SegmentPolicy.INACTIVE
    if known_type is MediaSegmentType.INTRO:
      return self.intro
    if known_type is MediaSegmentType.OUTRO:
      return self.outro
    if known_type is MediaSegmentType.PREVIEW:
      return self.preview
    if known_type is MediaSegmentType.RECAP:
      return self.recap
    return self.commercial

  def with_policy(
    self, segment_type: MediaSegmentType, policy: SegmentPolicy
  ) -> MediaSegmentPolicies:
    if not isinstance(segment_type, MediaSegmentType):
      raise TypeError('Only supported MediaSegment types can be configured.')
    if not isinstance(policy, SegmentPolicy):
      raise TypeError('MediaSegment policy is invalid.')
    return replace(self, **{segment_type.value.lower(): policy})

  def to_dict(self) -> dict[str, str]:
    return {
      MediaSegmentType.INTRO.value: self.intro.value,
      MediaSegmentType.OUTRO.value: self.outro.value,
      MediaSegmentType.PREVIEW.value: self.preview.value,
      MediaSegmentType.RECAP.value: self.recap.value,
      MediaSegmentType.COMMERCIAL.value: self.commercial.value,
    }

  @classmethod
  def from_dict(cls, value: Any, path: str = 'MediaSegment policies') -> MediaSegmentPolicies:
    data = _object(value, path)
    expected = frozenset(segment_type.value for segment_type in MediaSegmentType)
    _exact_keys(data, expected, path)
    return cls(
      intro=_policy(data[MediaSegmentType.INTRO.value], f'{path}.Intro'),
      outro=_policy(data[MediaSegmentType.OUTRO.value], f'{path}.Outro'),
      preview=_policy(data[MediaSegmentType.PREVIEW.value], f'{path}.Preview'),
      recap=_policy(data[MediaSegmentType.RECAP.value], f'{path}.Recap'),
      commercial=_policy(data[MediaSegmentType.COMMERCIAL.value], f'{path}.Commercial'),
    )


@dataclass(frozen=True)
class AccountPlayerPreferences:
  media_segments: MediaSegmentPolicies = field(default_factory=MediaSegmentPolicies)

  def __post_init__(self) -> None:
    if not isinstance(self.media_segments, MediaSegmentPolicies):
      raise TypeError('Account MediaSegment preferences are invalid.')


@dataclass(frozen=True)
class BitrateLimits:
  """Installation-local limits; None means no jelq-selected limit."""

  in_network_bps: int | None = None
  remote_bps: int | None = None

  def __post_init__(self) -> None:
    _bitrate(self.in_network_bps, 'Home-network bitrate limit')
    _bitrate(self.remote_bps, 'Internet bitrate limit')

  def for_context(self, context: NetworkContext) -> int | None:
    if context is NetworkContext.IN_NETWORK:
      return self.in_network_bps
    if context is NetworkContext.REMOTE:
      return self.remote_bps
    raise TypeError('Network context is invalid.')

  def with_limit(self, context: NetworkContext, bits_per_second: int | None) -> BitrateLimits:
    limit = _bitrate(bits_per_second, 'Bitrate limit')
    if context is NetworkContext.IN_NETWORK:
      return replace(self, in_network_bps=limit)
    if context is NetworkContext.REMOTE:
      return replace(self, remote_bps=limit)
    raise TypeError('Network context is invalid.')

  def to_dict(self) -> dict[str, int | None]:
    return {'in_network_bps': self.in_network_bps, 'remote_bps': self.remote_bps}

  @classmethod
  def from_dict(cls, value: Any) -> BitrateLimits:
    data = _object(value, 'Bitrate limits')
    _exact_keys(data, frozenset({'in_network_bps', 'remote_bps'}), 'Bitrate limits')
    return cls(
      in_network_bps=_bitrate(data['in_network_bps'], 'Bitrate limits.in_network_bps'),
      remote_bps=_bitrate(data['remote_bps'], 'Bitrate limits.remote_bps'),
    )


@dataclass
class PlayerPreferences:
  """Typed player subsection of the application preference root."""

  bitrate_limits: BitrateLimits = field(default_factory=BitrateLimits)
  _accounts: dict[AccountScope, AccountPlayerPreferences] = field(default_factory=dict, repr=False)

  def __post_init__(self) -> None:
    if not isinstance(self.bitrate_limits, BitrateLimits):
      raise TypeError('Bitrate-limit preferences are invalid.')
    if any(
      not isinstance(scope, AccountScope) or not isinstance(preferences, AccountPlayerPreferences)
      for scope, preferences in self._accounts.items()
    ):
      raise TypeError('Account-scoped player preferences are invalid.')
    self._accounts = dict(self._accounts)

  @property
  def account_scopes(self) -> tuple[AccountScope, ...]:
    return tuple(sorted(self._accounts, key=lambda scope: (scope.server_id, scope.user_id)))

  def for_account(self, scope: AccountScope) -> AccountPlayerPreferences:
    if not isinstance(scope, AccountScope):
      raise TypeError('Account scope is invalid.')
    return self._accounts.get(scope, AccountPlayerPreferences())

  def media_segment_policy(self, scope: AccountScope, segment_type: object) -> SegmentPolicy:
    return self.for_account(scope).media_segments.for_type(segment_type)

  def set_media_segment_policy(
    self, scope: AccountScope, segment_type: MediaSegmentType, policy: SegmentPolicy
  ) -> None:
    current = self.for_account(scope)
    self._accounts[scope] = AccountPlayerPreferences(
      current.media_segments.with_policy(segment_type, policy)
    )

  def set_bitrate_limit(self, context: NetworkContext, bits_per_second: int | None) -> None:
    self.bitrate_limits = self.bitrate_limits.with_limit(context, bits_per_second)

  def to_dict(self) -> dict[str, Any]:
    accounts = []
    for scope in self.account_scopes:
      account = self._accounts[scope]
      accounts.append(
        {
          'server_id': scope.server_id,
          'user_id': scope.user_id,
          'media_segments': account.media_segments.to_dict(),
        }
      )
    return {'bitrate_limits': self.bitrate_limits.to_dict(), 'accounts': accounts}

  @classmethod
  def from_dict(cls, value: Any) -> PlayerPreferences:
    data = _object(value, 'Player preferences')
    _exact_keys(data, frozenset({'bitrate_limits', 'accounts'}), 'Player preferences')
    limits = BitrateLimits.from_dict(data['bitrate_limits'])
    accounts: dict[AccountScope, AccountPlayerPreferences] = {}
    for index, raw_record in enumerate(_array(data['accounts'], 'Player preferences.accounts')):
      path = f'Player preferences.accounts[{index}]'
      record = _object(raw_record, path)
      _exact_keys(record, frozenset({'server_id', 'user_id', 'media_segments'}), path)
      scope = AccountScope(
        _identity(record['server_id'], f'{path}.server_id'),
        _identity(record['user_id'], f'{path}.user_id'),
      )
      if scope in accounts:
        message = f'{path} duplicates an existing account scope.'
        raise PreferenceFormatError(message)
      accounts[scope] = AccountPlayerPreferences(
        MediaSegmentPolicies.from_dict(record['media_segments'], f'{path}.media_segments')
      )
    return cls(limits, accounts)


def migrate_preferences_payload(value: Any) -> dict[str, Any]:
  """Validate the root schema boundary where sequential future migrations belong."""
  data = _object(value, 'Preferences')
  version = data.get('version')
  if isinstance(version, bool) or not isinstance(version, int):
    raise PreferenceFormatError('Preferences require an integer schema version.')
  if version != PREFERENCE_SCHEMA_VERSION:
    direction = 'newer' if version > PREFERENCE_SCHEMA_VERSION else 'older'
    message = f'The {direction} preference format is unsupported; the original file is preserved.'
    raise UnsupportedPreferenceVersionError(message)
  return dict(data)


@dataclass
class Preferences:
  """Versioned application preference root persisted as preferences.json."""

  player: PlayerPreferences = field(default_factory=PlayerPreferences)

  def __post_init__(self) -> None:
    if not isinstance(self.player, PlayerPreferences):
      raise TypeError('Player preferences are invalid.')

  def to_dict(self) -> dict[str, Any]:
    return {'version': PREFERENCE_SCHEMA_VERSION, 'player': self.player.to_dict()}

  def to_json(self) -> str:
    return json.dumps(self.to_dict(), ensure_ascii=False, separators=(',', ':'), sort_keys=True)

  @classmethod
  def from_dict(cls, value: Any) -> Preferences:
    data = migrate_preferences_payload(value)
    _exact_keys(data, frozenset({'version', 'player'}), 'Preferences')
    return cls(PlayerPreferences.from_dict(data['player']))

  @classmethod
  def from_json(cls, value: str) -> Preferences:
    if not isinstance(value, str):
      raise TypeError('Serialized preferences must be text.')
    if not value.strip():
      return cls()
    try:
      data: Any = json.loads(value)
    except (TypeError, ValueError) as error:
      raise PreferenceFormatError(
        'Preferences could not be read; the original file is preserved.'
      ) from error
    return cls.from_dict(data)
