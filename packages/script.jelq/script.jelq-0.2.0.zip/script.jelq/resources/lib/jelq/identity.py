"""Stable client identity shared by Jellyfin requests and release metadata tests."""

VERSION = '0.2.0'
USER_AGENT = 'jelq/' + VERSION
