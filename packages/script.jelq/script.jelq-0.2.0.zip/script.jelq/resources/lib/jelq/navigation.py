from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
  from jelq.models import MediaItem


@dataclass
class Screen:
  kind: str
  title: str
  parent_id: str = ''
  series_id: str = ''
  item_type: str = ''
  items: list[MediaItem] = field(default_factory=list)
  selected: int = 0
  total: int = 0
  loaded: bool = False
  detail: MediaItem | None = None

  @property
  def has_more(self) -> bool:
    return len(self.items) < self.total


class Navigation:
  """Keep screen state and reject work from another navigation or session."""

  def __init__(self) -> None:
    self.screens: list[Screen] = []
    self.generation = 0

  @property
  def current(self) -> Screen:
    return self.screens[-1]

  def reset(self, screen: Screen) -> None:
    self.generation += 1
    self.screens = [screen]

  def push(self, screen: Screen) -> None:
    self.generation += 1
    self.screens.append(screen)

  def back(self) -> bool:
    if len(self.screens) <= 1:
      return False
    self.generation += 1
    self.screens.pop()
    return True
