"""Pure presentation helpers for the jelq-owned video player."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Mapping, Sequence

from jelq.models import TICKS_PER_SECOND, Chapter, Segment, integer, text

BITS_PER_MEGABIT = 1_000_000


@dataclass(frozen=True)
class PlaybackBadge:
  label: str
  tone: str


@dataclass(frozen=True)
class StreamChoice:
  server_index: int
  kodi_index: int
  label: str
  badges: tuple[str, ...]
  selected: bool = False
  off: bool = False


@dataclass(frozen=True)
class DiagnosticRow:
  label: str
  value: str


def format_time(ticks: int, *, signed_remaining: bool = False) -> str:
  seconds = max(0, ticks // TICKS_PER_SECOND)
  hours, remainder = divmod(seconds, 3600)
  minutes, seconds = divmod(remainder, 60)
  value = f'{hours}:{minutes:02d}:{seconds:02d}' if hours else f'{minutes}:{seconds:02d}'
  return '−' + value if signed_remaining else value  # noqa: RUF001 - typographic minus.


def percentage(ticks: int, duration_ticks: int) -> float:
  if duration_ticks <= 0:
    return 0.0
  return min(100.0, max(0.0, ticks * 100.0 / duration_ticks))


def range_string(ranges: Iterable[tuple[int, int]], duration_ticks: int) -> str:
  values = []
  for start, end in ranges:
    left = percentage(start, duration_ticks)
    right = percentage(end, duration_ticks)
    if right > left:
      values.append(f'{left:.4f},{right:.4f}')
  return ','.join(values)


def chapter_ranges(chapter_ticks: Iterable[int], duration_ticks: int) -> str:
  """Return narrow but non-zero ranges suitable for Kodi's ranges control."""
  # One eighth of a percent is about 2.24 pixels on the 1792-pixel 1080p rail,
  # keeping every marker thin while avoiding subpixel ranges.
  width = max(1, duration_ticks // 800)
  return range_string(
    ((tick, min(duration_ticks, tick + width)) for tick in chapter_ticks), duration_ticks
  )


def chapter_preview(chapters: Sequence[Chapter], ticks: int) -> Chapter | None:
  """Choose the image for the chapter containing a pending seek target."""
  active = None
  for chapter in sorted(chapters, key=lambda value: value.start_ticks):
    if chapter.start_ticks > ticks:
      break
    active = chapter
  return active if active is not None and active.has_image else None


def segment_rows(segments: Sequence[Segment]) -> tuple[tuple[Segment, ...], tuple[Segment, ...]]:
  """Lay segments into at most two stable rows; union pathological overflow in row two."""
  rows: list[list[Segment]] = [[], []]
  ends = [-1, -1]
  overflow: list[Segment] = []
  for segment in sorted(
    segments, key=lambda value: (value.start_ticks, value.end_ticks, value.type)
  ):
    row = next((index for index, end in enumerate(ends) if segment.start_ticks >= end), None)
    if row is None:
      overflow.append(segment)
      continue
    rows[row].append(segment)
    ends[row] = segment.end_ticks
  if overflow:
    combined = sorted([*rows[1], *overflow], key=lambda value: (value.start_ticks, value.end_ticks))
    merged: list[Segment] = []
    for segment in combined:
      if merged and segment.start_ticks <= merged[-1].end_ticks:
        previous = merged[-1]
        merged[-1] = Segment(
          previous.start_ticks, max(previous.end_ticks, segment.end_ticks), 'Multiple'
        )
      else:
        merged.append(segment)
    rows[1] = merged
  return tuple(rows[0]), tuple(rows[1])


def segments_at(segments: Iterable[Segment], ticks: int) -> tuple[Segment, ...]:
  return tuple(segment for segment in segments if segment.contains(ticks))


def playback_badge(  # noqa: PLR0911 - branches mirror the product states.
  method: str, transcoding: dict[str, Any] | None = None
) -> PlaybackBadge | None:
  if method in {'DirectPlay', 'DirectStream'}:
    return PlaybackBadge('Direct Play', 'good')
  if method != 'Transcode':
    return None
  info = transcoding if isinstance(transcoding, dict) else {}
  video = info.get('IsVideoDirect')
  audio = info.get('IsAudioDirect')
  if not isinstance(video, bool) or not isinstance(audio, bool):
    return PlaybackBadge('Transcode', 'bad')
  if video and audio:
    return PlaybackBadge('Remux', 'good')
  if video:
    return PlaybackBadge('Audio Transcode', 'warn')
  if audio:
    return PlaybackBadge('Video Transcode', 'bad')
  return PlaybackBadge('Full Transcode', 'bad')


def _safe_diagnostic(value: Any, default: str = 'Unavailable') -> str:
  if not isinstance(value, (str, int, float)) or isinstance(value, bool):
    return default
  result = ' '.join(str(value).split())[:240]
  unsafe = ('://', 'authorization', 'apikey', 'api_key', 'password', 'token=')
  return default if not result or any(marker in result.casefold() for marker in unsafe) else result


def _bitrate(value: Any) -> str:
  bitrate = integer(value)
  if bitrate <= 0:
    return ''
  return (
    f'{bitrate / BITS_PER_MEGABIT:.1f} Mbps'
    if bitrate >= BITS_PER_MEGABIT
    else f'{round(bitrate / 1000)} Kbps'
  )


def _selected_stream(source: Mapping[str, Any], kind: str, selected_index: int) -> dict[str, Any]:
  streams = source.get('MediaStreams')
  if not isinstance(streams, list):
    return {}
  candidates = [value for value in streams if isinstance(value, dict) and value.get('Type') == kind]
  return next(
    (value for value in candidates if integer(value.get('Index'), -1) == selected_index),
    candidates[0] if candidates else {},
  )


def _video_diagnostic(stream: Mapping[str, Any]) -> str:
  resolution = ''
  width, height = integer(stream.get('Width')), integer(stream.get('Height'))
  if width > 0 and height > 0:
    resolution = f'{width}×{height}'  # noqa: RUF001 - standard resolution notation.
  frame_rate = stream.get('RealFrameRate', stream.get('AverageFrameRate'))
  values = (
    text(stream.get('Codec')).upper(),
    text(stream.get('Profile')),
    'Level ' + _safe_diagnostic(stream.get('Level'), '') if stream.get('Level') is not None else '',
    resolution,
    _safe_diagnostic(frame_rate, '') + ' fps' if frame_rate else '',
    str(integer(stream.get('BitDepth'))) + '-bit' if integer(stream.get('BitDepth')) > 0 else '',
    text(stream.get('VideoRangeType')) or text(stream.get('VideoRange')),
    text(stream.get('ColorSpace')),
    text(stream.get('ColorTransfer')),
    text(stream.get('ColorPrimaries')),
    _bitrate(stream.get('BitRate')),
  )
  return ' · '.join(_safe_diagnostic(value, '') for value in values if value) or 'Unavailable'


def _audio_diagnostic(stream: Mapping[str, Any]) -> str:
  channels = integer(stream.get('Channels'))
  sample_rate = integer(stream.get('SampleRate'))
  values = (
    text(stream.get('Codec')).upper(),
    text(stream.get('Profile')),
    text(stream.get('ChannelLayout')) or (str(channels) + ' ch' if channels > 0 else ''),
    f'{sample_rate / 1000:.1f} kHz' if sample_rate > 0 else '',
    text(stream.get('Language')),
    _bitrate(stream.get('BitRate')),
  )
  return ' · '.join(_safe_diagnostic(value, '') for value in values if value) or 'Unavailable'


def diagnostic_rows(  # noqa: PLR0913 - explicit whitelisted diagnostics contract.
  *,
  method: str,
  playback_info: Mapping[str, Any],
  source: Mapping[str, Any],
  session_id: str,
  position_ticks: int,
  duration_ticks: int,
  paused: bool,
  audio_index: int = -1,
  subtitle_index: int = -1,
  subtitle_enabled: bool = False,
  kodi: Mapping[str, Any] | None = None,
) -> tuple[DiagnosticRow, ...]:
  """Build a strict allow-list of useful, secret-safe runtime diagnostics."""
  transcoding = playback_info.get('TranscodingInfo')
  transcode_info = transcoding if isinstance(transcoding, dict) else {}
  badge = playback_badge(method, transcode_info)
  reasons = transcode_info.get('TranscodeReasons', source.get('TranscodeReasons'))
  if isinstance(reasons, list):
    safe_reasons = tuple(_safe_diagnostic(value, '') for value in reasons if value)
    reason = ', '.join(value for value in safe_reasons if value)
  else:
    reason = _safe_diagnostic(reasons, '')
  video = _selected_stream(source, 'Video', -1)
  audio = _selected_stream(source, 'Audio', audio_index)
  subtitle = _selected_stream(source, 'Subtitle', subtitle_index) if subtitle_enabled else {}
  subtitle_value = 'Off'
  if subtitle:
    subtitle_value = (
      ' · '.join(
        value
        for value in (
          _safe_diagnostic(text(subtitle.get('Codec')).upper(), ''),
          _safe_diagnostic(text(subtitle.get('Language')), ''),
        )
        if value
      )
      or 'Enabled'
    )
  rows = [
    DiagnosticRow('Playback', badge.label if badge is not None else 'Unavailable'),
    DiagnosticRow('Transcoding reason', reason or 'None reported'),
    DiagnosticRow('Media source', _safe_diagnostic(source.get('Id'))),
    DiagnosticRow('Container', _safe_diagnostic(source.get('Container'))),
    DiagnosticRow('Video', _video_diagnostic(video)),
    DiagnosticRow('Audio', _audio_diagnostic(audio)),
    DiagnosticRow('Subtitle', subtitle_value),
    DiagnosticRow(
      'Selected streams',
      'Audio {} · Subtitle {}'.format(
        audio_index if audio_index >= 0 else 'default',
        subtitle_index if subtitle_enabled and subtitle_index >= 0 else 'off',
      ),
    ),
    DiagnosticRow(
      'Position',
      f'{format_time(position_ticks)} / {format_time(duration_ticks)}',
    ),
    DiagnosticRow('Play session', _safe_diagnostic(session_id)),
    DiagnosticRow('Kodi state', 'Paused' if paused else 'Playing'),
  ]
  runtime = kodi or {}
  for key, label in (
    ('cache_level', 'Cache level'),
    ('video_decoder', 'Video decoder'),
    ('audio_decoder', 'Audio decoder'),
    ('pixel_format', 'Pixel format'),
  ):
    value = _safe_diagnostic(runtime.get(key), '')
    if value:
      rows.append(DiagnosticRow(label, value))
  return tuple(rows)


def _language(stream: dict[str, Any]) -> str:
  return text(stream.get('Language'), 'und') or 'und'


def _badges(stream: dict[str, Any], suggested: int) -> tuple[str, ...]:
  values = []
  if stream.get('IsDefault') is True:
    values.append('Default')
  if stream.get('IsForced') is True:
    values.append('Forced')
  if stream.get('IsHearingImpaired') is True:
    values.append('SDH')
  if stream.get('IsExternal') is True:
    values.append('External')
  if integer(stream.get('Index'), -1) == suggested:
    values.append('Suggested')
  return tuple(values)


def audio_choices(
  streams: Sequence[dict[str, Any]], suggested: int = -1, selected_kodi: int = -1
) -> tuple[StreamChoice, ...]:
  choices = []
  for kodi_index, stream in enumerate(streams):
    values = [_language(stream)]
    title = text(stream.get('Title'))
    codec = text(stream.get('Codec')).upper()
    layout = text(stream.get('ChannelLayout'))
    channels = integer(stream.get('Channels'))
    if title:
      values.append(title)
    if codec:
      values.append(codec)
    if layout:
      values.append(layout)
    elif channels:
      values.append(str(channels) + ' ch')
    choices.append(
      StreamChoice(
        integer(stream.get('Index'), -1),
        kodi_index,
        ' · '.join(values),
        _badges(stream, suggested),
        kodi_index == selected_kodi,
      )
    )
  return tuple(choices)


def subtitle_choices(
  streams: Sequence[dict[str, Any]],
  suggested: int = -1,
  selected_kodi: int = -1,
  enabled: bool = False,  # noqa: FBT001, FBT002 - mirrors Kodi's subtitle state.
) -> tuple[StreamChoice, ...]:
  ordered = sorted(
    enumerate(streams),
    key=lambda value: (
      not bool(value[1].get('IsExternal')),
      not bool(value[1].get('IsForced')),
      not bool(value[1].get('IsDefault')),
      integer(value[1].get('Index'), value[0]),
    ),
  )
  choices = [StreamChoice(-1, -1, 'Off', (), not enabled, True)]
  for kodi_index, stream in ordered:
    values = [_language(stream)]
    title = text(stream.get('Title'))
    codec = text(stream.get('Codec')).upper()
    if title:
      values.append(title)
    if codec:
      values.append(codec)
    choices.append(
      StreamChoice(
        integer(stream.get('Index'), -1),
        kodi_index,
        ' · '.join(values),
        _badges(stream, suggested),
        enabled and kodi_index == selected_kodi,
      )
    )
  return tuple(choices)


def semantic_stream_key(stream: dict[str, Any]) -> tuple[str, str, str, int, bool, bool]:
  """Match streams across episodes without assuming stable numeric indices."""
  return (
    _language(stream).lower(),
    text(stream.get('Title')).strip().casefold(),
    text(stream.get('Codec')).lower(),
    integer(stream.get('Channels')),
    stream.get('IsForced') is True,
    stream.get('IsHearingImpaired') is True,
  )


def matching_stream_index(
  source: dict[str, Any], candidates: Sequence[dict[str, Any]]
) -> int | None:
  key = semantic_stream_key(source)
  exact = next(
    (
      integer(candidate.get('Index'), -1)
      for candidate in candidates
      if semantic_stream_key(candidate) == key
    ),
    None,
  )
  if exact is not None and exact >= 0:
    return exact
  language = key[0]
  fallback = next(
    (
      integer(candidate.get('Index'), -1)
      for candidate in candidates
      if _language(candidate).lower() == language
    ),
    None,
  )
  return fallback if fallback is not None and fallback >= 0 else None
