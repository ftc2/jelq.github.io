from __future__ import annotations

import xbmc


def event(message: str, *, error: bool = False) -> None:
  """Log fixed diagnostic descriptions, never HTTP objects or user data."""
  xbmc.log('[jelq] ' + message, xbmc.LOGERROR if error else xbmc.LOGINFO)
