"""Kodi adapters; domain modules have no dependency on this package."""
