from __future__ import annotations

import json
import threading
from uuid import uuid4

import xbmcvfs

from jelq.accounts import AccountStore
from jelq.player_preferences import PlayerPreferences, UnsupportedPreferenceVersionError


class UnsupportedProfileError(ValueError):
  """A newer profile must not be replaced with an older backup."""


class ProfileStorage:
  """Save only in Kodi's profile, with a recoverable previous version."""

  def __init__(self, profile: str) -> None:
    self.profile = profile.rstrip('/') + '/'
    self.path = self.profile + 'accounts.json'
    self.lock = threading.Lock()

  def read(self) -> str:
    with self.lock:
      found = False
      for path in (self.path, self.path + '.bak'):
        if xbmcvfs.exists(path):
          found = True
          try:
            return self._read_valid(path)
          except UnsupportedProfileError:
            raise
          except (OSError, ValueError):
            continue
      if found:
        raise ValueError('Saved accounts could not be read. The original profile is preserved.')
    return ''

  @staticmethod
  def _read_valid(path: str) -> str:
    with xbmcvfs.File(path) as handle:
      content = handle.read()
    if not content.strip():
      raise ValueError('The saved-account file is empty.')
    data = json.loads(content)
    if isinstance(data, dict) and 'version' in data and data['version'] != 1:
      raise UnsupportedProfileError(
        'Unsupported saved-account format. The original profile is preserved.'
      )
    AccountStore.from_json(content)
    return content

  def _preserve_current(self) -> str | None:
    if not xbmcvfs.exists(self.path):
      return None
    try:
      self._read_valid(self.path)
    except UnsupportedProfileError:
      raise
    except (OSError, ValueError):
      # Retain the damaged original without replacing a usable recovery copy.
      previous = self.path + '.invalid-' + uuid4().hex
    else:
      previous = self.path + '.bak'
      if xbmcvfs.exists(previous) and not xbmcvfs.delete(previous):
        raise OSError('Could not update the saved-account backup.')
    if not xbmcvfs.rename(self.path, previous):
      raise OSError('Could not preserve the previous account settings.')
    return previous

  def write(self, content: str) -> None:
    with self.lock:
      if not content.strip():
        raise ValueError('Cannot save empty account settings.')
      AccountStore.from_json(content)
      if not xbmcvfs.mkdirs(self.profile) and not xbmcvfs.exists(self.profile):
        raise OSError('Could not create the account settings directory.')
      temporary = self.path + '.tmp'
      with xbmcvfs.File(temporary, 'w') as handle:
        if not handle.write(content):
          raise OSError('Could not save the account settings.')
      if self._read_valid(temporary) != content:
        raise OSError('Could not verify the saved account settings.')
      previous = self._preserve_current()
      if not xbmcvfs.rename(temporary, self.path):
        if previous:
          xbmcvfs.rename(previous, self.path)
        raise OSError('Could not finish saving the account settings.')


class PlayerPreferenceStorage:
  """Recoverable storage for the versioned, non-secret player preference model."""

  def __init__(self, profile: str) -> None:
    self.profile = profile.rstrip('/') + '/'
    self.path = self.profile + 'player_preferences.json'
    self.lock = threading.Lock()

  @staticmethod
  def _read_valid(path: str) -> str:
    with xbmcvfs.File(path) as handle:
      content = handle.read()
    if not content.strip():
      raise ValueError('The player-preference file is empty.')
    PlayerPreferences.from_json(content)
    return content

  def read(self) -> str:
    with self.lock:
      found = False
      for path in (self.path, self.path + '.bak'):
        if not xbmcvfs.exists(path):
          continue
        found = True
        try:
          return self._read_valid(path)
        except UnsupportedPreferenceVersionError:
          raise
        except (OSError, ValueError):
          continue
      if found:
        raise ValueError(
          'Saved player preferences could not be read. The original file is preserved.'
        )
    return ''

  def _preserve_current(self) -> str | None:
    if not xbmcvfs.exists(self.path):
      return None
    try:
      self._read_valid(self.path)
    except UnsupportedPreferenceVersionError:
      raise
    except (OSError, ValueError):
      previous = self.path + '.invalid-' + uuid4().hex
    else:
      previous = self.path + '.bak'
      if xbmcvfs.exists(previous) and not xbmcvfs.delete(previous):
        raise OSError('Could not update the player-preference backup.')
    if not xbmcvfs.rename(self.path, previous):
      raise OSError('Could not preserve previous player preferences.')
    return previous

  def write(self, content: str) -> None:
    with self.lock:
      PlayerPreferences.from_json(content)
      if not xbmcvfs.mkdirs(self.profile) and not xbmcvfs.exists(self.profile):
        raise OSError('Could not create the player-preference directory.')
      temporary = self.path + '.tmp'
      with xbmcvfs.File(temporary, 'w') as handle:
        if not handle.write(content):
          raise OSError('Could not save player preferences.')
      if self._read_valid(temporary) != content:
        raise OSError('Could not verify saved player preferences.')
      previous = self._preserve_current()
      if not xbmcvfs.rename(temporary, self.path):
        if previous:
          xbmcvfs.rename(previous, self.path)
        raise OSError('Could not finish saving player preferences.')
