"""Kodi VFS cache adapter for cropped trickplay preview frames."""

from __future__ import annotations

from hashlib import sha256
from uuid import uuid4

import xbmcvfs

from jelq.client import ApiError, JellyfinClient
from jelq.trickplay import TrickplayFrame, crop_trickplay_frame

PREVIEW_DIRECTORY = 'special://temp/jelq/trickplay/'


def new_trickplay_cache_scope() -> str:
  """Return an opaque scope for one player session's temporary previews."""
  return uuid4().hex


def load_trickplay_preview(
  client: JellyfinClient,
  frame: TrickplayFrame,
  cache_scope: str,
) -> str:
  """Fetch, crop, and atomically cache one preview off Kodi's UI thread."""
  if not cache_scope:
    raise ValueError('A player-session cache scope is required.')
  identity = sha256((cache_scope + ':' + frame.key).encode('utf-8')).hexdigest()
  path = PREVIEW_DIRECTORY + identity + '.jpg'
  if xbmcvfs.exists(path):
    return path
  content = client.download_image(frame.url)
  preview = crop_trickplay_frame(content, frame)
  if not xbmcvfs.mkdirs(PREVIEW_DIRECTORY) and not xbmcvfs.exists(PREVIEW_DIRECTORY):
    raise ApiError('Kodi could not create the trickplay preview cache.')
  temporary = path + '.tmp-' + uuid4().hex
  try:
    with xbmcvfs.File(temporary, 'w') as handle:
      if not handle.write(preview):
        raise ApiError('Kodi could not cache the trickplay preview.')
    if not xbmcvfs.rename(temporary, path):
      if xbmcvfs.exists(path):
        return path
      raise ApiError('Kodi could not finish caching the trickplay preview.')
  finally:
    if xbmcvfs.exists(temporary):
      xbmcvfs.delete(temporary)
  return path


def remove_trickplay_previews(paths: set[str]) -> None:
  """Best-effort cleanup of previews created for the closing player session."""
  for path in paths:
    if path.startswith(PREVIEW_DIRECTORY):
      xbmcvfs.delete(path)
