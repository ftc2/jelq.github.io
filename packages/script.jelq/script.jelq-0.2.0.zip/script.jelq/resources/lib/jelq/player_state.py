"""Pure player state and interaction transitions, independent of Kodi."""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from enum import Enum, IntEnum
from typing import Iterable


class InvalidPlayerTransitionError(ValueError):
  """The requested transition would violate the player state model."""


class PlaybackPhase(str, Enum):
  PREPARING = 'preparing'
  BUFFERING = 'buffering'
  PLAYING = 'playing'
  PAUSED = 'paused'
  TRANSITIONING = 'transitioning'
  COMPLETING = 'completing'
  FAILED = 'failed'
  EXITING = 'exiting'


class PlaybackIntent(str, Enum):
  PLAYING = 'playing'
  PAUSED = 'paused'


class PlayerSurface(str, Enum):
  """Player-owned surfaces; CLEAN is represented by an empty surface stack."""

  CLEAN = 'clean'
  SOSD = 'sosd'
  MAIN_OSD = 'main_osd'
  AUDIO = 'audio'
  SUBTITLES = 'subtitles'
  CHAPTERS = 'chapters'
  EPISODES = 'episodes'
  PLAYER_MENU = 'player_menu'
  QUALITY = 'quality'
  SUBTITLE_OFFSET = 'subtitle_offset'
  NERD_STATS = 'nerd_stats'
  SEGMENT_PROMPT = 'segment_prompt'
  UP_NEXT = 'up_next'


class SeekOrigin(str, Enum):
  SOSD = 'sosd'
  MAIN_OSD = 'main_osd'


class SeekDisposition(str, Enum):
  COMMIT = 'commit'
  CANCEL = 'cancel'
  ABORT_TO_MAIN_OSD = 'abort_to_main_osd'


class BackAction(str, Enum):
  CANCEL_SEEK = 'cancel_seek'
  CLOSE_LAYER = 'close_layer'
  HIDE_MAIN_OSD = 'hide_main_osd'
  EXIT_PLAYER = 'exit_player'
  IGNORED = 'ignored'


class PlayerEventKind(str, Enum):
  """Kinds used to arbitrate events collected during one controller turn."""

  POSITION_UPDATE = 'position_update'
  CONTEXTUAL_PROMPT = 'contextual_prompt'
  TIMER = 'timer'
  USER_INPUT = 'user_input'
  PLAYBACK_STATE = 'playback_state'
  NATURAL_COMPLETION = 'natural_completion'
  ITEM_REPLACEMENT = 'item_replacement'
  FAILURE = 'failure'
  EXIT = 'exit'


class EventPriority(IntEnum):
  """Higher values win when queued events would produce conflicting transitions."""

  POSITION_UPDATE = 10
  CONTEXTUAL_PROMPT = 20
  TIMER = 30
  PLAYBACK_STATE = 40
  USER_INPUT = 50
  NATURAL_COMPLETION = 60
  ITEM_REPLACEMENT = 70
  FAILURE = 80
  EXIT = 90


_EVENT_PRIORITIES = {
  PlayerEventKind.POSITION_UPDATE: EventPriority.POSITION_UPDATE,
  PlayerEventKind.CONTEXTUAL_PROMPT: EventPriority.CONTEXTUAL_PROMPT,
  PlayerEventKind.TIMER: EventPriority.TIMER,
  PlayerEventKind.USER_INPUT: EventPriority.USER_INPUT,
  PlayerEventKind.PLAYBACK_STATE: EventPriority.PLAYBACK_STATE,
  PlayerEventKind.NATURAL_COMPLETION: EventPriority.NATURAL_COMPLETION,
  PlayerEventKind.ITEM_REPLACEMENT: EventPriority.ITEM_REPLACEMENT,
  PlayerEventKind.FAILURE: EventPriority.FAILURE,
  PlayerEventKind.EXIT: EventPriority.EXIT,
}


def event_priority(event: PlayerEventKind) -> EventPriority:
  """Return the documented priority for an event kind."""
  return _EVENT_PRIORITIES[event]


def highest_priority_event(events: Iterable[PlayerEventKind]) -> PlayerEventKind:
  """Choose the first highest-priority event, preserving arrival order on ties."""
  iterator = iter(events)
  try:
    selected = next(iterator)
  except StopIteration:
    raise ValueError('At least one player event is required.') from None
  for event in iterator:
    if event_priority(event) > event_priority(selected):
      selected = event
  return selected


def _ticks(value: int, name: str) -> int:
  if isinstance(value, bool) or not isinstance(value, int):
    message = f'{name} must be an integer number of Jellyfin ticks.'
    raise TypeError(message)
  return value


def clamp_position(position_ticks: int, duration_ticks: int) -> int:
  """Clamp a position to the inclusive playable range."""
  position = _ticks(position_ticks, 'Position')
  duration = _ticks(duration_ticks, 'Duration')
  if duration < 0:
    raise ValueError('Duration must not be negative.')
  return min(max(position, 0), duration)


@dataclass(frozen=True)
class PendingSeek:
  start_ticks: int
  target_ticks: int
  duration_ticks: int
  resume_intent: PlaybackIntent
  origin: SeekOrigin

  def __post_init__(self) -> None:
    start = clamp_position(self.start_ticks, self.duration_ticks)
    target = clamp_position(self.target_ticks, self.duration_ticks)
    if start != self.start_ticks or target != self.target_ticks:
      raise ValueError('Pending seek positions must already be clamped.')
    if not isinstance(self.resume_intent, PlaybackIntent):
      raise TypeError('Pending seek resume intent is invalid.')
    if not isinstance(self.origin, SeekOrigin):
      raise TypeError('Pending seek origin is invalid.')

  def adjusted(self, delta_ticks: int) -> PendingSeek:
    delta = _ticks(delta_ticks, 'Seek adjustment')
    target = clamp_position(self.target_ticks + delta, self.duration_ticks)
    return replace(self, target_ticks=target)


@dataclass(frozen=True)
class ResolvedSeek:
  disposition: SeekDisposition
  position_ticks: int
  resume_intent: PlaybackIntent


@dataclass(frozen=True)
class BackResult:
  action: BackAction
  closed_surface: PlayerSurface | None = None
  seek: ResolvedSeek | None = None


_INTERACTIVE_PHASES = frozenset(
  {PlaybackPhase.BUFFERING, PlaybackPhase.PLAYING, PlaybackPhase.PAUSED}
)
_CONTEXTUAL_SURFACES = frozenset({PlayerSurface.SEGMENT_PROMPT, PlayerSurface.UP_NEXT})
_CLEAN_BACK_SURFACES = frozenset({PlayerSurface.SEGMENT_PROMPT})
_PANEL_CHILDREN = {
  PlayerSurface.MAIN_OSD: frozenset(
    {
      PlayerSurface.AUDIO,
      PlayerSurface.SUBTITLES,
      PlayerSurface.CHAPTERS,
      PlayerSurface.EPISODES,
      PlayerSurface.PLAYER_MENU,
      PlayerSurface.NERD_STATS,
    }
  ),
  PlayerSurface.PLAYER_MENU: frozenset({PlayerSurface.QUALITY, PlayerSurface.SUBTITLE_OFFSET}),
}
_ALLOWED_PHASE_TRANSITIONS = {
  PlaybackPhase.PREPARING: frozenset(
    {
      PlaybackPhase.BUFFERING,
      PlaybackPhase.PLAYING,
      PlaybackPhase.PAUSED,
      PlaybackPhase.FAILED,
      PlaybackPhase.EXITING,
    }
  ),
  PlaybackPhase.BUFFERING: frozenset(
    {
      PlaybackPhase.PLAYING,
      PlaybackPhase.PAUSED,
      PlaybackPhase.TRANSITIONING,
      PlaybackPhase.COMPLETING,
      PlaybackPhase.FAILED,
      PlaybackPhase.EXITING,
    }
  ),
  PlaybackPhase.PLAYING: frozenset(
    {
      PlaybackPhase.BUFFERING,
      PlaybackPhase.PAUSED,
      PlaybackPhase.TRANSITIONING,
      PlaybackPhase.COMPLETING,
      PlaybackPhase.FAILED,
      PlaybackPhase.EXITING,
    }
  ),
  PlaybackPhase.PAUSED: frozenset(
    {
      PlaybackPhase.BUFFERING,
      PlaybackPhase.PLAYING,
      PlaybackPhase.TRANSITIONING,
      PlaybackPhase.COMPLETING,
      PlaybackPhase.FAILED,
      PlaybackPhase.EXITING,
    }
  ),
  PlaybackPhase.TRANSITIONING: frozenset(
    {
      PlaybackPhase.PREPARING,
      PlaybackPhase.BUFFERING,
      PlaybackPhase.PLAYING,
      PlaybackPhase.PAUSED,
      PlaybackPhase.FAILED,
      PlaybackPhase.EXITING,
    }
  ),
  PlaybackPhase.COMPLETING: frozenset(
    {PlaybackPhase.TRANSITIONING, PlaybackPhase.FAILED, PlaybackPhase.EXITING}
  ),
  PlaybackPhase.FAILED: frozenset({PlaybackPhase.EXITING}),
  PlaybackPhase.EXITING: frozenset(),
}


@dataclass
class PlayerState:
  """State for one visible, jelq-owned playback session."""

  phase: PlaybackPhase = PlaybackPhase.PREPARING
  playback_intent: PlaybackIntent = PlaybackIntent.PLAYING
  pending_seek: PendingSeek | None = None
  _surface_stack: tuple[PlayerSurface, ...] = field(default_factory=tuple, repr=False)

  def __post_init__(self) -> None:
    self._assert_invariants()

  @property
  def surface_stack(self) -> tuple[PlayerSurface, ...]:
    return self._surface_stack

  @property
  def visible_surface(self) -> PlayerSurface:
    if not self._surface_stack:
      return PlayerSurface.CLEAN
    return self._surface_stack[-1]

  @property
  def is_interactive(self) -> bool:
    return self.phase in _INTERACTIVE_PHASES

  def change_phase(self, phase: PlaybackPhase) -> None:
    if not isinstance(phase, PlaybackPhase):
      raise TypeError('Playback phase is invalid.')
    if phase == self.phase:
      return
    if phase not in _ALLOWED_PHASE_TRANSITIONS[self.phase]:
      message = f'Cannot change playback from {self.phase} to {phase}.'
      raise InvalidPlayerTransitionError(message)
    self.phase = phase
    if phase is PlaybackPhase.PLAYING:
      self.playback_intent = PlaybackIntent.PLAYING
    elif phase is PlaybackPhase.PAUSED:
      self.playback_intent = PlaybackIntent.PAUSED
    if phase not in _INTERACTIVE_PHASES:
      self.pending_seek = None
      self._surface_stack = ()
    self._assert_invariants()

  def toggle_play_pause(self) -> PlaybackIntent:
    if not self.is_interactive or self.pending_seek is not None:
      raise InvalidPlayerTransitionError('Play/Pause cannot toggle in the current player state.')
    if self.playback_intent is PlaybackIntent.PLAYING:
      self.playback_intent = PlaybackIntent.PAUSED
      if self.phase is PlaybackPhase.PLAYING:
        self.phase = PlaybackPhase.PAUSED
    else:
      self.playback_intent = PlaybackIntent.PLAYING
      if self.phase is PlaybackPhase.PAUSED:
        self.phase = PlaybackPhase.PLAYING
    self._assert_invariants()
    return self.playback_intent

  def open_main_osd(self) -> ResolvedSeek | None:
    self._require_interactive()
    if len(self._surface_stack) > 1:
      raise InvalidPlayerTransitionError(
        'A nested panel must handle directional navigation itself.'
      )
    resolved = None
    if self.pending_seek is not None:
      resolved = self._resolve_seek(SeekDisposition.ABORT_TO_MAIN_OSD)
    self._surface_stack = (PlayerSurface.MAIN_OSD,)
    self._assert_invariants()
    return resolved

  def return_to_main_osd(self) -> ResolvedSeek | None:
    """
    Close contextual or nested UI and leave the main OSD visible.

    Controller transactions such as a stream replacement intentionally collapse
    all child panels at once. User Back navigation still uses :meth:`back` and
    unwinds exactly one layer.
    """
    self._require_interactive()
    resolved = None
    if self.pending_seek is not None:
      resolved = self._resolve_seek(SeekDisposition.ABORT_TO_MAIN_OSD)
    self._surface_stack = (PlayerSurface.MAIN_OSD,)
    self._assert_invariants()
    return resolved

  def hide_surfaces(self) -> ResolvedSeek | None:
    """Return to the clean frame without changing the playback phase."""
    self._require_interactive()
    resolved = None
    if self.pending_seek is not None:
      resolved = self._resolve_seek(SeekDisposition.CANCEL)
    self._surface_stack = ()
    self._assert_invariants()
    return resolved

  def push_panel(self, surface: PlayerSurface) -> None:
    self._require_interactive()
    if self.pending_seek is not None:
      raise InvalidPlayerTransitionError('Resolve the pending seek before opening a panel.')
    if not self._surface_stack:
      raise InvalidPlayerTransitionError('Panels require the main OSD.')
    parent = self._surface_stack[-1]
    if surface not in _PANEL_CHILDREN.get(parent, frozenset()):
      message = f'{surface} cannot be opened from {parent}.'
      raise InvalidPlayerTransitionError(message)
    self._surface_stack += (surface,)
    self._assert_invariants()

  def show_contextual_prompt(self, surface: PlayerSurface) -> bool:
    """Show a prompt only over the clean player; visible user UI wins otherwise."""
    self._require_interactive()
    if surface not in _CONTEXTUAL_SURFACES:
      raise ValueError('Only contextual prompt surfaces can be shown this way.')
    if self._surface_stack or self.pending_seek is not None:
      return False
    self._surface_stack = (surface,)
    self._assert_invariants()
    return True

  def dismiss_contextual_prompt(self) -> bool:
    if self.visible_surface not in _CONTEXTUAL_SURFACES:
      return False
    self._surface_stack = ()
    self._assert_invariants()
    return True

  def start_seek(self, position_ticks: int, duration_ticks: int) -> PendingSeek:
    self._require_interactive()
    if self.pending_seek is not None:
      raise InvalidPlayerTransitionError('A seek is already pending.')
    duration = _ticks(duration_ticks, 'Duration')
    start = clamp_position(position_ticks, duration)
    if not self._surface_stack or self.visible_surface in _CONTEXTUAL_SURFACES:
      origin = SeekOrigin.SOSD
      self._surface_stack = (PlayerSurface.SOSD,)
    elif self._surface_stack == (PlayerSurface.MAIN_OSD,):
      origin = SeekOrigin.MAIN_OSD
    else:
      raise InvalidPlayerTransitionError('Seeking cannot begin from this player surface.')
    self.pending_seek = PendingSeek(start, start, duration, self.playback_intent, origin)
    self._assert_invariants()
    return self.pending_seek

  def adjust_seek(self, delta_ticks: int) -> PendingSeek:
    pending = self._require_pending_seek()
    self.pending_seek = pending.adjusted(delta_ticks)
    self._assert_invariants()
    return self.pending_seek

  def commit_seek(self) -> ResolvedSeek:
    resolved = self._resolve_seek(SeekDisposition.COMMIT)
    self._assert_invariants()
    return resolved

  def cancel_seek(self) -> ResolvedSeek:
    resolved = self._resolve_seek(SeekDisposition.CANCEL)
    self._assert_invariants()
    return resolved

  def abort_seek_to_main_osd(self) -> ResolvedSeek:
    resolved = self._resolve_seek(SeekDisposition.ABORT_TO_MAIN_OSD)
    self._surface_stack = (PlayerSurface.MAIN_OSD,)
    self._assert_invariants()
    return resolved

  def back(self) -> BackResult:
    """Unwind exactly one player-owned layer, or exit from the clean player."""
    if self.phase is PlaybackPhase.EXITING:
      return BackResult(BackAction.IGNORED)
    if self.pending_seek is not None:
      resolved = self.cancel_seek()
      return BackResult(BackAction.CANCEL_SEEK, seek=resolved)
    if self.visible_surface in _CLEAN_BACK_SURFACES or not self._surface_stack:
      self.change_phase(PlaybackPhase.EXITING)
      return BackResult(BackAction.EXIT_PLAYER)
    closed = self._surface_stack[-1]
    self._surface_stack = self._surface_stack[:-1]
    self._assert_invariants()
    if closed is PlayerSurface.MAIN_OSD:
      return BackResult(BackAction.HIDE_MAIN_OSD, closed_surface=closed)
    return BackResult(BackAction.CLOSE_LAYER, closed_surface=closed)

  def _resolve_seek(self, disposition: SeekDisposition) -> ResolvedSeek:
    pending = self._require_pending_seek()
    position = (
      pending.target_ticks if disposition is SeekDisposition.COMMIT else pending.start_ticks
    )
    resolved = ResolvedSeek(disposition, position, pending.resume_intent)
    self.pending_seek = None
    if pending.origin is SeekOrigin.SOSD:
      self._surface_stack = ()
    return resolved

  def _require_interactive(self) -> None:
    if not self.is_interactive:
      raise InvalidPlayerTransitionError('The player is not in an interactive playback phase.')

  def _require_pending_seek(self) -> PendingSeek:
    if self.pending_seek is None:
      raise InvalidPlayerTransitionError('There is no pending seek.')
    return self.pending_seek

  def _assert_invariants(self) -> None:
    if not isinstance(self.phase, PlaybackPhase):
      raise TypeError('Playback phase is invalid.')
    if not isinstance(self.playback_intent, PlaybackIntent):
      raise TypeError('Playback intent is invalid.')
    if any(not isinstance(surface, PlayerSurface) for surface in self._surface_stack):
      raise TypeError('Player surface stack is invalid.')
    if PlayerSurface.CLEAN in self._surface_stack:
      raise InvalidPlayerTransitionError(
        'The clean player is represented by an empty surface stack.'
      )
    if self.phase not in _INTERACTIVE_PHASES and (self._surface_stack or self.pending_seek):
      raise InvalidPlayerTransitionError('Non-interactive playback phases cannot own visible UI.')
    self._assert_surface_invariants()
    self._assert_seek_invariants()

  def _assert_surface_invariants(self) -> None:
    if self._surface_stack and self._surface_stack[0] is PlayerSurface.MAIN_OSD:
      for parent, child in zip(self._surface_stack, self._surface_stack[1:]):
        if child not in _PANEL_CHILDREN.get(parent, frozenset()):
          raise InvalidPlayerTransitionError('The player panel stack has an invalid parent.')
    elif len(self._surface_stack) > 1:
      raise InvalidPlayerTransitionError('Only the main OSD can own nested surfaces.')
    elif self._surface_stack and self.visible_surface not in (
      PlayerSurface.SOSD,
      *_CONTEXTUAL_SURFACES,
    ):
      raise InvalidPlayerTransitionError('A player panel cannot exist without the main OSD.')

  def _assert_seek_invariants(self) -> None:
    if self.pending_seek is None:
      if self.visible_surface is PlayerSurface.SOSD:
        raise InvalidPlayerTransitionError('The SOSD requires a pending seek.')
      return
    if not isinstance(self.pending_seek, PendingSeek):
      raise TypeError('Pending seek state is invalid.')
    if self.pending_seek.origin is SeekOrigin.SOSD:
      if self._surface_stack != (PlayerSurface.SOSD,):
        raise InvalidPlayerTransitionError('An SOSD seek requires the SOSD to be the only surface.')
    elif self._surface_stack != (PlayerSurface.MAIN_OSD,):
      raise InvalidPlayerTransitionError('A main-OSD seek cannot coexist with a nested panel.')
