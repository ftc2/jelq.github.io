"""Small Jellyfin value objects independent of Kodi."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

TICKS_PER_SECOND = 10_000_000


def integer(value: Any, default: int = 0) -> int:
  """Read optional server integers without accepting booleans or crashing on null."""
  if isinstance(value, bool):
    return default
  try:
    return int(value)
  except (TypeError, ValueError, OverflowError):
    return default


def text(value: Any, default: str = '') -> str:
  return value if isinstance(value, str) else default


def user_autoplay_enabled(user: dict[str, Any]) -> bool:
  """Read Jellyfin's server-owned autoplay preference without coercing malformed values."""
  configuration = user.get('Configuration')
  if not isinstance(configuration, dict):
    return True
  enabled = configuration.get('EnableNextEpisodeAutoPlay')
  return enabled if isinstance(enabled, bool) else True


@dataclass(frozen=True)
class Chapter:
  start_ticks: int
  name: str = ''
  image_tag: str = ''
  index: int = 0
  image_path: str = field(default='', repr=False)

  @property
  def has_image(self) -> bool:
    return bool(self.image_tag or self.image_path)

  @classmethod
  def from_dict(cls, data: dict[str, Any], index: int = 0) -> Chapter | None:
    start = integer(data.get('StartPositionTicks'), -1)
    if start < 0 or isinstance(index, bool) or index < 0:
      return None
    return cls(
      start_ticks=start,
      name=text(data.get('Name')),
      image_tag=text(data.get('ImageTag')),
      index=index,
      image_path=text(data.get('ImagePath')),
    )


@dataclass(frozen=True)
class MediaItem:
  id: str
  name: str
  type: str
  overview: str = ''
  runtime_ticks: int = 0
  position_ticks: int = 0
  played: bool = False
  image_tags: dict[str, str] = field(default_factory=dict, repr=False)
  parent_id: str = ''
  series_id: str = ''
  season_id: str = ''
  index_number: int = 0
  parent_index_number: int = 0
  year: int = 0
  series_name: str = ''
  media_sources: tuple[dict[str, Any], ...] = field(default_factory=tuple, repr=False)
  raw: dict[str, Any] = field(default_factory=dict, repr=False, compare=False)
  chapters: tuple[Chapter, ...] = field(default_factory=tuple)
  trickplay: dict[str, dict[str, Any]] = field(default_factory=dict, repr=False)

  @classmethod
  def from_dict(cls, data: dict[str, Any]) -> MediaItem:
    item_id = text(data.get('Id'))
    if not item_id:
      raise ValueError('The server returned an item without an identifier.')
    user_data = data.get('UserData') or {}
    if not isinstance(user_data, dict):
      user_data = {}
    tags = data.get('ImageTags') or {}
    if not isinstance(tags, dict):
      tags = {}
    sources = data.get('MediaSources') or []
    if not isinstance(sources, list):
      sources = []
    raw_chapters = data.get('Chapters') or []
    if not isinstance(raw_chapters, list):
      raw_chapters = []
    chapters = []
    for index, value in enumerate(raw_chapters):
      if isinstance(value, dict):
        chapter = Chapter.from_dict(value, index)
        if chapter is not None:
          chapters.append(chapter)
    raw_trickplay = data.get('Trickplay') or {}
    if not isinstance(raw_trickplay, dict):
      raw_trickplay = {}
    return cls(
      id=item_id,
      name=text(data.get('Name'), 'Untitled'),
      type=text(data.get('Type')),
      overview=text(data.get('Overview')),
      runtime_ticks=max(0, integer(data.get('RunTimeTicks'))),
      position_ticks=max(0, integer(user_data.get('PlaybackPositionTicks'))),
      played=user_data.get('Played') is True,
      image_tags={key: value for key, value in tags.items() if isinstance(value, str)},
      parent_id=text(data.get('ParentId')),
      series_id=text(data.get('SeriesId')),
      season_id=text(data.get('SeasonId')),
      index_number=integer(data.get('IndexNumber')),
      parent_index_number=integer(data.get('ParentIndexNumber')),
      year=integer(data.get('ProductionYear')),
      series_name=text(data.get('SeriesName')),
      media_sources=tuple(source for source in sources if isinstance(source, dict)),
      raw=dict(data),
      chapters=tuple(chapters),
      trickplay={
        key: value
        for key, value in raw_trickplay.items()
        if isinstance(key, str) and isinstance(value, dict)
      },
    )


@dataclass(frozen=True)
class Page:
  items: tuple[MediaItem, ...]
  total: int
  start: int = 0
  limit: int = 60

  @property
  def has_more(self) -> bool:
    return bool(self.items) and self.start + len(self.items) < self.total

  @classmethod
  def from_dict(cls, data: dict[str, Any], start: int = 0, limit: int = 60) -> Page:
    raw_items = data.get('Items')
    if not isinstance(raw_items, list) or any(not isinstance(item, dict) for item in raw_items):
      raise ValueError('The server returned an invalid item page.')
    items = tuple(MediaItem.from_dict(item) for item in raw_items)
    offset = max(0, integer(data.get('StartIndex'), start))
    total = max(offset + len(items), integer(data.get('TotalRecordCount')))
    return cls(items, total, offset, limit)


class SegmentType(str, Enum):
  UNKNOWN = 'Unknown'
  COMMERCIAL = 'Commercial'
  PREVIEW = 'Preview'
  RECAP = 'Recap'
  OUTRO = 'Outro'
  INTRO = 'Intro'


@dataclass(frozen=True)
class Segment:
  start_ticks: int
  end_ticks: int
  type: str = SegmentType.INTRO.value
  id: str = ''
  item_id: str = ''

  @property
  def known_type(self) -> SegmentType | None:
    try:
      return SegmentType(self.type)
    except ValueError:
      return None

  def contains(self, position_ticks: int) -> bool:
    return self.start_ticks <= position_ticks < self.end_ticks

  @classmethod
  def from_dict(cls, data: dict[str, Any]) -> Segment | None:
    start = integer(data.get('StartTicks'), -1)
    end = integer(data.get('EndTicks'), -1)
    if start < 0 or end <= start:
      return None
    segment_type = text(data.get('Type'), SegmentType.UNKNOWN.value)
    return cls(
      start,
      end,
      segment_type or SegmentType.UNKNOWN.value,
      text(data.get('Id')),
      text(data.get('ItemId')),
    )
