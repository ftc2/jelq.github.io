"""Explicit server/account identity and serialization; Kodi owns profile file I/O."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from typing import Any
from urllib.parse import urlsplit, urlunsplit
from uuid import uuid4


def normalize_url(value: str) -> str:
  if not isinstance(value, str):
    raise TypeError('Enter a complete HTTP or HTTPS server address.')
  try:
    parts = urlsplit(value.strip())
    _ = parts.port  # Access validates malformed or out-of-range ports.
  except ValueError:
    raise ValueError('Enter a valid server address and port.') from None
  if parts.scheme not in {'http', 'https'} or not parts.hostname:
    raise ValueError('Enter a complete HTTP or HTTPS server address.')
  if parts.username or parts.password or parts.query or parts.fragment:
    raise ValueError('Use a server address without credentials, query parameters, or fragments.')
  return urlunsplit((parts.scheme.lower(), parts.netloc.lower(), parts.path.rstrip('/'), '', ''))


@dataclass(frozen=True)
class Server:
  url: str = field(repr=False)
  id: str = ''
  name: str = 'Jellyfin'

  def __post_init__(self) -> None:
    if any(not isinstance(value, str) for value in (self.url, self.id, self.name)):
      raise TypeError('Saved server fields must be text.')
    normalize_url(self.url)


@dataclass(frozen=True)
class Account:
  server_url: str = field(repr=False)
  server_id: str
  user_id: str
  user_name: str = field(repr=False)
  token: str = field(repr=False)
  device_id: str = field(repr=False)

  def __post_init__(self) -> None:
    values = (
      self.server_url,
      self.server_id,
      self.user_id,
      self.user_name,
      self.token,
      self.device_id,
    )
    if any(not isinstance(value, str) for value in values):
      raise TypeError('Saved account fields must be text.')
    if not self.user_id or not self.token or not self.device_id:
      raise ValueError('Saved accounts require a user, authentication token, and device identity.')
    normalize_url(self.server_url)


def _records(data: dict[str, Any], key: str) -> list[dict[str, Any]]:
  values = data.get(key, [])
  if not isinstance(values, list) or any(not isinstance(value, dict) for value in values):
    raise ValueError('Saved accounts and servers must be lists of records.')
  return values


def _profile_text(data: dict[str, Any], key: str, default: str, *, allow_empty: bool = True) -> str:
  value = data.get(key, default)
  if not isinstance(value, str):
    raise TypeError('Saved profile identity fields must be text.')
  if not allow_empty and not value:
    raise ValueError('Saved profile identity fields must not be empty.')
  return value


@dataclass
class AccountStore:
  servers: list[Server] = field(default_factory=list)
  accounts: list[Account] = field(default_factory=list, repr=False)
  last_server_url: str = field(default='', repr=False)
  device_id: str = field(default_factory=lambda: uuid4().hex, repr=False)

  def add_server(self, server: Server) -> None:
    normalized = Server(normalize_url(server.url), server.id, server.name)
    self.servers = [existing for existing in self.servers if existing.url != normalized.url]
    self.servers.append(normalized)
    self.last_server_url = normalized.url

  def save_account(self, account: Account) -> None:
    normalized = Account(
      normalize_url(account.server_url),
      account.server_id,
      account.user_id,
      account.user_name,
      account.token,
      account.device_id,
    )
    self.remove_account(normalized.server_url, normalized.user_id)
    self.accounts.append(normalized)
    self.last_server_url = normalized.server_url

  def accounts_for(self, server_url: str) -> list[Account]:
    normalized = normalize_url(server_url)
    return [account for account in self.accounts if account.server_url == normalized]

  def remove_account(self, server_url: str, user_id: str) -> None:
    normalized = normalize_url(server_url)
    self.accounts = [
      account
      for account in self.accounts
      if (account.server_url, account.user_id) != (normalized, user_id)
    ]

  def to_json(self) -> str:
    """Serialize secret-bearing profile data; callers must never log this string."""
    return json.dumps({'version': 1, **asdict(self)}, ensure_ascii=False)

  @classmethod
  def from_json(cls, value: str) -> AccountStore:
    if not value.strip():
      return cls()
    try:
      data: Any = json.loads(value)
    except (TypeError, ValueError) as error:
      raise ValueError(
        'Saved accounts could not be read. The original profile is preserved.'
      ) from error
    if (
      not isinstance(data, dict)
      or isinstance(data.get('version'), bool)
      or data.get('version') != 1
    ):
      raise ValueError('Unsupported saved-account format. The original profile is preserved.')
    try:
      store = cls()
      for server in _records(data, 'servers'):
        store.add_server(Server(**server))
      for account in _records(data, 'accounts'):
        store.save_account(Account(**account))
      last = _profile_text(data, 'last_server_url', '')
      store.last_server_url = normalize_url(last) if last else ''
      store.device_id = _profile_text(
        data,
        'device_id',
        store.accounts[0].device_id if store.accounts else store.device_id,
        allow_empty=False,
      )
    except (TypeError, ValueError, KeyError) as error:
      raise ValueError(
        'Saved accounts could not be read. The original profile is preserved.'
      ) from error
    return store
