"""Jellyfin application domain and Kodi integration."""
