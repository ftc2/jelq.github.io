"""Pure season and episode presentation state for the player-owned browser."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

from jelq.models import MediaItem, integer, text


@dataclass(frozen=True)
class EpisodeChoice:
  """One selectable item, retaining its position in Jellyfin's exact sequence."""

  item: MediaItem
  sequence_index: int
  label: str
  current: bool = False
  session_start: bool = False
  before_session_start: bool = False
  after_session_start: bool = False


@dataclass(frozen=True)
class SeasonGroup:
  """Episodes sharing a Jellyfin season identity, in server sequence order."""

  key: str
  label: str
  episodes: tuple[EpisodeChoice, ...]
  current_episode_index: int = -1

  @property
  def current(self) -> bool:
    return self.current_episode_index >= 0


@dataclass(frozen=True)
class EpisodeBrowser:
  """A stable two-level view over an unmodified Jellyfin episode sequence."""

  sequence: tuple[EpisodeChoice, ...]
  seasons: tuple[SeasonGroup, ...]
  current_index: int = -1
  session_start_index: int = -1
  current_season_index: int = -1

  @property
  def current(self) -> EpisodeChoice | None:
    return self._at(self.current_index)

  @property
  def previous(self) -> EpisodeChoice | None:
    return self._at(self.current_index - 1) if self.current_index > 0 else None

  @property
  def next(self) -> EpisodeChoice | None:
    return self._at(self.current_index + 1) if self.current_index >= 0 else None

  def choose(self, season_index: int, episode_index: int) -> MediaItem | None:
    """Resolve a two-pane selection without constraining it to the session start."""
    if season_index < 0 or season_index >= len(self.seasons):
      return None
    episodes = self.seasons[season_index].episodes
    if episode_index < 0 or episode_index >= len(episodes):
      return None
    return episodes[episode_index].item

  def choose_sequence_index(self, sequence_index: int) -> MediaItem | None:
    choice = self._at(sequence_index)
    return choice.item if choice is not None else None

  def choice_for_item(self, item_id: str) -> EpisodeChoice | None:
    return next((choice for choice in self.sequence if choice.item.id == item_id), None)

  def _at(self, index: int) -> EpisodeChoice | None:
    return self.sequence[index] if 0 <= index < len(self.sequence) else None

  @classmethod
  def build(
    cls,
    sequence: Sequence[MediaItem],
    current_item_id: str,
    session_start_item_id: str | None = None,
  ) -> EpisodeBrowser:
    """Build browser state without filtering or reordering Jellyfin's sequence."""
    items = tuple(sequence)
    current_index = _first_item_index(items, current_item_id)
    start_id = current_item_id if session_start_item_id is None else session_start_item_id
    session_start_index = _first_item_index(items, start_id)
    choices = tuple(
      EpisodeChoice(
        item=item,
        sequence_index=index,
        label=episode_label(item, index),
        current=index == current_index,
        session_start=index == session_start_index,
        before_session_start=session_start_index >= 0 and index < session_start_index,
        after_session_start=session_start_index >= 0 and index > session_start_index,
      )
      for index, item in enumerate(items)
    )

    group_keys: list[str] = []
    grouped: dict[str, list[EpisodeChoice]] = {}
    group_labels: dict[str, str] = {}
    for choice in choices:
      key = season_key(choice.item)
      if key not in grouped:
        group_keys.append(key)
        grouped[key] = []
        group_labels[key] = season_label(choice.item)
      grouped[key].append(choice)

    seasons = []
    current_season_index = -1
    for group_index, key in enumerate(group_keys):
      episodes = tuple(grouped[key])
      current_episode_index = next(
        (index for index, choice in enumerate(episodes) if choice.current),
        -1,
      )
      if current_episode_index >= 0:
        current_season_index = group_index
      seasons.append(
        SeasonGroup(
          key=key,
          label=group_labels[key],
          episodes=episodes,
          current_episode_index=current_episode_index,
        )
      )
    return cls(
      choices,
      tuple(seasons),
      current_index,
      session_start_index,
      current_season_index,
    )


def _first_item_index(items: Sequence[MediaItem], item_id: str) -> int:
  if not item_id:
    return -1
  return next((index for index, item in enumerate(items) if item.id == item_id), -1)


def _raw_nonnegative_number(item: MediaItem, key: str) -> int | None:
  if key not in item.raw:
    return None
  value = integer(item.raw.get(key), -1)
  return value if value >= 0 else None


def _season_number(item: MediaItem) -> int | None:
  if item.parent_index_number > 0:
    return item.parent_index_number
  return _raw_nonnegative_number(item, 'ParentIndexNumber')


def _episode_number(item: MediaItem) -> int | None:
  if item.index_number > 0:
    return item.index_number
  return _raw_nonnegative_number(item, 'IndexNumber')


def season_key(item: MediaItem) -> str:
  """Return a stable grouping key, preferring Jellyfin's season identities."""
  season_id = item.season_id or item.parent_id
  if season_id:
    return 'id:' + season_id
  number = _season_number(item)
  if number is not None:
    return 'number:' + str(number)
  name = text(item.raw.get('SeasonName')).strip()
  return 'name:' + name.casefold() if name else 'unknown'


def season_label(item: MediaItem) -> str:
  number = _season_number(item)
  if number == 0:
    return 'Specials'
  if number is not None:
    return f'Season {number}'
  name = text(item.raw.get('SeasonName')).strip()
  return name or 'Unknown season'


def episode_label(item: MediaItem, sequence_index: int) -> str:
  """Build a deterministic label without embedding transient selection state."""
  season = _season_number(item)
  episode = _episode_number(item)
  if season is not None and episode is not None:
    code = f'S{season:02d}E{episode:02d}'
  elif episode is not None:
    code = f'E{episode:02d}'
  else:
    code = f'#{sequence_index + 1}'
  return f'{code}  {item.name}'
