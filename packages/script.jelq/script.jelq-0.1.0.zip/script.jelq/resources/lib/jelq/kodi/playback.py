from __future__ import annotations

import json
import queue
import threading
import time
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Any, Callable
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

import xbmc
import xbmcgui

from jelq.client import ApiError, AuthError, JellyfinClient
from jelq.kodi.log import event
from jelq.models import TICKS_PER_SECOND, MediaItem, Segment, integer, text

REPORT_INTERVAL = 10
REPORT_TIMEOUT = 3.0
START_TIMEOUT = 45
INTRO_BUTTON = 10
END_TOLERANCE_TICKS = 2 * TICKS_PER_SECOND


def authenticated_url(client: JellyfinClient, url: str) -> str:
  if '|' in url:
    raise ApiError('The server returned an invalid media address.')
  return (
    url
    + '|'
    + urlencode({'Authorization': client.authorization_header, 'User-Agent': 'jelq/0.1.0'})
  )


def current_audio_index() -> int:
  """Read Kodi's selected track before asking it to restart the audio stream."""
  request = {
    'jsonrpc': '2.0',
    'id': 1,
    'method': 'Player.GetProperties',
    'params': {'playerid': 1, 'properties': ['currentaudiostream']},
  }
  try:
    response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
  except (AttributeError, TypeError, ValueError, RuntimeError):
    return -1
  result = response.get('result') if isinstance(response, dict) else None
  current = result.get('currentaudiostream') if isinstance(result, dict) else None
  return integer(current.get('index'), -1) if isinstance(current, dict) else -1


@dataclass
class PreparedPlayback:
  client: JellyfinClient = field(repr=False)
  item: MediaItem
  source: dict[str, Any] = field(repr=False)
  session_id: str
  path: str = field(repr=False)
  method: str
  start_ticks: int
  segments: tuple[Segment, ...]
  subtitles: list[str] = field(default_factory=list, repr=False)
  timeline_offset_ticks: int = 0

  @property
  def duration_ticks(self) -> int:
    return max(0, integer(self.source.get('RunTimeTicks'), self.item.runtime_ticks))


def select_source(sources: list[Any]) -> tuple[dict[str, Any], str]:
  valid = [source for source in sources if isinstance(source, dict) and text(source.get('Id'))]
  for method, supported, address in (
    ('DirectPlay', 'SupportsDirectPlay', ''),
    ('DirectStream', 'SupportsDirectStream', 'DirectStreamUrl'),
    ('Transcode', '', 'TranscodingUrl'),
  ):
    for source in valid:
      if (not supported or source.get(supported) is True) and (
        not address or text(source.get(address))
      ):
        return source, method
  raise ApiError('The server could not negotiate a playable stream for Kodi.')


def playback_timeline(path: str, method: str) -> tuple[str, int]:
  """HLS exposes the full title timeline; only progressive encodes use an offset."""
  parts = urlsplit(path)
  query = parse_qsl(parts.query, keep_blank_values=True)
  if parts.path.lower().endswith('.m3u8'):
    # Jellyfin's dynamic HLS variant lists the full runtime. Kodi seeks to its
    # matching segment; StartTimeTicks must not propagate to segment requests.
    query = [(key, value) for key, value in query if key.lower() != 'starttimeticks']
    return urlunsplit(parts._replace(query=urlencode(query))), 0
  offset = next((integer(value) for key, value in query if key.lower() == 'starttimeticks'), 0)
  return path, max(0, offset) if method == 'Transcode' else 0


def media_streams(source: dict[str, Any], kind: str) -> list[dict[str, Any]]:
  streams = source.get('MediaStreams')
  if not isinstance(streams, list):
    return []
  return [stream for stream in streams if isinstance(stream, dict) and stream.get('Type') == kind]


def subtitle_tracks(source: dict[str, Any]) -> list[dict[str, Any]]:
  """Kodi loads ListItem's external subtitles before opening the embedded streams."""
  tracks = media_streams(source, 'Subtitle')
  internal = [stream for stream in tracks if not stream.get('IsExternal')]
  external = [
    stream for stream in tracks if stream.get('IsExternal') and text(stream.get('DeliveryUrl'))
  ]
  return external + internal


def prepare(client: JellyfinClient, item: MediaItem, *, resume: bool) -> PreparedPlayback:
  start_ticks = item.position_ticks if resume else 0
  info = client.playback_info(item.id, start_ticks=start_ticks)
  sources = info.get('MediaSources')
  if not isinstance(sources, list) or not sources:
    raise ApiError('No playable source is available for this title.')
  source, method = select_source(sources)
  source_id = text(source.get('Id'))
  if method == 'DirectPlay':
    path = client.stream_url(item.id, source_id)
  elif method == 'DirectStream':
    path = client.media_url(text(source.get('DirectStreamUrl')))
  else:
    path = client.media_url(text(source.get('TranscodingUrl')))
  path, timeline_offset = playback_timeline(path, method)
  try:
    segments = client.segments(item.id)
  except AuthError:
    raise
  except ApiError:
    segments = ()
  subtitles = []
  for stream in subtitle_tracks(source):
    if stream.get('IsExternal'):
      delivery = text(stream.get('DeliveryUrl'))
      if delivery:
        subtitles.append(authenticated_url(client, client.media_url(delivery)))
  return PreparedPlayback(
    client,
    item,
    source,
    text(info.get('PlaySessionId')),
    authenticated_url(client, path),
    method,
    start_ticks,
    segments,
    subtitles,
    timeline_offset,
  )


class KodiPlayer(xbmc.Player):
  def __init__(self, events: queue.Queue[str]) -> None:
    super().__init__()
    self.events = events

  def onAVStarted(self) -> None:  # noqa: N802 - Kodi callback name.
    self.events.put('started')

  def onPlayBackPaused(self) -> None:  # noqa: N802 - Kodi callback name.
    self.events.put('paused')

  def onPlayBackResumed(self) -> None:  # noqa: N802 - Kodi callback name.
    self.events.put('resumed')

  def onPlayBackSeek(self, time: int, seekOffset: int) -> None:  # noqa: N802, N803, ARG002 - Kodi callback signature.
    self.events.put('seek')

  def onPlayBackStopped(self) -> None:  # noqa: N802 - Kodi callback name.
    self.events.put('stopped')

  def onPlayBackEnded(self) -> None:  # noqa: N802 - Kodi callback name.
    self.events.put('ended')

  def onPlayBackError(self) -> None:  # noqa: N802 - Kodi callback name.
    self.events.put('error')


class IntroDialog(xbmcgui.WindowXMLDialog):
  commands: queue.Queue[str]

  def onClick(self, control_id: int) -> None:  # noqa: N802 - Kodi callback name.
    if control_id == INTRO_BUTTON:
      self.commands.put('skip')

  def onAction(self, action: xbmcgui.Action) -> None:  # noqa: N802 - Kodi callback name.
    if action.getId() in {9, 10, 92, 24}:
      self.commands.put('dismiss')
      self.close()


class PlaybackController:
  def __init__(self, addon_path: str, finished: Callable[[str], None]) -> None:
    self.events: queue.Queue[str] = queue.Queue()
    self.player = KodiPlayer(self.events)
    self.addon_path = addon_path
    self.finished = finished
    self.current: PreparedPlayback | None = None
    self.report_client: JellyfinClient | None = None
    self.reporter = ThreadPoolExecutor(max_workers=1)
    self.reports: list[Future[bool]] = []
    self.shutdown = threading.Event()
    self.started = False
    self.finishing = False
    self.paused = False
    self.position = 0
    self.last_report = 0.0
    self.requested_at = 0.0
    self.intro: IntroDialog | None = None
    self.intro_commands: queue.Queue[str] = queue.Queue()
    self.dismissed: set[int] = set()
    self.sync_failed = False

  @property
  def active(self) -> bool:
    return self.current is not None and not self.finishing

  @property
  def busy(self) -> bool:
    """A title still owns this controller until its final report completes."""
    return self.current is not None

  def start(self, prepared: PreparedPlayback) -> None:
    if self.busy or self.shutdown.is_set():
      raise RuntimeError('Stop the current playback before starting another title.')
    # Each Kodi Player retains its own callback queue. Late callbacks from an old
    # item cannot finish a new item or send updates to a newly selected account.
    self.events = queue.Queue()
    self.player = KodiPlayer(self.events)
    self.intro_commands = queue.Queue()
    self.current = prepared
    client = prepared.client
    self.report_client = JellyfinClient(
      client.base_url,
      client.device_id,
      client.token,
      client.user_id,
      transport=client.transport,
      timeout=min(client.timeout, REPORT_TIMEOUT),
    )
    self.started = False
    self.finishing = False
    self.paused = False
    self.sync_failed = False
    self.position = prepared.start_ticks
    self.dismissed.clear()
    self.requested_at = time.monotonic()
    entry = xbmcgui.ListItem(label=prepared.item.name, path=prepared.path)
    metadata = entry.getVideoInfoTag()
    metadata.setTitle(prepared.item.name)
    metadata.setMediaType('episode' if prepared.item.type == 'Episode' else 'movie')
    metadata.setDuration(prepared.duration_ticks // TICKS_PER_SECOND)
    metadata.setPlot(prepared.item.overview)
    # Only the explicit Jellyfin subtitle URLs should precede embedded streams.
    # Kodi scans/adds ListItem subtitles before creating the media demuxer.
    entry.setProperty('no-ext-subs-scan', 'true')
    offset = max(0, prepared.start_ticks - prepared.timeline_offset_ticks)
    if offset:
      entry.setProperty('StartOffset', str(offset / TICKS_PER_SECOND))
    entry.setSubtitles(prepared.subtitles)
    xbmcgui.Window(10000).setProperty('jelq.playing', 'true')
    try:
      self.player.play(prepared.path, entry, windowed=False)
    except RuntimeError:
      self._event('error')

  def poll(self) -> None:
    while not self.events.empty():
      self._event(self.events.get_nowait())
    if not self.current:
      return
    if self.started and not self.finishing:
      self._position()
      self._intro()
      if time.monotonic() - self.last_report >= REPORT_INTERVAL:
        self._report('progress')
    elif not self.finishing and time.monotonic() - self.requested_at > START_TIMEOUT:
      self.player.stop()
      self._event('error')
    self._finish_reports()

  def _finish_reports(self) -> None:
    for future in list(self.reports):
      if future.done():
        self.reports.remove(future)
        if not future.result():
          self.sync_failed = True
    if self.current is not None and self.finishing and not self.reports:
      item_id = self.current.item.id
      self.current = None
      self.report_client = None
      self.finishing = False
      if self.sync_failed:
        xbmcgui.Dialog().ok(
          'Watch progress',
          'Jellyfin could not save all playback updates. Watch progress may be out of date.',
        )
      self.finished(item_id)

  def _event(self, kind: str) -> None:
    if self.current is None or self.finishing:
      return
    if kind == 'started':
      if self.started:
        return
      self.started = True
      self._position()
      self._defaults()
      self._report('start')
    elif kind in {'paused', 'resumed', 'seek'}:
      if not self.started:
        return
      if kind != 'seek':
        self.paused = kind == 'paused'
      self._position()
      self._report('progress')
    elif kind in {'stopped', 'ended', 'error'}:
      self._stopped(kind)

  def _stopped(self, kind: str) -> None:
    if self.current is None:
      return
    self.finishing = True
    self._hide_intro()
    xbmcgui.Window(10000).clearProperty('jelq.playing')
    failure = ''
    if kind == 'ended':
      duration = self.current.duration_ticks
      tolerance = min(END_TOLERANCE_TICKS, duration // 20)
      if self.started and duration > 0 and self.position >= duration - tolerance:
        self.position = duration
      else:
        failure = 'Playback ended before the title finished. You can resume or retry.'
    if self.started:
      self._report('stop')
    if kind == 'error':
      failure = 'Kodi could not play this title. You can retry or choose another title.'
    if failure:
      xbmcgui.Dialog().ok('Playback failed', failure)

  def _position(self) -> None:
    try:
      seconds = self.player.getTime()
    except RuntimeError:
      return
    if self.current:
      seconds += self.current.timeline_offset_ticks / TICKS_PER_SECOND
    self.position = max(0, int(seconds * TICKS_PER_SECOND))

  def _defaults(self) -> None:
    if not self.current or self.current.method != 'DirectPlay':
      return
    source = self.current.source
    current_audio = current_audio_index()
    for stream_type, key in (
      ('Audio', 'DefaultAudioStreamIndex'),
      ('Subtitle', 'DefaultSubtitleStreamIndex'),
    ):
      target = integer(source.get(key), -1)
      tracks = media_streams(source, 'Audio') if stream_type == 'Audio' else subtitle_tracks(source)
      match = next(
        (
          index
          for index, value in enumerate(tracks)
          if target >= 0 and integer(value.get('Index'), -1) == target
        ),
        None,
      )
      try:
        if stream_type == 'Audio':
          if match is not None and current_audio >= 0 and match != current_audio:
            # Kodi closes/reopens audio and seeks even when selecting the same
            # stream. Leave its selection alone until the current index is known.
            self.player.setAudioStream(match)
        elif stream_type == 'Subtitle':
          if match is not None:
            self.player.setSubtitleStream(match)
          self.player.showSubtitles(match is not None)
      except RuntimeError:
        event('A default playback track was unavailable.')

  def _report(self, action: str) -> None:
    if self.current is None or self.report_client is None:
      return
    if action == 'progress' and any(not future.done() for future in self.reports):
      # A slow/offline server must not accumulate an unbounded queue of obsolete
      # positions. Start/stop are always retained; progress takes a fresh snapshot.
      self.last_report = time.monotonic()
      return
    current = self.current
    payload = {
      'ItemId': current.item.id,
      'MediaSourceId': text(current.source.get('Id')),
      'PlaySessionId': current.session_id,
      'PositionTicks': self.position,
      'IsPaused': self.paused,
      'CanSeek': True,
      'PlayMethod': current.method,
    }
    function = {
      'start': self.report_client.report_start,
      'progress': self.report_client.report_progress,
      'stop': self.report_client.report_stop,
    }[action]
    self.reports.append(self.reporter.submit(self._send, function, payload))
    self.last_report = time.monotonic()

  def _send(self, function: Callable[[dict[str, Any]], None], payload: dict[str, Any]) -> bool:
    for delay in (0, 1, 3):
      if delay and self.shutdown.wait(delay):
        return False
      try:
        function(payload)
      except AuthError:
        return False
      except ApiError:
        continue
      except Exception:  # noqa: BLE001 - Contain reporter failures without exposing HTTP credentials.
        event('A playback update failed.', error=True)
        return False
      else:
        return True
    return False

  def _intro(self) -> None:
    if not self.current:
      return
    segment = next(
      (segment for segment in self.current.segments if segment.contains(self.position)), None
    )
    while not self.intro_commands.empty():
      command = self.intro_commands.get_nowait()
      if segment:
        if command == 'skip':
          offset = self.current.timeline_offset_ticks
          self.player.seekTime(max(0, segment.end_ticks - offset) / TICKS_PER_SECOND)
        self.dismissed.add(segment.start_ticks)
      self._hide_intro()
    if segment and segment.start_ticks not in self.dismissed and not self.intro:
      if xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)'):
        self.intro = IntroDialog('intro.xml', self.addon_path, 'Default', '1080i')
        self.intro.commands = self.intro_commands
        self.intro.show()
    elif not segment:
      self._hide_intro()

  def _hide_intro(self) -> None:
    if self.intro:
      self.intro.close()
      self.intro = None

  def close(self) -> None:
    self._hide_intro()
    if self.current and not self.finishing:
      self._position()
      self.player.stop()
      self._event('stopped')
    self.shutdown.set()
    if any(not future.done() for future in self.reports):
      xbmcgui.Dialog().notification('Watch progress', 'Finishing watch progress in the background.')
    # Keep the final stop, but never make the window wait for the network. The
    # original account snapshot has a short timeout; shutdown suppresses retries.
    self.reporter.shutdown(wait=False)
