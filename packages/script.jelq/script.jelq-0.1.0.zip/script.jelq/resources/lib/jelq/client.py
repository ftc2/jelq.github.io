"""Jellyfin 12 HTTP API, isolated from the Kodi host and its UI thread."""

from __future__ import annotations

import json
from typing import Any, Protocol
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qsl, quote, urlencode, urljoin, urlsplit, urlunsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

from jelq.accounts import Account, normalize_url
from jelq.models import MediaItem, Page, Segment, text

MAX_RESPONSE_BYTES = 16 * 1024 * 1024
UNAUTHORIZED = 401
FORBIDDEN = 403


class ApiError(Exception):
  """A sanitized API error safe for display; never contains a response body or URL."""

  def __init__(self, message: str, status: int = 0) -> None:
    super().__init__(message)
    self.status = status


class AuthError(ApiError):
  pass


class NetworkError(ApiError):
  pass


JellyfinError = ApiError
AuthenticationError = AuthError


class Transport(Protocol):
  def request(
    self,
    method: str,
    url: str,
    headers: dict[str, str],
    body: dict[str, Any] | None,
    timeout: float,
  ) -> dict[str, Any]: ...


class _SameOriginRedirect(HTTPRedirectHandler):
  def redirect_request(  # noqa: PLR0913, PLR0917 - urllib callback signature.
    self,
    req: Request,
    fp: Any,
    code: int,
    msg: str,
    headers: Any,
    newurl: str,
  ) -> Request | None:
    origin = urlsplit(req.full_url)
    target = urlsplit(newurl)
    if (origin.scheme, origin.netloc) != (target.scheme, target.netloc):
      raise ApiError('The server redirected to another address. Update its saved address.')
    return super().redirect_request(req, fp, code, msg, headers, newurl)


class UrllibTransport:
  def request(
    self,
    method: str,
    url: str,
    headers: dict[str, str],
    body: dict[str, Any] | None,
    timeout: float,
  ) -> dict[str, Any]:
    data = json.dumps(body).encode('utf-8') if body is not None else None
    if urlsplit(url).scheme not in {'https', 'http'}:
      raise ApiError('Only HTTP and HTTPS server requests are supported.')
    request = Request(url, data=data, headers=headers, method=method)  # noqa: S310 - scheme checked above.
    try:
      with build_opener(_SameOriginRedirect()).open(request, timeout=timeout) as response:
        raw = response.read(MAX_RESPONSE_BYTES + 1)
    except HTTPError as error:
      if error.code == UNAUTHORIZED:
        raise AuthError(
          'Sign-in expired or the username/password was not accepted.', error.code
        ) from None
      if error.code == FORBIDDEN:
        raise ApiError('The server denied access to this request.', error.code) from None
      raise ApiError('The Jellyfin request failed. Please retry.', error.code) from None
    except (URLError, OSError, TimeoutError):
      raise NetworkError(
        'The server could not be reached. Check the connection and retry.'
      ) from None
    if len(raw) > MAX_RESPONSE_BYTES:
      raise ApiError('The server response is too large. Try a smaller page.')
    if not raw:
      return {}
    try:
      result = json.loads(raw)
    except (ValueError, UnicodeError):
      raise ApiError('The server returned an unreadable response.') from None
    if not isinstance(result, dict):
      raise ApiError('The server returned an unexpected response.')
    return result


def kodi_device_profile() -> dict[str, Any]:
  """Advertise common Kodi video formats; Kodi chooses hardware/software decoding."""
  return {
    'Name': 'Kodi',
    'MaxStreamingBitrate': 200_000_000,
    'MaxStaticBitrate': 200_000_000,
    'DirectPlayProfiles': [
      {
        'Type': 'Video',
        'Container': 'mkv,mp4,m4v,mov,avi,ts,m2ts,mts,webm,mpeg,mpg,wmv,asf,flv,ogv',
        'VideoCodec': 'h264,hevc,mpeg4,mpeg2video,mpeg1video,vc1,wmv3,vp8,vp9,av1,theora,mjpeg',
        'AudioCodec': 'aac,ac3,eac3,dts,truehd,flac,mp3,mp2,vorbis,opus,pcm_s16le,pcm_s24le,pcm_s32le',
      }
    ],
    'TranscodingProfiles': [
      {
        'Type': 'Video',
        'Container': 'ts',
        'Protocol': 'hls',
        'Context': 'Streaming',
        'VideoCodec': 'h264',
        'AudioCodec': 'aac',
        'MaxAudioChannels': '6',
      }
    ],
    'SubtitleProfiles': [
      {'Format': format_name, 'Method': method}
      for format_name, method in (
        ('srt', 'External'),
        ('ass', 'External'),
        ('ssa', 'External'),
        ('vtt', 'External'),
        ('subrip', 'Embed'),
        ('ass', 'Embed'),
        ('ssa', 'Embed'),
        ('pgssub', 'Embed'),
        ('dvdsub', 'Embed'),
      )
    ],
  }


class JellyfinClient:
  def __init__(  # noqa: PLR0913 - explicit identity and transport host-adapter contract.
    self,
    base_url: str,
    device_id: str,
    token: str = '',
    user_id: str = '',
    *,
    transport: Transport | None = None,
    timeout: float = 15,
  ) -> None:
    self.base_url = normalize_url(base_url)
    self.device_id = device_id
    self.token = token
    self.user_id = user_id
    self.timeout = timeout
    self.transport = transport or UrllibTransport()

  @property
  def authorization_header(self) -> str:
    parts = {
      'Client': 'jelq',
      'Device': 'Kodi',
      'DeviceId': self.device_id,
      'Version': '0.1.0',
    }
    if self.token:
      parts['Token'] = self.token
    return 'MediaBrowser ' + ', '.join(
      '{}="{}"'.format(key, quote(value, safe='')) for key, value in parts.items()
    )

  @property
  def headers(self) -> dict[str, str]:
    return {
      'Authorization': self.authorization_header,
      'User-Agent': 'jelq/0.1.0',
      'Accept': 'application/json',
      'Content-Type': 'application/json',
    }

  def _url(self, path: str, params: dict[str, Any] | None = None) -> str:
    query = urlencode(
      {
        key: str(value).lower() if isinstance(value, bool) else value
        for key, value in (params or {}).items()
        if value is not None and value != ''
      }
    )
    return self.base_url + '/' + path.lstrip('/') + ('?' + query if query else '')

  def _request(
    self,
    path: str,
    params: dict[str, Any] | None = None,
    *,
    method: str = 'GET',
    body: dict[str, Any] | None = None,
  ) -> dict[str, Any]:
    return self.transport.request(method, self._url(path, params), self.headers, body, self.timeout)

  def _page(self, path: str, params: dict[str, Any]) -> Page:
    try:
      return Page.from_dict(
        self._request(path, params),
        start=params.get('StartIndex', 0),
        limit=params.get('Limit', 60),
      )
    except ValueError:
      raise ApiError('The server returned an invalid library page.') from None

  def public_info(self) -> dict[str, Any]:
    return self._request('/System/Info/Public')

  def authenticate(self, username: str, password: str) -> Account:
    response = self._request(
      '/Users/AuthenticateByName',
      method='POST',
      body={'Username': username, 'Pw': password},
    )
    user = response.get('User')
    if (
      not isinstance(user, dict)
      or not text(response.get('AccessToken'))
      or not text(user.get('Id'))
    ):
      raise ApiError('The server returned an incomplete sign-in response.')
    return Account(
      self.base_url,
      text(response.get('ServerId')),
      text(user.get('Id')),
      text(user.get('Name'), username),
      text(response.get('AccessToken')),
      self.device_id,
    )

  def current_user(self) -> dict[str, Any]:
    user = self._request('/Users/Me')
    if self.user_id and user.get('Id') != self.user_id:
      raise AuthError('The saved sign-in belongs to a different account. Sign in again.')
    return user

  def logout(self) -> None:
    self._request('/Sessions/Logout', method='POST', body={})

  def libraries(self) -> tuple[MediaItem, ...]:
    return self._page('/UserViews', {'UserId': self.user_id}).items

  def items(self, parent_id: str, kind: str, start: int = 0, limit: int = 60) -> Page:
    if kind not in {'Movie', 'Series'}:
      raise ValueError('Library browsing requires Movie or Series items.')
    sort = 'DateCreated' if kind == 'Movie' else 'DateLastContentAdded'
    return self._page(
      '/Items',
      {
        'UserId': self.user_id,
        'ParentId': parent_id,
        'IncludeItemTypes': kind,
        'Recursive': True,
        'StartIndex': max(0, start),
        'Limit': max(1, min(limit, 200)),
        'SortBy': sort + ',SortName',
        'SortOrder': 'Descending',
        'Fields': 'DateCreated,Overview,PrimaryImageAspectRatio',
        'EnableUserData': True,
        'EnableTotalRecordCount': True,
      },
    )

  def seasons(self, series_id: str) -> Page:
    return self._page(
      '/Shows/' + quote(series_id, safe='') + '/Seasons',
      {
        'UserId': self.user_id,
        'Fields': 'Overview',
        'EnableUserData': True,
        'IsMissing': False,
        'IsSpecialSeason': None,
      },
    )

  def episodes(
    self,
    series_id: str,
    season_id: str = '',
    start: int = 0,
    limit: int = 60,
  ) -> Page:
    return self._page(
      '/Shows/' + quote(series_id, safe='') + '/Episodes',
      {
        'UserId': self.user_id,
        'SeasonId': season_id,
        'StartIndex': max(0, start),
        'Limit': max(1, min(limit, 200)),
        'Fields': 'Overview',
        'EnableUserData': True,
        'IsMissing': False,
      },
    )

  def item(self, item_id: str) -> MediaItem:
    try:
      return MediaItem.from_dict(
        self._request(
          '/Items/' + quote(item_id, safe=''),
          {'UserId': self.user_id},
        )
      )
    except ValueError:
      raise ApiError('The server returned invalid title details.') from None

  def playback_info(  # noqa: PLR0913 - Jellyfin playback negotiation parameters.
    self,
    item_id: str,
    *,
    start_ticks: int = 0,
    media_source_id: str = '',
    audio_index: int | None = None,
    subtitle_index: int | None = None,
    device_profile: dict[str, Any] | None = None,
  ) -> dict[str, Any]:
    body: dict[str, Any] = {
      'UserId': self.user_id,
      'StartTimeTicks': max(0, start_ticks),
      'IsPlayback': True,
      'AutoOpenLiveStream': False,
      'EnableDirectPlay': True,
      'EnableDirectStream': True,
      'EnableTranscoding': True,
      'AllowVideoStreamCopy': True,
      'AllowAudioStreamCopy': True,
      'DeviceProfile': device_profile if device_profile is not None else kodi_device_profile(),
    }
    selections = (
      ('MediaSourceId', media_source_id or None),
      ('AudioStreamIndex', audio_index),
      ('SubtitleStreamIndex', subtitle_index),
    )
    body.update({key: value for key, value in selections if value is not None})
    return self._request(
      '/Items/' + quote(item_id, safe='') + '/PlaybackInfo', method='POST', body=body
    )

  def segments(self, item_id: str) -> tuple[Segment, ...]:
    data = self._request(
      '/MediaSegments/' + quote(item_id, safe=''), {'IncludeSegmentTypes': 'Intro'}
    )
    values = data.get('Items')
    if not isinstance(values, list):
      raise ApiError('The server returned invalid intro segments.')
    result = []
    for value in values:
      if isinstance(value, dict):
        segment = Segment.from_dict(value)
        if segment is not None and segment.type == 'Intro':
          result.append(segment)
    return tuple(sorted(result, key=lambda segment: segment.start_ticks))

  def report_start(self, payload: dict[str, Any]) -> None:
    self._request('/Sessions/Playing', method='POST', body=payload)

  def report_progress(self, payload: dict[str, Any]) -> None:
    self._request('/Sessions/Playing/Progress', method='POST', body=payload)

  def report_stop(self, payload: dict[str, Any]) -> None:
    self._request('/Sessions/Playing/Stopped', method='POST', body=payload)

  def image_url(self, item: MediaItem, image_type: str = 'Primary', width: int = 400) -> str:
    return self._url(
      '/Items/' + quote(item.id, safe='') + '/Images/' + quote(image_type, safe=''),
      {
        'Tag': item.image_tags.get(image_type),
        'MaxWidth': max(1, min(width, 1920)),
      },
    )

  def stream_url(self, item_id: str, media_source_id: str) -> str:
    return self._url(
      '/Videos/' + quote(item_id, safe='') + '/stream',
      {
        'Static': True,
        'MediaSourceId': media_source_id,
      },
    )

  def media_url(self, path: str) -> str:
    """Resolve same-server media; the Kodi adapter supplies auth via headers."""
    resolved = urljoin(self.base_url + '/', path)
    origin, target = urlsplit(self.base_url), urlsplit(resolved)
    if (origin.scheme, origin.netloc) != (target.scheme, target.netloc):
      raise ApiError('The server returned a media address on another server.')
    query = urlencode(
      [
        (key, value)
        for key, value in parse_qsl(target.query, keep_blank_values=True)
        if key.lower().replace('_', '') != 'apikey'
      ]
    )
    return urlunsplit((target.scheme, target.netloc, target.path, query, ''))
