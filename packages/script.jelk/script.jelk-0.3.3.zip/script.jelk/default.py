from __future__ import annotations

import sys

import xbmcaddon
import xbmcvfs

sys.path.insert(0, xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path') + '/resources/lib'))

from jelk.kodi.runtime import run

if __name__ == '__main__':
  run()
