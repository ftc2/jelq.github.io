"""Jellyfin 12 HTTP API, isolated from the Kodi host and its UI thread."""

from __future__ import annotations

import json
from copy import deepcopy
from typing import Any, Protocol
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qsl, quote, urlencode, urljoin, urlsplit, urlunsplit
from urllib.request import HTTPRedirectHandler, Request

from jelk.accounts import Account, normalize_url
from jelk.identity import USER_AGENT, VERSION
from jelk.models import Chapter, MediaItem, Page, Segment, text
from jelk.models import user_autoplay_enabled as parse_user_autoplay_enabled
from jelk.network import RequestCancelledError, read_response
from jelk.server_settings import (
  LanguageOption,
  UserConfiguration,
  UserSetting,
  validated_setting_value,
)

MAX_RESPONSE_BYTES = 16 * 1024 * 1024
MAX_IMAGE_RESPONSE_BYTES = 48 * 1024 * 1024
MAX_INT32 = 2_147_483_647
MAX_EPISODE_PAGE_SIZE = 200
MAX_EPISODE_SEQUENCE_ITEMS = 20_000
MAX_EPISODE_SEQUENCE_PAGES = 100
UNAUTHORIZED = 401
FORBIDDEN = 403


class ApiError(Exception):
  """A sanitized API error safe for display; never contains a response body or URL."""

  def __init__(self, message: str, status: int = 0) -> None:
    super().__init__(message)
    self.status = status


class AuthError(ApiError):
  pass


class NetworkError(ApiError):
  pass


class ServerIdentityError(ApiError):
  def __init__(self) -> None:
    super().__init__(
      'The server identity does not match. Saved sign-ins cannot be used. '
      'Check the server, then retry connection.'
    )


JellyfinError = ApiError
AuthenticationError = AuthError


class Transport(Protocol):
  def request(
    self,
    method: str,
    url: str,
    headers: dict[str, str],
    body: dict[str, Any] | None,
    timeout: float,
  ) -> Any: ...


class _SameOriginRedirect(HTTPRedirectHandler):
  def redirect_request(  # noqa: PLR0913, PLR0917 - urllib callback signature.
    self,
    req: Request,
    fp: Any,
    code: int,
    msg: str,
    headers: Any,
    newurl: str,
  ) -> Request | None:
    origin = urlsplit(req.full_url)
    target = urlsplit(newurl)
    if (origin.scheme, origin.netloc) != (target.scheme, target.netloc):
      fp.close()
      raise ApiError('The server redirected to another address. Update its saved address.')
    return super().redirect_request(req, fp, code, msg, headers, newurl)


class UrllibTransport:
  def request(  # noqa: C901 - sanitized HTTP and response-format boundary.
    self,
    method: str,
    url: str,
    headers: dict[str, str],
    body: dict[str, Any] | None,
    timeout: float,
  ) -> Any:
    data = json.dumps(body).encode('utf-8') if body is not None else None
    if urlsplit(url).scheme not in {'https', 'http'}:
      raise ApiError('Only HTTP and HTTPS server requests are supported.')
    request = Request(url, data=data, headers=headers, method=method)  # noqa: S310 - scheme checked above.
    try:
      raw = read_response(request, timeout, MAX_RESPONSE_BYTES, _SameOriginRedirect())
    except RequestCancelledError:
      raise NetworkError('The request was interrupted; its outcome is unconfirmed.') from None
    except HTTPError as error:
      if error.code == UNAUTHORIZED:
        raise AuthError(
          'Sign-in expired or the username/password was not accepted.', error.code
        ) from None
      if error.code == FORBIDDEN:
        raise ApiError('The server denied access to this request.', error.code) from None
      raise ApiError('The Jellyfin request failed. Please retry.', error.code) from None
    except (URLError, OSError, TimeoutError):
      raise NetworkError(
        'The server could not be reached. Check the connection and retry.'
      ) from None
    if len(raw) > MAX_RESPONSE_BYTES:
      raise ApiError('The server response is too large. Try a smaller page.')
    if not raw:
      return {}
    try:
      result = json.loads(raw)
    except (ValueError, UnicodeError):
      raise ApiError('The server returned an unreadable response.') from None
    if not isinstance(result, (dict, list)):
      raise ApiError('The server returned an unexpected response.')
    return result


def kodi_device_profile() -> dict[str, Any]:
  """Advertise common Kodi video formats; Kodi chooses hardware/software decoding."""
  return {
    'Name': 'Kodi',
    'MaxStreamingBitrate': 200_000_000,
    'MaxStaticBitrate': 200_000_000,
    'DirectPlayProfiles': [
      {
        'Type': 'Video',
        'Container': 'mkv,mp4,m4v,mov,avi,ts,m2ts,mts,webm,mpeg,mpg,wmv,asf,flv,ogv',
        'VideoCodec': 'h264,hevc,mpeg4,mpeg2video,mpeg1video,vc1,wmv3,vp8,vp9,av1,theora,mjpeg',
        'AudioCodec': 'aac,ac3,eac3,dts,truehd,flac,mp3,mp2,vorbis,opus,pcm_s16le,pcm_s24le,pcm_s32le',
      }
    ],
    'TranscodingProfiles': [
      {
        'Type': 'Video',
        'Container': 'ts',
        'Protocol': 'hls',
        'Context': 'Streaming',
        'VideoCodec': 'h264',
        'AudioCodec': 'aac',
        'MaxAudioChannels': '6',
      }
    ],
    'SubtitleProfiles': [
      {'Format': format_name, 'Method': method}
      for format_name, method in (
        ('srt', 'External'),
        ('ass', 'External'),
        ('ssa', 'External'),
        ('vtt', 'External'),
        ('subrip', 'Embed'),
        ('ass', 'Embed'),
        ('ssa', 'Embed'),
        ('pgssub', 'Embed'),
        ('dvdsub', 'Embed'),
      )
    ],
  }


class JellyfinClient:
  def __init__(  # noqa: PLR0913 - explicit identity and transport host-adapter contract.
    self,
    base_url: str,
    device_id: str,
    token: str = '',
    user_id: str = '',
    *,
    server_id: str = '',
    transport: Transport | None = None,
    timeout: float = 15,
  ) -> None:
    self.base_url = normalize_url(base_url)
    self.device_id = device_id
    self.token = token
    self.user_id = user_id
    self.server_id = server_id
    self.timeout = timeout
    self.transport = transport or UrllibTransport()

  @property
  def authorization_header(self) -> str:
    parts = {
      'Client': 'jelk',
      'Device': 'Kodi',
      'DeviceId': self.device_id,
      'Version': VERSION,
    }
    if self.token:
      parts['Token'] = self.token
    return 'MediaBrowser ' + ', '.join(
      '{}="{}"'.format(key, quote(value, safe='')) for key, value in parts.items()
    )

  @property
  def headers(self) -> dict[str, str]:
    return {
      'Authorization': self.authorization_header,
      'User-Agent': USER_AGENT,
      'Accept': 'application/json',
      'Content-Type': 'application/json',
    }

  def _url(self, path: str, params: dict[str, Any] | None = None) -> str:
    query = urlencode(
      {
        key: str(value).lower() if isinstance(value, bool) else value
        for key, value in (params or {}).items()
        if value is not None and value != ''
      }
    )
    return self.base_url + '/' + path.lstrip('/') + ('?' + query if query else '')

  def _request(
    self,
    path: str,
    params: dict[str, Any] | None = None,
    *,
    method: str = 'GET',
    body: dict[str, Any] | None = None,
  ) -> dict[str, Any]:
    result = self.transport.request(
      method, self._url(path, params), self.headers, body, self.timeout
    )
    if not isinstance(result, dict):
      raise ApiError('The server returned an unexpected response.')
    return result

  def _request_array(self, path: str) -> list[Any]:
    result = self.transport.request('GET', self._url(path), self.headers, None, self.timeout)
    if not isinstance(result, list):
      raise ApiError('The server returned an unexpected response.')
    return result

  def download_image(self, url: str) -> bytes:
    """Download a bounded same-server image without exposing credentials in its URL."""
    origin = urlsplit(self.base_url)
    target = urlsplit(url)
    if target.scheme not in {'https', 'http'} or (origin.scheme, origin.netloc) != (
      target.scheme,
      target.netloc,
    ):
      raise ApiError('The server returned an image address on another server.')
    headers = dict(self.headers)
    headers['Accept'] = 'image/jpeg,image/*;q=0.8'
    request = Request(url, headers=headers, method='GET')  # noqa: S310 - origin checked above.
    try:
      raw = read_response(request, self.timeout, MAX_IMAGE_RESPONSE_BYTES, _SameOriginRedirect())
    except RequestCancelledError:
      raise NetworkError('The request was interrupted; its outcome is unconfirmed.') from None
    except HTTPError as error:
      if error.code == UNAUTHORIZED:
        raise AuthError('Sign-in expired while loading playback artwork.', error.code) from None
      if error.code == FORBIDDEN:
        raise ApiError('The server denied access to playback artwork.', error.code) from None
      raise ApiError('Playback artwork is unavailable.', error.code) from None
    except (URLError, OSError, TimeoutError):
      raise NetworkError('Playback artwork could not be loaded.') from None
    if len(raw) > MAX_IMAGE_RESPONSE_BYTES:
      raise ApiError('Playback artwork is too large to display safely.')
    if not raw:
      raise ApiError('Playback artwork is empty.')
    return raw

  def _page(self, path: str, params: dict[str, Any]) -> Page:
    try:
      return Page.from_dict(
        self._request(path, params),
        start=params.get('StartIndex', 0),
        limit=params.get('Limit', 60),
      )
    except ValueError:
      raise ApiError('The server returned an invalid library page.') from None

  def public_info(self) -> dict[str, Any]:
    headers = {key: value for key, value in self.headers.items() if key != 'Authorization'}
    result = self.transport.request(
      'GET', self._url('/System/Info/Public'), headers, None, self.timeout
    )
    if not isinstance(result, dict):
      raise ApiError('The server returned an unexpected public response.')
    return result

  def _check_server(self, value: object) -> None:
    if not self.server_id or not isinstance(value, str) or value != self.server_id:
      raise ServerIdentityError

  def authenticate(self, username: str, password: str) -> Account:
    self._check_server(self.server_id)
    response = self._request(
      '/Users/AuthenticateByName',
      method='POST',
      body={'Username': username, 'Pw': password},
    )
    user = response.get('User')
    self._check_server(response.get('ServerId'))
    if (
      not isinstance(user, dict)
      or not text(response.get('AccessToken'))
      or not text(user.get('Id'))
    ):
      raise ApiError('The server returned an incomplete sign-in response.')
    return Account(
      text(response.get('ServerId')),
      text(user.get('Id')),
      text(user.get('Name'), username),
      text(response.get('AccessToken')),
      self.device_id,
    )

  def current_user(self) -> dict[str, Any]:
    self._check_server(self.server_id)
    user = self._request('/Users/Me')
    self._check_server(user.get('ServerId'))
    if self.user_id and user.get('Id') != self.user_id:
      raise AuthError('The saved sign-in belongs to a different account. Sign in again.')
    return user

  def endpoint_is_in_network(self) -> bool:
    """Return Jellyfin's current connection classification without persisting it."""
    value = self._request('/System/Endpoint').get('IsInNetwork')
    if not isinstance(value, bool):
      raise ApiError('The server did not provide a usable network classification.')
    return value

  def language_options(self) -> tuple[LanguageOption, ...]:
    """Return the language vocabulary advertised by this Jellyfin server."""
    try:
      values = tuple(
        LanguageOption.from_dict(item) for item in self._request_array('/Localization/Options')
      )
    except ValueError as error:
      raise ApiError(str(error)) from None
    if not values:
      raise ApiError('The server did not provide any language choices.')
    return values

  def user_configuration(self) -> UserConfiguration:
    try:
      return UserConfiguration.from_user(self.current_user())
    except ValueError as error:
      raise ApiError(str(error)) from None

  def update_user_setting(
    self,
    setting: UserSetting,
    value: str | bool,  # noqa: FBT001 - typed value union.
  ) -> UserConfiguration:
    """Fresh read, narrow mutation, full write, and confirmed fresh read-back."""
    if not isinstance(setting, UserSetting):
      raise TypeError('Unsupported Jellyfin user setting.')
    intended = validated_setting_value(setting, value)
    current = self.current_user()
    raw_configuration = current.get('Configuration')
    if not isinstance(raw_configuration, dict):
      raise ApiError('The server returned invalid user settings.')
    updated = deepcopy(raw_configuration)
    updated[setting.value] = intended
    self._request('/Users/Configuration', method='POST', body=updated)
    confirmed = self.user_configuration()
    if confirmed.value(setting) != intended:
      raise ApiError('The server did not confirm the user-setting change. Please retry.')
    return confirmed

  def autoplay_enabled(self) -> bool:
    """Return the active user's server preference, defaulting only an absent value on."""
    return self.user_autoplay_enabled()

  def user_autoplay_enabled(self) -> bool:
    """Backward-compatible explicit name for the active user's autoplay preference."""
    return parse_user_autoplay_enabled(self.current_user())

  def logout(self) -> None:
    self._request('/Sessions/Logout', method='POST', body={})

  def libraries(self) -> tuple[MediaItem, ...]:
    return self._page('/UserViews', {'UserId': self.user_id}).items

  def items(self, parent_id: str, kind: str, start: int = 0, limit: int = 60) -> Page:
    if kind not in {'Movie', 'Series'}:
      raise ValueError('Library browsing requires Movie or Series items.')
    sort = 'DateCreated' if kind == 'Movie' else 'DateLastContentAdded'
    return self._page(
      '/Items',
      {
        'UserId': self.user_id,
        'ParentId': parent_id,
        'IncludeItemTypes': kind,
        'Recursive': True,
        'StartIndex': max(0, start),
        'Limit': max(1, min(limit, 200)),
        'SortBy': sort + ',SortName',
        'SortOrder': 'Descending',
        'Fields': 'DateCreated,Overview,PrimaryImageAspectRatio',
        'EnableUserData': True,
        'EnableTotalRecordCount': True,
      },
    )

  def seasons(self, series_id: str) -> Page:
    return self._page(
      '/Shows/' + quote(series_id, safe='') + '/Seasons',
      {
        'UserId': self.user_id,
        'Fields': 'Overview',
        'EnableUserData': True,
        'IsMissing': False,
        'IsSpecialSeason': None,
      },
    )

  def episodes(
    self,
    series_id: str,
    season_id: str = '',
    start: int = 0,
    limit: int = 60,
  ) -> Page:
    return self._page(
      '/Shows/' + quote(series_id, safe='') + '/Episodes',
      {
        'UserId': self.user_id,
        'SeasonId': season_id,
        'StartIndex': max(0, start),
        'Limit': max(1, min(limit, 200)),
        'Fields': 'Chapters,Overview,PrimaryImageAspectRatio,Trickplay',
        'EnableImages': True,
        'ImageTypeLimit': 1,
        'EnableUserData': True,
        'EnableTotalRecordCount': True,
        'IsMissing': False,
      },
    )

  def episode_sequence(
    self,
    series_id: str,
    *,
    page_size: int = MAX_EPISODE_PAGE_SIZE,
  ) -> tuple[MediaItem, ...]:
    """Fetch a complete series in the exact episode order supplied by Jellyfin."""
    if isinstance(page_size, bool) or not isinstance(page_size, int) or page_size < 1:
      raise ValueError('The episode page size must be positive.')
    limit = min(page_size, MAX_EPISODE_PAGE_SIZE)
    start = 0
    page_count = 0
    result: list[MediaItem] = []
    while True:
      if page_count >= MAX_EPISODE_SEQUENCE_PAGES:
        raise ApiError('The server returned an episode sequence that is too large.')
      page = self.episodes(series_id, start=start, limit=limit)
      page_count += 1
      if page.start != start:
        raise ApiError('The server returned an inconsistent episode sequence.')
      if (
        page.total > MAX_EPISODE_SEQUENCE_ITEMS
        or len(result) + len(page.items) > MAX_EPISODE_SEQUENCE_ITEMS
      ):
        raise ApiError('The server returned an episode sequence that is too large.')
      result.extend(page.items)
      if start + len(page.items) >= page.total:
        return tuple(result)
      if not page.items:
        raise ApiError('The server returned an incomplete episode sequence.')
      start += len(page.items)

  def item(self, item_id: str) -> MediaItem:
    try:
      return MediaItem.from_dict(
        self._request(
          '/Items/' + quote(item_id, safe=''),
          {'UserId': self.user_id},
        )
      )
    except ValueError:
      raise ApiError('The server returned invalid title details.') from None

  def playback_info(  # noqa: PLR0913 - Jellyfin playback negotiation parameters.
    self,
    item_id: str,
    *,
    start_ticks: int = 0,
    media_source_id: str = '',
    audio_index: int | None = None,
    subtitle_index: int | None = None,
    device_profile: dict[str, Any] | None = None,
    max_streaming_bitrate: int | None = None,
  ) -> dict[str, Any]:
    if max_streaming_bitrate is not None and (
      isinstance(max_streaming_bitrate, bool)
      or not isinstance(max_streaming_bitrate, int)
      or not 1 <= max_streaming_bitrate <= MAX_INT32
    ):
      raise ValueError('The streaming bitrate limit must be a positive 32-bit integer.')
    profile = deepcopy(device_profile if device_profile is not None else kodi_device_profile())
    if max_streaming_bitrate is not None:
      profile['MaxStreamingBitrate'] = max_streaming_bitrate
    body: dict[str, Any] = {
      'UserId': self.user_id,
      'StartTimeTicks': max(0, start_ticks),
      'IsPlayback': True,
      'AutoOpenLiveStream': False,
      'EnableDirectPlay': True,
      'EnableDirectStream': True,
      'EnableTranscoding': True,
      'AllowVideoStreamCopy': True,
      'AllowAudioStreamCopy': True,
      'DeviceProfile': profile,
    }
    if max_streaming_bitrate is not None:
      body['MaxStreamingBitrate'] = max_streaming_bitrate
    selections = (
      ('MediaSourceId', media_source_id or None),
      ('AudioStreamIndex', audio_index),
      ('SubtitleStreamIndex', subtitle_index),
    )
    body.update({key: value for key, value in selections if value is not None})
    return self._request(
      '/Items/' + quote(item_id, safe='') + '/PlaybackInfo', method='POST', body=body
    )

  def segments(self, item_id: str) -> tuple[Segment, ...]:
    data = self._request('/MediaSegments/' + quote(item_id, safe=''))
    values = data.get('Items')
    if not isinstance(values, list):
      raise ApiError('The server returned invalid media segments.')
    result = []
    for value in values:
      if isinstance(value, dict):
        segment = Segment.from_dict(value)
        if segment is not None:
          result.append(segment)
    return tuple(sorted(result, key=lambda segment: segment.start_ticks))

  def report_start(self, payload: dict[str, Any]) -> None:
    self._request('/Sessions/Playing', method='POST', body=payload)

  def report_progress(self, payload: dict[str, Any]) -> None:
    self._request('/Sessions/Playing/Progress', method='POST', body=payload)

  def report_stop(self, payload: dict[str, Any]) -> None:
    self._request('/Sessions/Playing/Stopped', method='POST', body=payload)

  def item_image_url(
    self,
    item_id: str,
    image_type: str = 'Primary',
    width: int = 400,
    *,
    image_index: int | None = None,
    tag: str = '',
  ) -> str:
    if image_index is not None and (
      isinstance(image_index, bool)
      or not isinstance(image_index, int)
      or not 0 <= image_index <= MAX_INT32
    ):
      raise ValueError('The image index must be a non-negative 32-bit integer.')
    path = '/Items/' + quote(item_id, safe='') + '/Images/' + quote(image_type, safe='')
    if image_index is not None:
      path += '/' + str(image_index)
    return self._url(
      path,
      {
        'Tag': tag,
        'MaxWidth': max(1, min(width, 1920)),
      },
    )

  def image_url(self, item: MediaItem, image_type: str = 'Primary', width: int = 400) -> str:
    return self.item_image_url(
      item.id,
      image_type,
      width,
      tag=item.image_tags.get(image_type, ''),
    )

  def chapter_image_url(self, item: MediaItem, chapter: Chapter, width: int = 640) -> str:
    return self.item_image_url(
      item.id,
      'Chapter',
      width,
      image_index=chapter.index,
      tag=chapter.image_tag,
    )

  def trickplay_playlist_url(
    self,
    item_id: str,
    width: int,
    media_source_id: str = '',
  ) -> str:
    if isinstance(width, bool) or not isinstance(width, int) or not 1 <= width <= MAX_INT32:
      raise ValueError('The trickplay width must be a positive 32-bit integer.')
    return self._url(
      '/Videos/' + quote(item_id, safe='') + '/Trickplay/' + str(width) + '/tiles.m3u8',
      {'MediaSourceId': media_source_id},
    )

  def trickplay_tile_url(
    self,
    item_id: str,
    width: int,
    index: int,
    media_source_id: str = '',
  ) -> str:
    if isinstance(width, bool) or not isinstance(width, int) or not 1 <= width <= MAX_INT32:
      raise ValueError('The trickplay width must be a positive 32-bit integer.')
    if isinstance(index, bool) or not isinstance(index, int) or not 0 <= index <= MAX_INT32:
      raise ValueError('The trickplay tile index must be a non-negative 32-bit integer.')
    return self._url(
      '/Videos/' + quote(item_id, safe='') + '/Trickplay/' + str(width) + '/' + str(index) + '.jpg',
      {'MediaSourceId': media_source_id},
    )

  def stream_url(self, item_id: str, media_source_id: str) -> str:
    return self._url(
      '/Videos/' + quote(item_id, safe='') + '/stream',
      {
        'Static': True,
        'MediaSourceId': media_source_id,
      },
    )

  def media_url(self, path: str) -> str:
    """Resolve same-server media; the Kodi adapter supplies auth via headers."""
    resolved = urljoin(self.base_url + '/', path)
    origin, target = urlsplit(self.base_url), urlsplit(resolved)
    if (origin.scheme, origin.netloc) != (target.scheme, target.netloc):
      raise ApiError('The server returned a media address on another server.')
    query = urlencode(
      [
        (key, value)
        for key, value in parse_qsl(target.query, keep_blank_values=True)
        if key.lower().replace('_', '') != 'apikey'
      ]
    )
    return urlunsplit((target.scheme, target.netloc, target.path, query, ''))
