"""Explicit server/account identity and serialization; Kodi owns profile file I/O."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from typing import Any
from urllib.parse import urlsplit, urlunsplit
from uuid import uuid4

ACCOUNT_FORMAT_VERSION = 2


class UnsupportedAccountFormatError(ValueError):
  """A development profile needs an explicit reset, never backup substitution."""


def normalize_url(value: str) -> str:
  if not isinstance(value, str):
    raise TypeError('Enter a complete HTTP or HTTPS server address.')
  try:
    parts = urlsplit(value.strip())
    _ = parts.port  # Access validates malformed or out-of-range ports.
  except ValueError:
    raise ValueError('Enter a valid server address and port.') from None
  if parts.scheme not in {'http', 'https'} or not parts.hostname:
    raise ValueError('Enter a complete HTTP or HTTPS server address.')
  if parts.username or parts.password or parts.query or parts.fragment:
    raise ValueError('Use a server address without credentials, query parameters, or fragments.')
  return urlunsplit((parts.scheme.lower(), parts.netloc.lower(), parts.path.rstrip('/'), '', ''))


@dataclass(frozen=True)
class Server:
  id: str
  addresses: tuple[str, ...] = field(repr=False)
  name: str = 'Jellyfin'

  def __post_init__(self) -> None:
    if any(not isinstance(value, str) for value in (self.id, self.name)):
      raise TypeError('Saved server fields must be text.')
    if not self.id.strip():
      raise ValueError('Saved servers require a server identity.')
    if not isinstance(self.addresses, (tuple, list)) or not self.addresses:
      raise ValueError('Saved servers require an ordered, non-empty address list.')
    object.__setattr__(
      self, 'addresses', tuple(dict.fromkeys(normalize_url(value) for value in self.addresses))
    )


@dataclass(frozen=True)
class Account:
  server_id: str
  user_id: str
  user_name: str = field(repr=False)
  token: str = field(repr=False)
  device_id: str = field(repr=False)

  def __post_init__(self) -> None:
    values = (
      self.server_id,
      self.user_id,
      self.user_name,
      self.token,
      self.device_id,
    )
    if any(not isinstance(value, str) for value in values):
      raise TypeError('Saved account fields must be text.')
    if any(
      not value.strip() for value in (self.server_id, self.user_id, self.token, self.device_id)
    ):
      raise ValueError('Saved accounts require a user, authentication token, and device identity.')


def _records(data: dict[str, Any], key: str) -> list[dict[str, Any]]:
  values = data.get(key, [])
  if not isinstance(values, list) or any(not isinstance(value, dict) for value in values):
    raise ValueError('Saved accounts and servers must be lists of records.')
  return values


def _profile_text(data: dict[str, Any], key: str, default: str, *, allow_empty: bool = True) -> str:
  value = data.get(key, default)
  if not isinstance(value, str):
    raise TypeError('Saved profile identity fields must be text.')
  if not allow_empty and not value.strip():
    raise ValueError('Saved profile identity fields must not be empty.')
  return value


@dataclass
class AccountStore:
  servers: list[Server] = field(default_factory=list)
  accounts: list[Account] = field(default_factory=list, repr=False)
  last_server_id: str = ''
  device_id: str = field(default_factory=lambda: uuid4().hex, repr=False)

  def add_server(self, server: Server) -> None:
    self.servers = [existing for existing in self.servers if existing.id != server.id]
    self.servers.append(server)
    self.last_server_id = server.id

  def save_account(self, account: Account) -> None:
    if not any(server.id == account.server_id for server in self.servers):
      raise ValueError('Saved accounts require a saved server.')
    self.remove_account(account.server_id, account.user_id)
    self.accounts.append(account)
    self.last_server_id = account.server_id

  def accounts_for(self, server_id: str) -> list[Account]:
    return [account for account in self.accounts if account.server_id == server_id]

  def remove_account(self, server_id: str, user_id: str) -> None:
    self.accounts = [
      account
      for account in self.accounts
      if (account.server_id, account.user_id) != (server_id, user_id)
    ]

  def to_json(self) -> str:
    """Serialize secret-bearing profile data; callers must never log this string."""
    return json.dumps({'version': ACCOUNT_FORMAT_VERSION, **asdict(self)}, ensure_ascii=False)

  @classmethod
  def from_json(cls, value: str) -> AccountStore:
    if not value.strip():
      return cls()
    try:
      data: Any = json.loads(value)
    except (TypeError, ValueError) as error:
      raise ValueError(
        'Saved accounts could not be read. The original profile is preserved.'
      ) from error
    if (
      not isinstance(data, dict)
      or type(data.get('version')) is not int
      or data.get('version') != ACCOUNT_FORMAT_VERSION
    ):
      raise UnsupportedAccountFormatError(
        'Unsupported saved-account format. Profile reset required. The original profile is preserved.'
      )
    try:
      return cls._from_data(data)
    except (TypeError, ValueError, KeyError) as error:
      raise ValueError(
        'Saved accounts could not be read. The original profile is preserved.'
      ) from error

  @classmethod
  def _from_data(cls, data: dict[str, Any]) -> AccountStore:
    store = cls()
    for server in _records(data, 'servers'):
      saved = Server(**server)
      if any(existing.id == saved.id for existing in store.servers) or len(saved.addresses) != len(
        server['addresses']
      ):
        raise ValueError('Duplicate saved server or address.')
      store.add_server(saved)
    for account in _records(data, 'accounts'):
      saved_account = Account(**account)
      if any(
        existing.user_id == saved_account.user_id
        for existing in store.accounts_for(saved_account.server_id)
      ):
        raise ValueError('Duplicate saved account.')
      store.save_account(saved_account)
    last = _profile_text(data, 'last_server_id', '')
    if last and not any(server.id == last for server in store.servers):
      raise ValueError('Unknown last server.')
    store.last_server_id = last
    store.device_id = _profile_text(
      data,
      'device_id',
      store.accounts[0].device_id if store.accounts else store.device_id,
      allow_empty=False,
    )
    return store
