"""Remote-first full-screen Settings controller."""

from __future__ import annotations

import queue
import time
from dataclasses import dataclass
from functools import partial
from typing import Callable, cast

import xbmcaddon
import xbmcgui

from jelk.client import ApiError, JellyfinClient
from jelk.delivery import SETTINGS_DELIVERY_SECONDS, Credential, Delivery, captured_client
from jelk.kodi.log import event
from jelk.kodi.settings import AddonSettings, KodiSettingsPage, open_kodi_settings
from jelk.kodi.surfaces import NativeDialogs, SurfaceWindow, foreground, selected_position
from jelk.preferences import (
  BITRATE_LIMITS_BPS,
  AccountScope,
  MediaSegmentType,
  NetworkContext,
  Preferences,
  SegmentPolicy,
  format_bitrate,
)
from jelk.server_settings import (
  SUBTITLE_MODE_LABELS,
  LanguageOption,
  ServerSettingsCache,
  SubtitleMode,
  UserConfiguration,
  UserSetting,
)
from jelk.work import Failure, WorkCoordinator, WorkScope

CATEGORIES = 300
ROWS = 301
HEADING = 302
IDENTITY = 303
STATUS = 304
HELP = 305
BACK_ACTIONS = {9, 10, 92}

POLICY_LABELS = {
  SegmentPolicy.AUTOMATIC: 'Automatically skip',
  SegmentPolicy.PROMPT: 'Ask to skip',
  SegmentPolicy.INACTIVE: 'Do nothing',
}

SETTING_NAMES = {
  UserSetting.AUDIO_LANGUAGE: 'Preferred audio language',
  UserSetting.PLAY_DEFAULT_AUDIO: 'Source-default audio',
  UserSetting.SUBTITLE_LANGUAGE: 'Preferred subtitle language',
  UserSetting.SUBTITLE_MODE: 'Subtitle mode',
  UserSetting.NEXT_EPISODE_AUTOPLAY: 'Next episode autoplay',
}


@dataclass(frozen=True)
class SettingsServerState:
  network_context: NetworkContext
  configuration: UserConfiguration
  languages: tuple[LanguageOption, ...]


@dataclass
class SettingRow:
  label: str
  value: str
  description: str
  action: Callable[[], None] | None
  server_setting: UserSetting | None = None


@dataclass(frozen=True)
class Category:
  name: str
  rows: Callable[[], list[SettingRow]]


class SettingsWindow(SurfaceWindow, xbmcgui.WindowXML):
  commands: queue.Queue[tuple[str, int, int | None]]

  def onInit(self) -> None:  # noqa: N802 - Kodi callback name.
    self.commands.put((self.initialise(), 0, None))

  def onClick(self, control_id: int) -> None:  # noqa: N802 - Kodi callback name.
    if not self.invalidated and foreground(self):
      self.commands.put(('click', control_id, selected_position(self, control_id)))

  def onAction(self, action: xbmcgui.Action) -> None:  # noqa: N802 - Kodi callback name.
    if action.getId() in BACK_ACTIONS and not self.invalidated and foreground(self):
      self.commands.put(('back', 0, None))


class SettingsController:
  def __init__(  # noqa: PLR0913, PLR0917 - explicit authority/context dependencies.
    self,
    addon: xbmcaddon.Addon,
    window: SettingsWindow,
    client: JellyfinClient,
    scope: AccountScope,
    server_name: str,
    user_name: str,
    preferences: Preferences,
    persist_preferences: Callable[[], None],
    cache: ServerSettingsCache,
    dialogs: NativeDialogs,
    work: WorkCoordinator,
    parent: WorkScope | None = None,
    *,
    current: Callable[[], bool] = lambda: True,
    authentication_failed: Callable[[], bool] = lambda: False,
    sign_in: Callable[[], None] = lambda: None,
    connection_failed: Callable[[], bool] = lambda: False,
    reconnect: Callable[[], None] = lambda: None,
    report_failure: Callable[[str, str], None] | None = None,
  ) -> None:
    self.window = window
    self.dialogs = dialogs
    self.client = client
    self.current = current
    self.authentication_failed = authentication_failed
    self.sign_in = sign_in
    self.connection_failed = connection_failed
    self.reconnect = reconnect
    self.connection_required = False
    self.report_failure = report_failure or dialogs.message
    self.authentication_required = False
    self.scope = scope
    self.server_name = server_name
    self.user_name = user_name
    self.preferences = preferences
    self.persist_preferences = persist_preferences
    self.cache = cache
    self.addon_settings = AddonSettings(addon)
    self.work = work
    self.visit = WorkScope(parent=parent)
    self.read = WorkScope(parent=self.visit)
    self.paint_pending = False
    self.pending_setting: UserSetting | None = None
    self.retry_update: tuple[UserSetting, str | bool] | None = None
    self.configuration: UserConfiguration | None = None
    self.languages: tuple[LanguageOption, ...] = ()
    self.network_context = NetworkContext.REMOTE
    self.write_failure: Failure | None = None
    self.status_text = ''
    self.closed = False
    self.ready = False
    self.load_started = False
    self.last_focus = CATEGORIES
    self.category_index = 0
    self.last_category_position = -1
    self.last_row_position = -1
    self.rows: list[SettingRow] = []
    self.categories = (
      Category('General', self._general_rows),
      Category('Playback', self._playback_rows),
      Category('Segment actions', self._segment_rows),
      Category('Episodes', self._episode_rows),
      Category('Kodi settings', self._kodi_rows),
      Category('Diagnostics', self._diagnostic_rows),
    )

  def poll(self) -> None:
    if not self.visit.alive:
      self.closed = True
    if self.closed or self.window.invalidated:
      return
    self._commands()
    if self.closed or self.window.invalidated or not self.ready:
      return
    if not self.load_started and not self.work.writing(self.scope):
      self._start_load(refresh=False)
    if self.paint_pending and foreground(self.window):
      self._status(self.status_text)
      self._render_rows()
    if self.ready:
      self._selection()

  def close(self) -> None:
    self.closed = True
    self.visit.dispose()
    self.read.dispose()
    self.window.close()

  def _commands(self) -> None:
    while not self.window.commands.empty():
      kind, control_id, position = self.window.commands.get_nowait()
      if kind == 'ready' and not self.ready:
        self.ready = True
        cast('xbmcgui.ControlLabel', self.window.getControl(HEADING)).setLabel('Settings')
        cast('xbmcgui.ControlLabel', self.window.getControl(IDENTITY)).setLabel(
          self.server_name + ' · ' + self.user_name
        )
        self._status(self.status_text)
        self._render_categories()
        self._render_rows(selected=max(0, self.last_row_position))
        self.last_category_position = self.category_index
        self.window.setFocusId(self.last_focus)
        if not self.load_started:
          self._start_load(refresh=False)
      elif kind == 'back':
        self.visit.dispose()
        self.read.dispose()
        self.closed = True
        return
      elif kind == 'click' and control_id == CATEGORIES and position is not None:
        self._set_category(position, focus_rows=True)
      elif kind == 'click' and control_id == ROWS and position is not None:
        if 0 <= position < len(self.rows):
          action = self.rows[position].action
          if action is not None:
            action()
            if not self.visit.alive:
              return

  def _status(self, value: str) -> None:
    self.status_text = value
    if self._visible():
      cast('xbmcgui.ControlLabel', self.window.getControl(STATUS)).setLabel(value)
    else:
      self.paint_pending = True

  def _selection(self) -> None:
    category_position = selected_position(self.window, CATEGORIES)
    if category_position is None:
      return
    self.last_focus = self.window.getFocusId()
    if category_position != self.last_category_position:
      self.last_category_position = category_position
      self._set_category(category_position, focus_rows=False)
    row_position = selected_position(self.window, ROWS)
    if row_position is None:
      return
    if row_position != self.last_row_position:
      self.last_row_position = row_position
      description = (
        self.rows[row_position].description if 0 <= row_position < len(self.rows) else ''
      )
      cast('xbmcgui.ControlTextBox', self.window.getControl(HELP)).setText(description)

  def _set_category(self, index: int, *, focus_rows: bool) -> None:
    if not 0 <= index < len(self.categories):
      return
    self.category_index = index
    self.last_row_position = -1
    self._render_rows()
    if focus_rows and self.rows:
      self.window.setFocusId(ROWS)

  def _visible(self) -> bool:
    return (
      self.visit.alive and self.ready and not self.window.invalidated and foreground(self.window)
    )

  def _server_status(self) -> None:
    if self.connection_required:
      self._status('Reconnect · The server identity changed. Reopen Settings after reconnecting.')
    elif self.authentication_required:
      self._status('Sign in again · Reopen Settings and explicitly reapply any unconfirmed change')
    elif self.write_failure is not None:
      self._status('Jellyfin save unconfirmed · Select the failed setting to retry')
    elif self.pending_setting is not None:
      self._status('Saving to Jellyfin…')
    elif self.read.busy:
      self._status('Loading Jellyfin user settings…')
    elif self.read.failure is not None:
      self._status('Jellyfin settings unavailable · Select a server-owned row to retry')
    else:
      self._status(
        'Current connection: '
        + ('Home network' if self.network_context is NetworkContext.IN_NETWORK else 'Internet')
      )

  def _start_load(self, *, refresh: bool) -> None:
    if not self.visit.alive or self.read.busy:
      return
    if self.work.writing(self.scope):
      self._status('Waiting for the earlier Jellyfin save…')
      return
    self.load_started = True
    self.work.submit(
      self.read,
      partial(self._load_server_state, refresh),
      self._loaded,
      partial(self._start_load, refresh=True),
      self._load_failed,
      lambda: self.visit.alive and self.current(),
    )
    self._server_status()
    self._render_rows()

  def _loaded(self, state: SettingsServerState) -> None:
    self.configuration = state.configuration
    self.languages = state.languages
    self.network_context = state.network_context
    self._server_status()
    self._render_rows()

  def _load_failed(self, failure: Failure) -> None:
    self._recovery_failure(failure)
    self._server_status()
    self._render_rows()

  def _recovery_failure(self, failure: Failure) -> None:
    if failure.connection:
      required = self.connection_failed()
      if self.visit.alive:
        self.connection_required = required
    if failure.authentication:
      required = self.authentication_failed()
      if self.visit.alive:
        self.authentication_required = required

  def _load_server_state(
    self,
    refresh: bool,  # noqa: FBT001 - submitted background-job argument.
  ) -> SettingsServerState:
    try:
      context = (
        NetworkContext.IN_NETWORK if self.client.endpoint_is_in_network() else NetworkContext.REMOTE
      )
    except (ApiError, OSError, ValueError):
      context = NetworkContext.REMOTE
      event('Jellyfin endpoint classification was unavailable; using Internet quality.')
    configuration = self.cache.user_configuration(
      self.scope, self.client.user_configuration, refresh=refresh
    )
    languages = self.cache.languages(self.scope, self.client.language_options, refresh=refresh)
    return SettingsServerState(context, configuration, languages)

  def _server_update(
    self,
    setting: UserSetting,
    value: str | bool,  # noqa: FBT001 - typed value union.
  ) -> None:
    if not self.visit.alive or self.work.writing(self.scope) or self.read.busy:
      return
    # Copy scalar identity/credential fields now; only the transport is shared.
    credential = Credential.of(self.client)
    if (
      not self.work.accepts(credential)
      or not self.current()
      or self.authentication_required
      or self.connection_required
    ):
      return
    delivery = Delivery(time.monotonic() + SETTINGS_DELIVERY_SECONDS)
    client = captured_client(self.client, delivery)
    cache, scope = self.cache, self.scope
    cache.invalidate(scope)

    def deliver() -> UserConfiguration:
      try:
        return client.update_user_setting(setting, value)
      finally:
        # Also runs after visit/process UI disposal. A new visit must confirm
        # uncertain POST/read-back outcomes instead of trusting an older cache.
        cache.invalidate(scope)

    self.pending_setting = setting
    self.write_failure = None
    self.retry_update = (setting, value)

    def outcome(failure: Failure | None) -> None:
      if failure is None:
        return
      self._recovery_failure(failure)
      if not self.visit.alive:
        self.report_failure(
          'Jellyfin save unconfirmed',
          self.server_name
          + ' · '
          + self.user_name
          + ' · '
          + SETTING_NAMES[setting]
          + ': the change could not be confirmed. Reopen Settings to check it.',
        )

    self.work.submit_write(
      scope,
      self.visit,
      deliver,
      self._updated,
      self._update_failed,
      delivery=delivery,
      credential=credential,
      outcome=outcome,
    )
    self._server_status()
    self._render_rows()

  def _updated(self, configuration: UserConfiguration) -> None:
    self.pending_setting = None
    self.configuration = configuration
    self.retry_update = None
    self.write_failure = None
    self._status('Saved to Jellyfin')
    self._render_rows()

  def _update_failed(self, failure: Failure) -> None:
    self.pending_setting = None
    self.write_failure = failure
    self._server_status()
    self._render_rows()

  def _server_action(
    self, setting: UserSetting, action: Callable[[], None]
  ) -> Callable[[], None] | None:
    if self.connection_required or self.authentication_required:
      return self.reconnect if self.connection_required else self.sign_in
    if self.work.writing(self.scope) or self.read.busy:
      return None
    if self.write_failure is not None:
      if self.retry_update is not None and self.retry_update[0] is setting:
        return partial(self._server_update, *self.retry_update)
      return partial(self._start_load, refresh=True)
    if self.read.failure is not None:
      return self.read.retry
    return action if self.configuration is not None else partial(self._start_load, refresh=True)

  def _server_value(self, setting: UserSetting, confirmed: str) -> str:
    if self.connection_required:
      return 'Reconnect'
    if self.authentication_required:
      return 'Sign in again'
    if self.pending_setting is setting:
      return 'Saving…'
    if (
      self.write_failure is not None
      and self.retry_update is not None
      and self.retry_update[0] is setting
    ):
      return (confirmed + ' · ' if confirmed else '') + 'Save unconfirmed · Retry'
    if self.read.failure is not None or self.configuration is None:
      return (confirmed + ' · ' if confirmed else '') + 'Unavailable · Retry'
    return confirmed

  def _render_categories(self) -> None:
    control = self._category_list()
    control.reset()
    for category in self.categories:
      control.addItem(xbmcgui.ListItem(label=category.name))
    control.selectItem(self.category_index)

  def _render_rows(self, *, selected: int | None = None) -> None:
    if not self._visible():
      self.paint_pending = True
      return
    self.paint_pending = False
    self.rows = self.categories[self.category_index].rows()
    control = self._row_list()
    if selected is None:
      selected = selected_position(self.window, ROWS)
    selected = max(0, self.last_row_position if selected is None else selected)
    control.reset()
    for row in self.rows:
      item = xbmcgui.ListItem(label=row.label, label2=row.value)
      if row.action is None:
        item.setProperty('disabled', 'true')
      control.addItem(item)
    if self.rows:
      control.selectItem(min(selected, len(self.rows) - 1))
    self.last_row_position = -1

  def _general_rows(self) -> list[SettingRow]:
    enabled = self.addon_settings.launch_on_start
    return [
      SettingRow(
        'Launch on Kodi startup',
        _enabled(enabled),
        'Kodi stores this for the active Kodi profile. The native add-on settings dialog '
        'edits the same value.',
        partial(self._set_launch_on_start, not enabled),
      )
    ]

  def _playback_rows(self) -> list[SettingRow]:
    configuration = self.configuration
    audio = configuration.audio_language if configuration else ''
    subtitle = configuration.subtitle_language if configuration else ''
    mode = configuration.subtitle_mode if configuration else SubtitleMode.DEFAULT
    default_audio = configuration.play_default_audio if configuration else True
    return [
      self._quality_row('Home network quality', NetworkContext.IN_NETWORK),
      self._quality_row('Internet quality', NetworkContext.REMOTE),
      SettingRow(
        'Preferred audio language',
        self._server_value(UserSetting.AUDIO_LANGUAGE, self._language_name(audio)),
        'Stored in this Jellyfin user configuration and shared with other Jellyfin clients.',
        self._server_action(
          UserSetting.AUDIO_LANGUAGE,
          partial(self._select_language, UserSetting.AUDIO_LANGUAGE),
        ),
        UserSetting.AUDIO_LANGUAGE,
      ),
      SettingRow(
        'Play source-default audio regardless of language',
        self._server_value(UserSetting.PLAY_DEFAULT_AUDIO, _enabled(default_audio)),
        'Stored in this Jellyfin user configuration. A source-default track can take '
        'priority over the preferred language.',
        self._server_action(
          UserSetting.PLAY_DEFAULT_AUDIO,
          partial(self._server_update, UserSetting.PLAY_DEFAULT_AUDIO, not default_audio),
        ),
        UserSetting.PLAY_DEFAULT_AUDIO,
      ),
      SettingRow(
        'Preferred subtitle language',
        self._server_value(UserSetting.SUBTITLE_LANGUAGE, self._language_name(subtitle)),
        'Stored in this Jellyfin user configuration and shared with other Jellyfin clients.',
        self._server_action(
          UserSetting.SUBTITLE_LANGUAGE,
          partial(self._select_language, UserSetting.SUBTITLE_LANGUAGE),
        ),
        UserSetting.SUBTITLE_LANGUAGE,
      ),
      SettingRow(
        'Subtitle mode',
        self._server_value(UserSetting.SUBTITLE_MODE, SUBTITLE_MODE_LABELS[mode]),
        'Jellyfin uses this mode with the preferred subtitle language and stream metadata.',
        self._server_action(UserSetting.SUBTITLE_MODE, self._select_subtitle_mode),
        UserSetting.SUBTITLE_MODE,
      ),
    ]

  def _quality_row(self, label: str, context: NetworkContext) -> SettingRow:
    value = self.preferences.player.bitrate_limits.for_context(context)
    applicable = context is self.network_context and self.configuration is not None
    rendered = format_bitrate(value) + (' · Current connection' if applicable else '')
    return SettingRow(
      label,
      rendered,
      'This installation-local value caps Jellyfin negotiation for this connection '
      "profile. Unlimited removes jelk's selected cap; it does not promise Direct Play.",
      partial(self._select_quality, context),
    )

  def _segment_rows(self) -> list[SettingRow]:
    result = []
    for segment_type in MediaSegmentType:
      policy = self.preferences.player.media_segment_policy(self.scope, segment_type)
      result.append(
        SettingRow(
          segment_type.value,
          POLICY_LABELS[policy],
          'Stored only on this Kodi profile for this Jellyfin server and user.',
          partial(self._select_segment_policy, segment_type),
        )
      )
    return result

  def _episode_rows(self) -> list[SettingRow]:
    configuration = self.configuration
    autoplay = configuration.next_episode_autoplay if configuration else True
    return [
      SettingRow(
        'Play next episode automatically',
        self._server_value(UserSetting.NEXT_EPISODE_AUTOPLAY, _enabled(autoplay)),
        'Stored in this Jellyfin user configuration. Playback fetches a fresh value '
        'before deciding whether to advance.',
        self._server_action(
          UserSetting.NEXT_EPISODE_AUTOPLAY,
          partial(self._server_update, UserSetting.NEXT_EPISODE_AUTOPLAY, not autoplay),
        ),
        UserSetting.NEXT_EPISODE_AUTOPLAY,
      )
    ]

  def _kodi_rows(self) -> list[SettingRow]:
    return [
      SettingRow(
        'Caching',
        'Open Kodi Services / Caching',
        "Opens Kodi's native cache controls. jelk does not read or change those values.",
        partial(open_kodi_settings, KodiSettingsPage.CACHING),
      ),
      SettingRow(
        'Video playback',
        'Open Kodi Player / Videos',
        "Opens Kodi's native video playback controls without changing them.",
        partial(open_kodi_settings, KodiSettingsPage.VIDEO_PLAYBACK),
      ),
      SettingRow(
        'Audio output',
        'Open Kodi System / Audio',
        "Opens Kodi's native audio output controls without changing them.",
        partial(open_kodi_settings, KodiSettingsPage.AUDIO_OUTPUT),
      ),
    ]

  def _diagnostic_rows(self) -> list[SettingRow]:
    enabled = self.addon_settings.debug_logging
    return [
      SettingRow(
        'jelk debug logging',
        _enabled(enabled),
        "Adds jelk-specific diagnostic messages. Kodi's global debug setting is not changed.",
        partial(self._set_debug_logging, not enabled),
      )
    ]

  def _set_launch_on_start(self, enabled: bool) -> None:  # noqa: FBT001 - callback value.
    self.addon_settings.launch_on_start = enabled
    self._render_rows()

  def _set_debug_logging(self, enabled: bool) -> None:  # noqa: FBT001 - callback value.
    self.addon_settings.debug_logging = enabled
    self._render_rows()

  def _select(self, work: Callable[[], int], done: Callable[[int], None]) -> None:
    def accept(selected: int) -> None:
      if self.visit.alive and not self.window.invalidated:
        done(selected)

    self.dialogs.request(work, accept)

  def _select_quality(self, context: NetworkContext) -> None:
    current = self.preferences.player.bitrate_limits.for_context(context)
    preselect = BITRATE_LIMITS_BPS.index(current) if current in BITRATE_LIMITS_BPS else 0
    self._select(
      partial(
        xbmcgui.Dialog().select,
        'Select quality limit',
        [format_bitrate(value) for value in BITRATE_LIMITS_BPS],
        preselect=preselect,
      ),
      partial(self._select_quality_chosen, context),
    )

  def _select_quality_chosen(self, context: NetworkContext, selected: int) -> None:
    if 0 <= selected < len(BITRATE_LIMITS_BPS):
      self.preferences.player.set_bitrate_limit(context, BITRATE_LIMITS_BPS[selected])
      self.persist_preferences()
      self._render_rows()

  def _select_segment_policy(self, segment_type: MediaSegmentType) -> None:
    policies = tuple(SegmentPolicy)
    current = self.preferences.player.media_segment_policy(self.scope, segment_type)
    self._select(
      partial(
        xbmcgui.Dialog().select,
        segment_type.value + ' action',
        [POLICY_LABELS[value] for value in policies],
        preselect=policies.index(current),
      ),
      partial(self._select_segment_policy_chosen, segment_type, policies),
    )

  def _select_segment_policy_chosen(
    self, segment_type: MediaSegmentType, policies: tuple[SegmentPolicy, ...], selected: int
  ) -> None:
    if 0 <= selected < len(policies):
      self.preferences.player.set_media_segment_policy(self.scope, segment_type, policies[selected])
      self.persist_preferences()
      self._render_rows()

  def _language_choices(self, setting: UserSetting) -> tuple[LanguageOption, ...]:
    choices = [LanguageOption('No preference', '')]
    if setting is UserSetting.AUDIO_LANGUAGE:
      choices.append(LanguageOption('Original language', 'OriginalLanguage'))
    choices.extend(self.languages)
    current = ''
    if self.configuration is not None:
      current_value = self.configuration.value(setting)
      current = current_value if isinstance(current_value, str) else ''
    if current and all(option.value != current for option in choices):
      choices.insert(1, LanguageOption('Current server value (' + current + ')', current))
    deduplicated: dict[str, LanguageOption] = {}
    for option in choices:
      deduplicated.setdefault(option.value, option)
    return tuple(deduplicated.values())

  def _select_language(self, setting: UserSetting) -> None:
    if self.configuration is None:
      return
    choices = self._language_choices(setting)
    current = cast('str', self.configuration.value(setting))
    self._select(
      partial(
        xbmcgui.Dialog().select,
        'Select language',
        [choice.name for choice in choices],
        preselect=next(
          (index for index, choice in enumerate(choices) if choice.value == current), 0
        ),
      ),
      partial(self._select_language_chosen, setting, choices, current),
    )

  def _select_language_chosen(
    self, setting: UserSetting, choices: tuple[LanguageOption, ...], current: str, selected: int
  ) -> None:
    if 0 <= selected < len(choices) and choices[selected].value != current:
      self._server_update(setting, choices[selected].value)

  def _select_subtitle_mode(self) -> None:
    if self.configuration is None:
      return
    modes = tuple(SubtitleMode)
    current = self.configuration.subtitle_mode
    self._select(
      partial(
        xbmcgui.Dialog().select,
        'Select subtitle mode',
        [SUBTITLE_MODE_LABELS[mode] for mode in modes],
        preselect=modes.index(current),
      ),
      partial(self._select_subtitle_mode_chosen, modes, current),
    )

  def _select_subtitle_mode_chosen(
    self, modes: tuple[SubtitleMode, ...], current: SubtitleMode, selected: int
  ) -> None:
    if 0 <= selected < len(modes) and modes[selected] is not current:
      self._server_update(UserSetting.SUBTITLE_MODE, modes[selected].value)

  def _language_name(self, value: str) -> str:
    if not value:
      return 'No preference'
    if value == 'OriginalLanguage':
      return 'Original language'
    return next((choice.name for choice in self.languages if choice.value == value), value)

  def _category_list(self) -> xbmcgui.ControlList:
    return cast('xbmcgui.ControlList', self.window.getControl(CATEGORIES))

  def _row_list(self) -> xbmcgui.ControlList:
    return cast('xbmcgui.ControlList', self.window.getControl(ROWS))


def _enabled(value: bool) -> str:  # noqa: FBT001 - formatter input.
  return 'Enabled' if value else 'Disabled'
