"""Process ownership and the one coordinating loop for every jelk surface."""

from __future__ import annotations

import queue
import time
from functools import partial
from uuid import uuid4

import xbmc
import xbmcaddon
import xbmcgui

from jelk.delivery import DRAIN_SECONDS
from jelk.kodi.application import Application, ApplicationWindow
from jelk.kodi.dev_state import DevelopmentState
from jelk.kodi.log import event
from jelk.kodi.skin import activate_companion_skin
from jelk.kodi.surfaces import NativeDialogs
from jelk.network import PROCESS_NETWORK

ACTIVE_PROPERTY = 'jelk.active'
PLAYING_PROPERTY = 'jelk.playing'
DRAINING_PROPERTY = 'jelk.draining'
ABORT_DRAIN_SECONDS = 3.0
RELAUNCH_WAIT_SECONDS = DRAIN_SECONDS + 1.5
# The claim is refreshed while jelk runs so an instance that loses its window,
# and therefore can no longer be exited from the UI, stops blocking a relaunch.
CLAIM_HEARTBEAT_SECONDS = 1.0
CLAIM_STALE_SECONDS = 5.0
# Launching jelk while it already runs asks the running instance to come forward
# rather than replacing it; only an instance that cannot answer is restarted.
FRONT_PROPERTY = 'jelk.front'
FRONT_WAIT_SECONDS = 2.5


def _claim_text(token: str) -> str:
  return token + ':' + repr(time.monotonic())


def _claim_parts(value: str) -> tuple[str, float] | None:
  """Read a claim, treating anything unrecognised as abandoned."""
  token, separator, stamp = value.partition(':')
  if not token or not separator:
    return None
  try:
    return token, float(stamp)
  except ValueError:
    return None


def claim_single_instance(home: xbmcgui.Window, *, force: bool = False) -> str | None:
  """
  Take the single-instance claim, or return None if a live instance holds it.

  Staleness only catches an instance whose loop has stopped. One that has lost
  its window keeps its claim fresh while being unreachable, so `force` exists to
  let the user hand the claim over; the displaced instance stands down when it
  next sees a token that is not its own.
  """
  parts = _claim_parts(home.getProperty(ACTIVE_PROPERTY))
  if not force and parts is not None and time.monotonic() - parts[1] <= CLAIM_STALE_SECONDS:
    return None
  token = uuid4().hex
  home.setProperty(ACTIVE_PROPERTY, _claim_text(token))
  return token


def holds_claim(home: xbmcgui.Window, token: str) -> bool:
  parts = _claim_parts(home.getProperty(ACTIVE_PROPERTY))
  return parts is not None and parts[0] == token


def ask_running_instance_forward(home: xbmcgui.Window) -> bool:
  """Ask the running instance to show itself, and report whether it answered."""
  home.setProperty(FRONT_PROPERTY, '1')
  monitor = xbmc.Monitor()
  deadline = time.monotonic() + FRONT_WAIT_SECONDS
  while time.monotonic() < deadline:
    if monitor.waitForAbort(0.1):
      return True
    if not home.getProperty(FRONT_PROPERTY):
      return True
  home.clearProperty(FRONT_PROPERTY)
  return False


def draining_claim(home: xbmcgui.Window) -> bool:
  parts = _claim_parts(home.getProperty(ACTIVE_PROPERTY))
  return (
    parts is not None
    and time.monotonic() - parts[1] <= CLAIM_STALE_SECONDS
    and home.getProperty(DRAINING_PROPERTY) == parts[0]
  )


def wait_for_draining_claim(home: xbmcgui.Window) -> str | None:
  observed = _claim_parts(home.getProperty(ACTIVE_PROPERTY))
  xbmcgui.Dialog().notification('jelk', 'Finishing pending changes…')
  monitor = xbmc.Monitor()
  deadline = time.monotonic() + RELAUNCH_WAIT_SECONDS
  while not monitor.abortRequested() and time.monotonic() < deadline:
    token = claim_single_instance(home)
    if token is not None:
      return token
    current = _claim_parts(home.getProperty(ACTIVE_PROPERTY))
    if current is not None and observed is not None and current[0] != observed[0]:
      # A different live owner acquired the slot. Never displace it.
      return None
    # Release consists of separate property writes. A missing draining marker
    # on the observed owner must not consume the launch in that short interval.
    if monitor.waitForAbort(0.1):
      return None
  return None


def acquire_claim(home: xbmcgui.Window) -> str | None:  # noqa: PLR0911 - distinct lease transitions.
  """Claim the instance slot, preferring to surface whatever is already running."""
  token = claim_single_instance(home)
  if token is not None:
    return token
  if draining_claim(home):
    return wait_for_draining_claim(home)
  answered = ask_running_instance_forward(home)
  if draining_claim(home):
    return wait_for_draining_claim(home)
  # The old owner may have released while answering the foreground request.
  token = claim_single_instance(home)
  if token is not None:
    return token
  if answered:
    return None
  if not xbmcgui.Dialog().yesno(
    'Restart jelk?',
    'jelk is already running but is not responding.',
    defaultbutton=xbmcgui.DLG_YESNO_YES_BTN,
  ):
    return None
  token = claim_single_instance(home, force=True)
  if token is not None:
    # Let the displaced instance notice and release its window first.
    xbmc.Monitor().waitForAbort(CLAIM_HEARTBEAT_SECONDS + 0.5)
  return token


class Runtime:
  def __init__(self, application: Application | None, home: xbmcgui.Window, token: str) -> None:
    self.application = application
    self.home = home
    self.token = token
    self.claim_due = 0.0
    self.monitor = xbmc.Monitor()
    self.activation = NativeDialogs()
    self.development: DevelopmentState | None = None
    self.closed = False

  def hold_claim(self) -> bool:
    now = time.monotonic()
    if not holds_claim(self.home, self.token):
      event('Another jelk instance took over; stopping this one.')
      return False
    if now < self.claim_due:
      return True
    self.home.setProperty(ACTIVE_PROPERTY, _claim_text(self.token))
    self.claim_due = now + CLAIM_HEARTBEAT_SECONDS
    return True

  def tick(self) -> bool:
    if not self.hold_claim():
      return False
    if self.home.getProperty(FRONT_PROPERTY):
      self.home.clearProperty(FRONT_PROPERTY)
      if self.application is not None:
        self.application.foreground()
    self.activation.poll()
    if self.application is not None:
      self.application.poll()
      return not self.application.closed
    return not self.closed

  def _activated(self, accepted: bool) -> None:  # noqa: FBT001 - native activation result.
    if not accepted:
      self.closed = True
      return
    self.development = DevelopmentState(self.home)
    self.development.start_application()
    addon = xbmcaddon.Addon()
    window = ApplicationWindow(
      'script-jelk-main.xml', addon.getAddonInfo('path'), 'Default', '1080i'
    )
    window.commands = queue.Queue()
    self.application = Application(addon, window)
    self.application.foreground()

  def run(self) -> None:
    try:
      if self.application is None:
        self.activation.request(partial(activate_companion_skin, self.home), self._activated)
      else:
        self.application.foreground()
      while not self.monitor.abortRequested() and self.tick():
        self.monitor.waitForAbort(0.05)
    finally:
      try:
        self._drain()
      finally:
        # Also interrupt abandoned reads/images when no writes needed draining,
        # or when close/poll raises. Cancellation belongs to the whole invocation.
        PROCESS_NETWORK.cancel()
        self.activation.close()

  def _drain(self) -> None:
    if self.application is None:
      return
    if holds_claim(self.home, self.token):
      self.home.setProperty(DRAINING_PROPERTY, self.token)
    self.application.close()
    abort_deadline = None
    while True:
      if self.monitor.abortRequested() and abort_deadline is None:
        abort_deadline = time.monotonic() + ABORT_DRAIN_SECONDS
        self.application.limit_shutdown(abort_deadline)
      if self.hold_claim() and self.home.getProperty(FRONT_PROPERTY):
        self.home.clearProperty(FRONT_PROPERTY)
      if not self.application.poll_shutdown():
        break
      # waitForAbort returns immediately after abort; avoid a busy loop.
      time.sleep(0.05)


def release_claim(home: xbmcgui.Window, token: str, development: DevelopmentState | None) -> None:
  if home.getProperty(DRAINING_PROPERTY) == token:
    home.clearProperty(DRAINING_PROPERTY)
  if holds_claim(home, token):
    if development is not None:
      development.clear()
    home.clearProperty(ACTIVE_PROPERTY)
    home.clearProperty(PLAYING_PROPERTY)
    home.clearProperty(FRONT_PROPERTY)


def run() -> None:
  home = xbmcgui.Window(10000)
  token = acquire_claim(home)
  if token is None:
    return
  runtime = Runtime(None, home, token)
  try:
    runtime.run()
  except Exception:  # noqa: BLE001 - Top-level Kodi boundary; never log secret-bearing exception objects.
    event('The application stopped unexpectedly.', error=True)
    xbmcgui.Dialog().ok('jelk', 'jelk stopped unexpectedly. You can launch it again from Kodi.')
  finally:
    # A superseded instance must not clear state the newer one now owns.
    release_claim(home, token, runtime.development)
