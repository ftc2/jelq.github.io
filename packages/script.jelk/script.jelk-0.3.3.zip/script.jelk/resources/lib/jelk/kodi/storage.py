from __future__ import annotations

import json
import threading
from uuid import uuid4

import xbmcvfs

from jelk.accounts import ACCOUNT_FORMAT_VERSION, AccountStore, UnsupportedAccountFormatError
from jelk.preferences import Preferences, UnsupportedPreferenceVersionError


class UnsupportedProfileError(UnsupportedAccountFormatError):
  """A newer profile must not be replaced with an older backup."""


class ProfileStorage:
  """Save only in Kodi's profile, with a recoverable previous version."""

  def __init__(self, profile: str) -> None:
    self.profile = profile.rstrip('/') + '/'
    self.path = self.profile + 'accounts.json'
    self.reset_marker = self.path + '.reset-pending'
    self.lock = threading.Lock()

  def read(self) -> str:
    with self.lock:
      return self._read()

  def _read(self) -> str:
    if xbmcvfs.exists(self.reset_marker):
      raise UnsupportedProfileError('The profile reset is incomplete. Saved files are preserved.')
    found = False
    for path in (self.path, self.path + '.bak'):
      if xbmcvfs.exists(path):
        found = True
        try:
          return self._read_valid(path)
        except UnsupportedProfileError:
          raise
        except (OSError, ValueError):
          continue
    if found:
      raise ValueError('Saved accounts could not be read. The original profile is preserved.')
    return ''

  def reset_unsupported(self) -> None:
    """Explicit confirmed reset; a marker keeps interrupted stages behind the load barrier."""
    with self.lock:
      try:
        self._read()
      except UnsupportedProfileError:
        pass
      else:
        raise ValueError('The saved profile changed. Reload it before resetting.')
      suffix = uuid4().hex
      temporary = self.path + '.reset-' + suffix + '.tmp'
      content = AccountStore().to_json()
      with xbmcvfs.File(temporary, 'w') as handle:
        if not handle.write(content):
          raise OSError('Could not prepare an empty account profile.')
      if self._read_valid(temporary) != content:
        raise OSError('Could not verify the empty account profile.')
      with xbmcvfs.File(self.reset_marker, 'w') as handle:
        if not handle.write('pending'):
          raise OSError('Could not mark the account reset as pending.')
      for path in (self.path, self.path + '.bak'):
        if xbmcvfs.exists(path) and not xbmcvfs.rename(path, path + '.unsupported-' + suffix):
          raise OSError('Could not preserve saved account files. Reset is incomplete.')
      if not xbmcvfs.rename(temporary, self.path):
        raise OSError('Could not finish the account reset. Saved files are preserved.')
      if not xbmcvfs.delete(self.reset_marker):
        raise OSError('Could not confirm the account reset. Saved files are preserved.')

  @staticmethod
  def _read_valid(path: str) -> str:
    with xbmcvfs.File(path) as handle:
      content = handle.read()
    if not content.strip():
      raise ValueError('The saved-account file is empty.')
    data = json.loads(content)
    if isinstance(data, dict) and (
      type(data.get('version')) is not int or data['version'] != ACCOUNT_FORMAT_VERSION
    ):
      raise UnsupportedProfileError(
        'Unsupported saved-account format. Profile reset required. The original profile is preserved.'
      )
    AccountStore.from_json(content)
    return content

  def _preserve_current(self) -> str | None:
    if not xbmcvfs.exists(self.path):
      return None
    try:
      self._read_valid(self.path)
    except UnsupportedProfileError:
      raise
    except (OSError, ValueError):
      # Retain the damaged original without replacing a usable recovery copy.
      previous = self.path + '.invalid-' + uuid4().hex
    else:
      previous = self.path + '.bak'
      if xbmcvfs.exists(previous) and not xbmcvfs.delete(previous):
        raise OSError('Could not update the saved-account backup.')
    if not xbmcvfs.rename(self.path, previous):
      raise OSError('Could not preserve the previous account settings.')
    return previous

  def write(self, content: str) -> None:
    with self.lock:
      if xbmcvfs.exists(self.reset_marker):
        raise UnsupportedProfileError('The account reset must finish before saving.')
      if not content.strip():
        raise ValueError('Cannot save empty account settings.')
      AccountStore.from_json(content)
      if not xbmcvfs.mkdirs(self.profile) and not xbmcvfs.exists(self.profile):
        raise OSError('Could not create the account settings directory.')
      temporary = self.path + '.tmp'
      with xbmcvfs.File(temporary, 'w') as handle:
        if not handle.write(content):
          raise OSError('Could not save the account settings.')
      if self._read_valid(temporary) != content:
        raise OSError('Could not verify the saved account settings.')
      previous = self._preserve_current()
      if not xbmcvfs.rename(temporary, self.path):
        if previous:
          xbmcvfs.rename(previous, self.path)
        raise OSError('Could not finish saving the account settings.')


class PreferenceStorage:
  """Recoverable storage for the versioned, non-secret application preferences."""

  def __init__(self, profile: str) -> None:
    self.profile = profile.rstrip('/') + '/'
    self.path = self.profile + 'preferences.json'
    self.lock = threading.Lock()

  @staticmethod
  def _read_valid(path: str) -> str:
    with xbmcvfs.File(path) as handle:
      content = handle.read()
    if not content.strip():
      raise ValueError('The preference file is empty.')
    Preferences.from_json(content)
    return content

  def read(self) -> str:
    with self.lock:
      found = False
      for path in (self.path, self.path + '.bak'):
        if not xbmcvfs.exists(path):
          continue
        found = True
        try:
          return self._read_valid(path)
        except UnsupportedPreferenceVersionError:
          raise
        except (OSError, ValueError):
          continue
      if found:
        raise ValueError('Saved preferences could not be read. The original file is preserved.')
    return ''

  def _preserve_current(self) -> str | None:
    if not xbmcvfs.exists(self.path):
      return None
    try:
      self._read_valid(self.path)
    except UnsupportedPreferenceVersionError:
      raise
    except (OSError, ValueError):
      previous = self.path + '.invalid-' + uuid4().hex
    else:
      previous = self.path + '.bak'
      if xbmcvfs.exists(previous) and not xbmcvfs.delete(previous):
        raise OSError('Could not update the player-preference backup.')
    if not xbmcvfs.rename(self.path, previous):
      raise OSError('Could not preserve previous preferences.')
    return previous

  def write(self, content: str) -> None:
    with self.lock:
      Preferences.from_json(content)
      if not xbmcvfs.mkdirs(self.profile) and not xbmcvfs.exists(self.profile):
        raise OSError('Could not create the preference directory.')
      temporary = self.path + '.tmp'
      with xbmcvfs.File(temporary, 'w') as handle:
        if not handle.write(content):
          raise OSError('Could not save preferences.')
      if self._read_valid(temporary) != content:
        raise OSError('Could not verify saved preferences.')
      previous = self._preserve_current()
      if not xbmcvfs.rename(temporary, self.path):
        if previous:
          xbmcvfs.rename(previous, self.path)
        raise OSError('Could not finish saving preferences.')
