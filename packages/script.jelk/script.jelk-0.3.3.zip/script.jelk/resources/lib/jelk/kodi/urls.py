"""Kodi URL-option authentication for same-server Jellyfin resources."""

from urllib.parse import urlencode

from jelk.client import ApiError, JellyfinClient
from jelk.identity import USER_AGENT


def authenticated_url(client: JellyfinClient, address: str) -> str:
  """Attach Jellyfin authentication using Kodi's URL-option syntax."""
  if '|' in address:
    raise ApiError('The server returned an invalid media address.')
  return (
    address
    + '|'
    + urlencode({'Authorization': client.authorization_header, 'User-Agent': USER_AGENT})
  )
