from __future__ import annotations

import queue
import time
from concurrent.futures import Future, ThreadPoolExecutor
from copy import copy
from dataclasses import dataclass
from functools import partial
from typing import Any, Callable, cast

import xbmcaddon
import xbmcgui

from jelk.accounts import Account, AccountStore, Server, normalize_url
from jelk.client import ApiError, AuthError, JellyfinClient
from jelk.connection import PROBE_TIMEOUT_SECONDS, ConnectionResolver, VerifiedConnection
from jelk.delivery import DRAIN_SECONDS, RETIRE_TIMEOUT, Credential, Delivery, captured_client
from jelk.kodi.log import event
from jelk.kodi.playback import PlaybackController, PreparedPlayback, prepare
from jelk.kodi.settings_window import SettingsController, SettingsWindow
from jelk.kodi.storage import PreferenceStorage, ProfileStorage
from jelk.kodi.surfaces import (
  WINDOW_INVALID,
  NativeDialogs,
  Surface,
  SurfaceWindow,
  foreground,
  selected_position,
)
from jelk.kodi.urls import authenticated_url
from jelk.models import MediaItem, Page, text
from jelk.navigation import Navigation, Screen
from jelk.preferences import AccountScope, NetworkContext, Preferences
from jelk.server_settings import ServerSettingsCache
from jelk.session import ParticipantBinding, SessionRuntime, WatchingSession
from jelk.work import Failure, WorkCoordinator, WorkScope

LIST = 100
BACK = 201
USER = 202
SERVER = 203
ADDON_SETTINGS = 204
EXIT = 205
SETTINGS = 206
BACK_ACTIONS = {9, 10, 92}
PLAYBACK_MODAL_GRACE_SECONDS = 3.0


def network_context(is_in_network: object) -> NetworkContext:
  """Map Jellyfin's endpoint result; every absent/invalid value is conservative."""
  return NetworkContext.IN_NETWORK if is_in_network is True else NetworkContext.REMOTE


def prepare_with_fresh_network_context(
  client: JellyfinClient,
  item: MediaItem,
  preferences: Preferences,
  *,
  resume: bool,
) -> tuple[NetworkContext, PreparedPlayback]:
  try:
    context = network_context(client.endpoint_is_in_network())
  except AuthError:
    raise
  except (ApiError, OSError, ValueError):
    context = NetworkContext.REMOTE
    event('Jellyfin endpoint classification was unavailable; using Internet quality.')
  prepared = prepare(
    client,
    item,
    resume=resume,
    max_streaming_bitrate=preferences.player.bitrate_limits.for_context(context),
  )
  return context, prepared


@dataclass
class Row:
  label: str
  secondary: str
  action: Callable[[], None]
  item: MediaItem | None = None


@dataclass(repr=False)
class PlaybackPreparation:
  route: Screen
  session: SessionRuntime
  binding: ParticipantBinding
  result: tuple[NetworkContext, PreparedPlayback]


@dataclass(repr=False)
class CredentialBarrier:
  credential: Credential
  owner: WorkScope
  request: Callable[[JellyfinClient], Any]
  client: JellyfinClient
  done: Callable[[Any], None]
  failed: Callable[[Failure], None]
  retirement: bool = False
  started: bool = False

  def matches(self, credential: Credential) -> bool:
    return (
      credential == self.credential
      if self.retirement
      else (credential.boundary == self.credential.boundary)
    )


class ApplicationWindow(SurfaceWindow, xbmcgui.WindowXML):
  commands: queue.Queue[tuple[str, int, int | None]]

  def onInit(self) -> None:  # noqa: N802 - Kodi callback name.
    self.commands.put((self.initialise(), 0, None))

  def onClick(self, control_id: int) -> None:  # noqa: N802 - Kodi callback name.
    if not self.invalidated and foreground(self):
      self.commands.put(
        ('click', control_id, selected_position(self, control_id) if control_id == LIST else None)
      )

  def onFocus(self, control_id: int) -> None:  # noqa: N802 - Kodi callback name.
    if not self.invalidated and foreground(self):
      self.commands.put(('focus', control_id, selected_position(self, LIST)))

  def onAction(self, action: xbmcgui.Action) -> None:  # noqa: N802 - Kodi callback name.
    if action.getId() in BACK_ACTIONS:
      self.onClick(BACK)


class Application:
  def __init__(
    self,
    addon: xbmcaddon.Addon,
    window: ApplicationWindow,
  ) -> None:
    self.addon = addon
    self.window = window
    self.surface = Surface(window)
    self.dialogs = NativeDialogs()
    self.settings: SettingsController | None = None
    self.settings_surface: Surface[SettingsWindow] | None = None
    self.return_focus: int | None = None
    self.last_focus = LIST
    self.storage = ProfileStorage(addon.getAddonInfo('profile'))
    self.preference_storage = PreferenceStorage(addon.getAddonInfo('profile'))
    self.store = AccountStore()
    self.preferences = Preferences()
    self.server_settings_cache = ServerSettingsCache()
    self.navigation = Navigation()
    self.navigation.reset(Screen('boot', 'Welcome'))
    self.workers = ThreadPoolExecutor(max_workers=4)
    self.work = WorkCoordinator(self.workers)
    self.connections = ConnectionResolver(self.work)
    self.setup_connection: VerifiedConnection | None = None
    self.disk = ThreadPoolExecutor(max_workers=1)
    self.saves: list[Future[None]] = []
    self.save_bounds: dict[Future[None], Delivery] = {}
    self.barriers: list[CredentialBarrier] = []
    self.messages: list[tuple[str, str]] = []
    self.closing = False
    self.drain_deadline = 0.0
    self.rows: list[Row] = []
    self.setup_server: Server | None = None
    self.session: SessionRuntime | None = None
    self.setup_attempt: WorkScope | None = None
    self.closed = False
    self.reset_save: Future[None] | None = None
    self.render_pending = False
    self.ready = False
    self.last_selected = -1
    self.playback = PlaybackController(
      addon.getAddonInfo('path'),
      self._playback_finished,
      self._persist_preferences,
      show_error=self._player_message,
    )
    self.playback_session: SessionRuntime | None = None
    self.prepared: PlaybackPreparation | None = None
    self.playback_attempt: WorkScope | None = None

  @property
  def account(self) -> Account | None:
    return self.session.single().account if self.session is not None else None

  @property
  def client(self) -> JellyfinClient | None:
    return self.session.single().client if self.session is not None else None

  @property
  def server(self) -> Server | None:
    return self.session.value.server if self.session is not None else self.setup_server

  @property
  def connection(self) -> VerifiedConnection | None:
    return self.session.connection if self.session is not None else self.setup_connection

  @property
  def busy(self) -> bool:
    owner = self._visible_work()
    return (
      owner.busy
      or self.reset_save is not None
      or self.connections.busy(owner)
      or any(b.owner is owner for b in self.barriers)
    )

  @property
  def retry(self) -> Callable[[], None] | None:
    return self._visible_work().retry

  def _visible_work(self) -> WorkScope:
    screen = self.navigation.current
    if (
      self.setup_attempt is not None
      and self.setup_attempt.alive
      and self.setup_attempt.parent is screen.work
    ):
      return self.setup_attempt
    if (
      self.playback_attempt is not None
      and self.playback_attempt.alive
      and self.playback_attempt.parent is screen.work
    ):
      return self.playback_attempt
    return screen.work

  def foreground(self) -> None:
    if self.playback.active:
      return  # The modal player owns focus; showing main would hide playback.
    surface = self.settings_surface or self.surface
    surface.request_show()

  def poll(self) -> None:
    # Invalidation always outranks queued input, rendering and completed work.
    if self.surface.invalidated and self.settings is None and not self.playback.active:
      self._restore_window()
    if self.settings_surface is not None and self.settings_surface.invalidated:
      self._restore_settings_window()
    self.dialogs.poll()
    if self.settings is None and not self.playback.active:
      self._commands()
    if self.settings is not None:
      settings = self.settings
      settings.poll()
      if self.settings is settings and settings.closed:
        self._close_settings()
    self._results()
    self._poll_playback()
    self._poll_barriers()
    self._present_messages()
    if self.settings is None and not self.playback.active:
      self.surface.show_when_unobstructed()
      if self.render_pending:
        self._render()
      if self.ready:
        self._selection()
    elif self.settings_surface is not None:
      self.settings_surface.show_when_unobstructed()

  def close(self) -> None:
    if self.closing:
      return
    self.closing = True
    self.closed = True
    self.drain_deadline = time.monotonic() + DRAIN_SECONDS
    if self.settings is not None:
      self.settings.close()
    self.playback.close()
    self.surface.close()
    self._dispose_session()
    for screen in self.navigation.screens:
      screen.work.dispose()
    self.limit_shutdown(self.drain_deadline)
    # Retirements remain accepted; cancelled login intentions never start later.
    for barrier in self.barriers:
      if not barrier.retirement:
        barrier.owner.dispose()
    for future, read in list(self.work.tasks.items()):
      read.owner.dispose()
      future.cancel()
    self.work.tasks.clear()
    for write in self.work.writes.values():
      write.owner.dispose()
    self.disk.shutdown(wait=False)

  def limit_shutdown(self, deadline: float) -> None:
    self.drain_deadline = min(self.drain_deadline, deadline)
    self.work.limit(self.drain_deadline)
    self.playback.limit_reports(self.drain_deadline)
    for delivery in self.save_bounds.values():
      delivery.limit(self.drain_deadline)

  def poll_shutdown(self) -> bool:
    """Advance bounded delivery on the process loop, never by joining workers."""
    self.work.poll()
    player_pending = self.playback.poll_drain()
    self._poll_saves()
    self._poll_barriers()
    pending = bool(self.work.writes or self.saves or self.barriers or player_pending)
    if pending and time.monotonic() < self.drain_deadline:
      return True
    if pending:
      # Time may cross the shared bound between the first poll and this check.
      # Publish every unconfirmed outcome before discarding process ownership.
      self.work.limit(0)
      self.work.poll()
      self.playback.limit_reports(0)
      self.playback.poll_drain()
      for delivery in self.save_bounds.values():
        delivery.limit(0)
      self._poll_saves()
      self._poll_barriers()
    if self.saves:
      self._message('Local save unconfirmed', 'Local changes may not survive a restart.')
      for future in self.saves:
        future.cancel()
      self.saves.clear()
      self.save_bounds.clear()
    # Retirement queued behind a slow operation cannot start beyond shutdown.
    self.barriers.clear()
    self.work.close()
    for heading, message in self.messages:
      xbmcgui.Dialog().notification(heading, message)
    self.messages.clear()
    self.dialogs.close()
    return False

  def _message(self, heading: str, message: str) -> None:
    self.messages.append((heading, message))

  def _player_message(self, heading: str, message: str) -> None:
    if self.closing or heading == 'Watch progress':
      self._message(heading, message)
    else:
      # Preserve immediate player error/recovery dialogs. Only delivery outcomes
      # wait for playback to finish.
      self.dialogs.message(heading, message)

  def _present_messages(self) -> None:
    if (
      self.messages
      and not self.playback.active
      and not self.closing
      and self.dialogs.pending is None
      and xbmcgui.getCurrentWindowDialogId() == WINDOW_INVALID
    ):
      # Hand over only the message which can display now. A queued second
      # message must recheck playback/modal ownership on a later process tick.
      heading, message = self.messages.pop(0)
      self.dialogs.message(heading, message)

  def _commands(self) -> None:
    while not self.window.commands.empty():
      kind, value, position = self.window.commands.get_nowait()
      if kind == 'ready':
        self.last_selected = -1
        self._render()
        if not self.ready:
          self.ready = True
          self._submit(self._load_saved_state, self._loaded)
      elif kind == 'rebuilt':
        self._restore_window()
      elif kind == 'click':
        self._click(value, position)
      elif kind == 'focus':
        if (
          self.last_focus == LIST and value != LIST and position is not None and self.retry is None
        ):
          self.navigation.current.selected = position
        self.last_focus = value

  def _submit(
    self,
    work: Callable[[], Any],
    done: Callable[[Any], None],
    *,
    owner: WorkScope | None = None,
    retry: Callable[[], None] | None = None,
  ) -> None:
    scope = owner or self.navigation.current.work
    self.work.submit(
      scope,
      work,
      done,
      retry or partial(self._submit, work, done, owner=scope),
      partial(self._failed, scope),
      lambda: not self.closed,
    )
    self._render_owner(scope)

  def _read(
    self,
    owner: WorkScope,
    request: Callable[[JellyfinClient], Any],
    done: Callable[[Any], None],
  ) -> None:
    session = self.session
    if session is None or not session.work.alive or not owner.alive:
      return
    binding = session.single()
    client = binding.client
    retry = partial(self._read, owner, request, done)
    if self.connection is None:
      binding.recovery.interrupted[owner] = retry
      self._connect(owner, partial(self._reconnected, session, client), retry)
      return
    if binding.recovery.authentication_required:
      binding.recovery.interrupted[owner] = retry
      owner.failure = Failure('Please sign in again to continue.', True)
      owner.retry = partial(self._reauthenticate, session)
      self._render_owner(owner)
      return

    def failed(failure: Failure) -> None:
      if failure.connection:
        self._invalidate_connection(client)
      if failure.unavailable:
        owner.retry = partial(self._retry_connection_read, session, client, retry)
      if failure.authentication:
        binding.recovery.authentication_required = True
        binding.recovery.interrupted[owner] = retry
        owner.retry = partial(self._reauthenticate, session)
      self._failed(owner, failure)

    self.work.submit(
      owner,
      partial(request, client),
      done,
      retry,
      failed,
      lambda: not self.closed and self.session is session and session.current(binding),
    )
    self._render_owner(owner)

  def _retry_connection_read(
    self, session: SessionRuntime, client: JellyfinClient, retry: Callable[[], None]
  ) -> None:
    if self.playback.active or self.session is not session or not session.work.alive:
      return
    if session.single().client is client:
      self._invalidate_connection(client)
    retry()

  def _failed(self, owner: WorkScope, failure: Failure) -> None:
    if self.session is not None and owner is self.session.work and not failure.authentication:
      # Refresh is best-effort. Keep cached watch state; reporting is independent.
      owner.failure = None
      owner.retry = None
      return
    self._render_owner(owner)

  def _render_owner(self, owner: WorkScope) -> None:
    if owner.alive and (
      owner is self._visible_work() or (self.session is not None and owner is self.session.work)
    ):
      if self.session is not None and owner is self.session.work:
        if owner.busy:
          return
        self.return_focus = self.return_focus or self.last_focus
      self._render()

  def _results(self) -> None:
    visible = self._visible_work()
    was_busy = self.busy
    self.connections.poll()
    self.work.poll()
    if was_busy != self.busy:
      self._render_owner(visible)
    self._poll_saves()
    self._poll_barriers()

  def _poll_saves(self) -> None:
    if self.reset_save is not None and self.reset_save.done() and self.reset_save not in self.saves:
      self.reset_save = None
      if not self.closed:
        self._render()
    for save in list(self.saves):
      expired = self.save_bounds[save].expired
      if save.done() or expired:
        self.saves.remove(save)
        del self.save_bounds[save]
        if expired:
          save.cancel()
        failed = expired or save.exception() is not None
        if save is self.reset_save:
          self._profile_reset_finished(save, failed)
        elif failed:
          self._message('Local save unconfirmed', 'Your changes may not survive a restart.')

  def _persist(self) -> None:
    self._save(partial(self.storage.write, self.store.to_json()))

  def _persist_preferences(self) -> None:
    self._save(partial(self.preference_storage.write, self.preferences.to_json()))

  def _save(self, write: Callable[[], None]) -> Future[None]:
    delivery = Delivery(time.monotonic() + DRAIN_SECONDS)

    def deliver() -> None:
      delivery.check()
      write()
      delivery.check()

    future = self.disk.submit(deliver)
    self.saves.append(future)
    self.save_bounds[future] = delivery
    return future

  def _request_profile_reset(self) -> None:
    owner = self.navigation.current.work
    self.dialogs.request(
      partial(
        xbmcgui.Dialog().yesno,
        'Reset saved servers and sign-ins?',
        'Remove all saved servers and sign-ins from jelk? Original account files will be '
        'preserved. Preferences stay unchanged. You will need to add servers and sign in again.',
      ),
      partial(self._profile_reset_confirmed, owner),
    )

  def _profile_reset_confirmed(self, owner: WorkScope, confirmed: bool) -> None:  # noqa: FBT001 - dialog result.
    if (
      not confirmed
      or self.closed
      or self.busy
      or not owner.alive
      or self.navigation.current.kind != 'boot'
      or self.navigation.current.work is not owner
      or owner.failure is None
      or not owner.failure.reset_required
    ):
      return
    owner.failure, owner.retry = None, None
    self.reset_save = self._save(self.storage.reset_unsupported)
    self._render()

  def _profile_reset_finished(self, save: Future[None], failed: bool) -> None:  # noqa: FBT001 - disk outcome.
    if save.done():
      self.reset_save = None
    if self.closed:
      if failed:
        self._message(
          'Profile reset unconfirmed',
          'Original files are preserved. Reopen jelk to retry loading or reset again.',
        )
      return
    owner = self.navigation.current.work
    if failed:
      owner.failure = Failure(
        'Reset unconfirmed. Original files are preserved. Retry loading or reset again.',
        reset_required=True,
      )
      owner.retry = partial(self._submit, self._load_saved_state, self._loaded)
      self._render()
    else:
      self._submit(self._load_saved_state, self._loaded)

  def _load_saved_state(self) -> tuple[AccountStore, Preferences]:
    store = AccountStore.from_json(self.storage.read())
    serialized_preferences = self.preference_storage.read()
    preferences = Preferences.from_json(serialized_preferences)
    if not serialized_preferences.strip():
      self.preference_storage.write(preferences.to_json())
    return store, preferences

  def _loaded(self, state: tuple[AccountStore, Preferences]) -> None:
    store, self.preferences = state
    self.store = store
    server = next((s for s in store.servers if s.id == store.last_server_id), None)
    if server:
      self._select_server(server)
    else:
      self._servers()

  def _reset(self, screen: Screen) -> None:
    self._cancel_playback_start()
    self.navigation.reset(screen)
    self.last_selected = -1
    self._render()

  def _servers(self) -> None:
    self._dispose_session()
    self.setup_server = None
    self.setup_connection = None
    self._reset(Screen('servers', 'Choose a server'))

  def _select_server(self, server: Server) -> None:
    self._dispose_session()
    self.setup_server = server
    self.setup_connection = None
    self.store.last_server_id = server.id
    self._persist()
    self._users()
    self._retry_connection(self.navigation.current.work)

  def _retry_connection(self, owner: WorkScope) -> None:
    self._connect(owner, lambda _connection: None, partial(self._retry_connection, owner))

  def _users(self) -> None:
    self.setup_server = self.server
    self.setup_connection = self.connection
    self._dispose_session()
    self._reset(Screen('users', "Who's watching?"))

  def _dispose_session(self) -> None:
    self._cancel_playback_start()
    if self.session is not None:
      self.session.dispose()
    self.session = None
    self.prepared = None
    if self.setup_attempt is not None:
      self.setup_attempt.dispose()
    self.setup_attempt = None

  def _add_server(self) -> None:
    self.dialogs.request(
      partial(xbmcgui.Dialog().input, 'Jellyfin server address', defaultt='https://'),
      self._server_address_entered,
    )

  def _server_address_entered(self, address: str) -> None:
    if not address:
      return
    try:
      address = normalize_url(address)
    except ValueError as error:
      self._status(str(error))
      return
    owner = self.navigation.current.work

    def connected(connection: VerifiedConnection) -> None:
      for saved in self.store.servers:
        if saved.id != connection.server_id and address in saved.addresses:
          self.connections.forget(saved.id, address)
      existing = next((s for s in self.store.servers if s.id == connection.server_id), None)
      if existing is not None:
        self._select_server(existing)
        self._message('Server already saved', 'Using the saved addresses for this server.')
        return
      server = Server(connection.server_id, (address,), connection.name)
      self.store.add_server(server)
      self._select_server(server)

    self.connections.resolve(
      '',
      (address,),
      owner,
      self._probe_address,
      connected,
      partial(self._connection_failed, owner, partial(self._server_address_entered, address)),
    )
    self._render_owner(owner)

  def _probe_address(self, address: str) -> dict[str, Any]:
    return JellyfinClient(
      address, self.store.device_id, timeout=PROBE_TIMEOUT_SECONDS
    ).public_info()

  def _connection_failed(
    self, owner: WorkScope, retry: Callable[[], None], failure: Failure
  ) -> None:
    owner.failure, owner.retry = failure, retry
    self._render_owner(owner)

  def _connect(
    self, owner: WorkScope, done: Callable[[VerifiedConnection], None], retry: Callable[[], None]
  ) -> None:
    server = self.server
    if server is None or not owner.alive:
      return
    if not server.id.strip():
      owner.failure = Failure('Profile reset required. The saved server identity is missing.')
      owner.retry = None
      self._render_owner(owner)
      return
    if self.connection is not None:
      owner.failure, owner.retry = None, None
      done(self.connection)
      return

    def connected(connection: VerifiedConnection) -> None:
      if self.server is not server:
        return
      if self.session is None:
        self.setup_connection = connection
      owner.failure, owner.retry = None, None
      done(connection)
      self._render_owner(owner)

    self.connections.resolve(
      server.id,
      server.addresses,
      owner,
      self._probe_address,
      connected,
      partial(self._connection_failed, owner, retry),
    )
    self._render_owner(owner)

  def _invalidate_connection(self, client: JellyfinClient) -> None:
    self.connections.forget(client.server_id, client.base_url)
    self.setup_connection = None
    session = self.session
    if session is not None and (
      session.single().client is client
      or (
        not client.token
        and session.connection is not None
        and session.connection.server_id == client.server_id
        and session.connection.address == client.base_url
      )
    ):
      session.invalidate_connection()
      for read in self.work.discard_stale():
        if read.owner.alive:
          session.single().recovery.interrupted.setdefault(read.owner, read.retry)

  def _reconnected(
    self, session: SessionRuntime, client: JellyfinClient, connection: VerifiedConnection
  ) -> None:
    if self.session is session and session.work.alive and session.single().client is client:
      self._use_verified_account(session.single().account, connection, validate=False)

  def _reauthenticate(self, session: SessionRuntime) -> None:
    if not session.work.alive or self.session is not session:
      return
    attempt = session.single().recovery.attempt
    if attempt is not None and attempt.alive and attempt.failure is None:
      return
    self._login(session.single().account.user_name)

  def _settings_authentication_failed(
    self, session: SessionRuntime, client: JellyfinClient
  ) -> bool:
    if (
      self.session is not session or not session.work.alive or session.single().client is not client
    ):
      return False
    session.single().recovery.authentication_required = True
    self._render_owner(session.work)
    return True

  def _settings_sign_in(self, session: SessionRuntime, client: JellyfinClient) -> None:
    if self._settings_authentication_failed(session, client):
      self._close_settings()
      self._reauthenticate(session)

  def _queue_barrier(self, barrier: CredentialBarrier) -> None:
    self._cancel_playback_start()
    self.barriers.append(barrier)
    self.work.blocked.add(barrier.credential.boundary)
    deadline = time.monotonic() + DRAIN_SECONDS
    self.work.limit(deadline, barrier.matches)
    if self.playback.draining(barrier.matches):
      self.playback.limit_reports(deadline)
    self._poll_barriers()

  def _settings_connection_failed(self, session: SessionRuntime, client: JellyfinClient) -> bool:
    if (
      self.session is not session or not session.work.alive or session.single().client is not client
    ):
      return False
    self._invalidate_connection(client)
    return True

  def _settings_reconnect(self, session: SessionRuntime, client: JellyfinClient) -> None:
    if self._settings_connection_failed(session, client):
      self._close_settings()
      self._read(
        self.navigation.current.work, lambda current: current.current_user(), lambda _user: None
      )

  def _barrier_finished(self, barrier: CredentialBarrier, _failure: Failure | None) -> None:
    if barrier.retirement and _failure is not None:
      barrier.failed(_failure)
    if barrier in self.barriers:
      self.barriers.remove(barrier)
    if not any(b.credential.boundary == barrier.credential.boundary for b in self.barriers):
      self.work.blocked.discard(barrier.credential.boundary)

  def _poll_barriers(self) -> None:
    while self.barriers:
      barrier = self.barriers[0]
      if barrier.started:
        return
      if not barrier.owner.alive and not barrier.retirement:
        self._barrier_finished(barrier, None)
        continue
      if self.closing and time.monotonic() >= self.drain_deadline:
        barrier.failed(Failure('Server sign-out could not be confirmed.'))
        self._barrier_finished(barrier, None)
        continue
      if self.work.draining(barrier.matches) or self.playback.draining(barrier.matches):
        return
      barrier.started = True
      deadline = time.monotonic() + DRAIN_SECONDS
      if self.closing:
        deadline = min(deadline, self.drain_deadline)
      delivery = Delivery(deadline)
      client = captured_client(barrier.client, delivery)
      if barrier.retirement:
        client.timeout = RETIRE_TIMEOUT
      self.work.submit_write(
        id(barrier),
        barrier.owner,
        partial(barrier.request, client),
        barrier.done,
        (lambda _failure: None) if barrier.retirement else barrier.failed,
        delivery=delivery,
        credential=barrier.credential,
        barrier=True,
        outcome=partial(self._barrier_finished, barrier),
      )
      return

  def _login(self, name: str = '') -> None:
    if self.server is None:
      return
    previous_failure = self._visible_work().failure
    if self.setup_attempt is not None:
      self.setup_attempt.dispose()
    attempt = WorkScope(parent=self.navigation.current.work)
    attempt.failure = previous_failure
    self.setup_attempt = attempt
    if self.session is not None:
      self.session.single().recovery.attempt = attempt
    self._connect(
      attempt, partial(self._login_connected, attempt, name), partial(self._login, name)
    )

  def _login_connected(self, attempt: WorkScope, name: str, connection: VerifiedConnection) -> None:
    self.setup_connection = connection
    self.dialogs.request(
      partial(xbmcgui.Dialog().input, 'Username', defaultt=name),
      partial(self._username_entered, attempt),
    )

  def _username_entered(self, attempt: WorkScope, name: str) -> None:
    if not attempt.alive:
      return
    if not name:
      attempt.dispose()
      self._render()
      return
    self.dialogs.request(
      partial(
        xbmcgui.Dialog().input,
        'Password',
        type=xbmcgui.INPUT_ALPHANUM,
        option=xbmcgui.ALPHANUM_HIDE_INPUT,
      ),
      partial(self._password_entered, attempt, name),
    )

  def _password_entered(self, attempt: WorkScope, name: str, password: str) -> None:
    if not attempt.alive or self.server is None:
      return
    if not password:
      attempt.dispose()
      self._render()
      return
    if self.setup_connection is None:
      self._connection_failed(
        attempt,
        partial(self._login, name),
        Failure(
          'The connection changed during sign-in. Retry connection, then enter your password again.',
          connection=True,
        ),
      )
      return
    connection = self.setup_connection
    client = JellyfinClient(
      connection.address, self.store.device_id, server_id=connection.server_id
    )

    def authenticated(account: Account) -> None:
      if account.server_id != connection.server_id:
        self._invalidate_connection(client)
        failed(
          Failure(
            'The sign-in returned a different server identity. Reconnect to retry.', connection=True
          )
        )
        return
      attempt.dispose()
      self.store.save_account(account)
      self._persist()
      self._use_verified_account(account, connection, validate=False)

    # Password exists only for this bounded authentication call; retries ask for it again.
    def failed(failure: Failure) -> None:
      if failure.connection:
        self._invalidate_connection(client)
      attempt.failure = failure
      attempt.retry = partial(self._login, name)
      self._render_owner(attempt)

    self._queue_barrier(
      CredentialBarrier(
        Credential.of(client),
        attempt,
        lambda captured: captured.authenticate(name, password),
        client,
        authenticated,
        failed,
      )
    )
    self._render_owner(attempt)

  def _use_account(self, account: Account, *, validate: bool = True) -> None:
    previous_failure = self._visible_work().failure
    if self.setup_attempt is not None:
      self.setup_attempt.dispose()
    attempt = WorkScope(parent=self.navigation.current.work)
    attempt.failure = previous_failure
    self.setup_attempt = attempt
    if not account.server_id.strip():
      attempt.failure = Failure('Profile reset required. The saved account identity is missing.')
      self._render_owner(attempt)
      return

    def connected(connection: VerifiedConnection) -> None:
      if account.server_id != connection.server_id:
        attempt.failure = Failure('This saved sign-in belongs to a different server.')
        self._render_owner(attempt)
        return
      attempt.dispose()
      self._use_verified_account(account, connection, validate=validate)

    self._connect(attempt, connected, partial(self._use_account, account, validate=validate))

  def _use_verified_account(
    self, account: Account, connection: VerifiedConnection, *, validate: bool = True
  ) -> None:
    server = self.server
    if server is None:
      return
    value = WatchingSession(server, (account,))
    session = self.session
    if session is not None and session.value.identity == value.identity:
      recovery = session.single().recovery
      session.replace(value, connection)
      current_recovery = session.single().recovery
      current_recovery.authentication_required = False
      for read in self.work.discard_stale():
        if read.owner.alive:
          recovery.interrupted.setdefault(read.owner, read.retry)
      retries = list(recovery.interrupted.items())
      recovery.interrupted.clear()
      self.setup_server = None
      self.setup_connection = None
      for owner, retry in retries:
        if owner.alive:
          retry()
      self._render()
      return
    replacement = SessionRuntime(value, connection, JellyfinClient)
    self._dispose_session()
    if session is not None:
      self._reset(Screen('users', "Who's watching?"))
    self.session = replacement
    self.setup_server = None
    self.setup_connection = None
    self.navigation.current.work.parent = self.session.work
    self.playback.configure_preferences(
      self.preferences.player,
      self._account_scope(account),
      NetworkContext.REMOTE,
    )
    if validate:
      self._read(
        self.navigation.current.work,
        lambda client: client.current_user(),
        lambda _user: self._libraries(),
      )
    else:
      self._libraries()

  def _account_scope(self, account: Account) -> AccountScope:
    return AccountScope(account.server_id, account.user_id)

  def _libraries(self) -> None:
    screen = Screen('libraries', 'Your libraries')
    if self.session is not None:
      screen.work.parent = self.session.work
    self._reset(screen)
    self._read(
      screen.work, lambda client: client.libraries(), partial(self._library_results, screen)
    )

  def _library_results(self, screen: Screen, items: tuple[MediaItem, ...]) -> None:
    screen.items = [
      item for item in items if text(item.raw.get('CollectionType')) in {'movies', 'tvshows', ''}
    ]
    screen.loaded = True
    self._render_owner(screen.work)

  def _open_library(self, item: MediaItem) -> None:
    self._cancel_playback_start()
    self._remember()
    kind = 'Series' if item.raw.get('CollectionType') == 'tvshows' else 'Movie'
    self.navigation.push(Screen('items', item.name, parent_id=item.id, item_type=kind))
    self._render()
    self._load_page()

  def _load_page(self, screen: Screen | None = None) -> None:
    if self.client is None:
      return
    screen = screen or self.navigation.current
    if screen.work.busy:
      return
    start = len(screen.items)

    def request(client: JellyfinClient) -> Page:
      if screen.kind == 'episodes':
        return client.episodes(screen.series_id, screen.parent_id, start)
      if screen.kind == 'seasons':
        return client.seasons(screen.parent_id)
      return client.items(screen.parent_id, screen.item_type, start)

    self._read(screen.work, request, partial(self._page_results, screen))

  def _page_results(self, screen: Screen, page: Page) -> None:
    screen.items.extend(page.items)
    screen.total = page.total if page.items else len(screen.items)
    screen.loaded = True
    self._render_owner(screen.work)

  def _open_item(self, item: MediaItem) -> None:
    self._cancel_playback_start()
    self._remember()
    if item.type == 'Season':
      screen = Screen('episodes', item.name, parent_id=item.id, series_id=item.series_id)
      self.navigation.push(screen)
      self._render()
      self._load_page()
      return
    screen = Screen('details', item.name, detail=item)
    self.navigation.push(screen)
    self._render()
    if self.client:
      self._read(
        screen.work, lambda client: client.item(item.id), partial(self._details_result, screen)
      )

  def _details_result(self, screen: Screen, item: MediaItem) -> None:
    screen.detail = item
    self._render_owner(screen.work)

  def _seasons(self, item: MediaItem) -> None:
    self._cancel_playback_start()
    self._remember()
    self.navigation.push(Screen('seasons', item.name, parent_id=item.id))
    self._render()
    self._load_page()

  def _play(self, item: MediaItem, *, resume: bool) -> None:
    if not self.client or self.session is None:
      return
    if not self.work.accepts(Credential.of(self.client)):
      self._status('Waiting for sign-in changes to finish…')
      return
    if self.playback.busy:
      self._status('Watch progress is still syncing. Please wait before playing another title.')
      return
    self._remember()
    self._cancel_playback_start()
    screen, session = self.navigation.current, self.session
    self.playback_attempt = WorkScope(parent=screen.work)
    self._read(
      self.playback_attempt,
      lambda client: prepare_with_fresh_network_context(
        client, item, self.preferences, resume=resume
      ),
      partial(self._prepared_playback, screen, session),
    )

  def _cancel_playback_start(self) -> None:
    if self.playback_attempt is not None:
      self.playback_attempt.dispose()
      if self.session is not None:
        self.session.single().recovery.interrupted.pop(self.playback_attempt, None)
    self.playback_attempt = None
    self.prepared = None

  def _prepared_playback(
    self,
    screen: Screen,
    session: SessionRuntime,
    result: tuple[NetworkContext, PreparedPlayback],
  ) -> None:
    if self.playback_attempt is None or not self.playback_attempt.alive:
      return
    self.prepared = PlaybackPreparation(screen, session, session.single(), result)
    self.work.deadlines.schedule(
      self.playback_attempt,
      'modal-grace',
      time.monotonic() + PLAYBACK_MODAL_GRACE_SECONDS,
      self._expire_prepared_playback,
    )
    self._present_prepared_playback()

  def _expire_prepared_playback(self) -> None:
    self._cancel_playback_start()
    self._render()

  def _present_prepared_playback(self) -> None:
    self.work.deadlines.poll()
    prepared = self.prepared
    if prepared is None:
      return
    if (
      not prepared.route.work.alive
      or not prepared.session.work.alive
      or self.session is not prepared.session
      or not prepared.session.current(prepared.binding)
      or prepared.route is not self.navigation.current
      or self.settings is not None
      or self.closed
    ):
      self._cancel_playback_start()
      self._render()
    elif self._controls_live():
      self._cancel_playback_start()
      self._start_playback(prepared.result)
    elif xbmcgui.getCurrentWindowDialogId() == WINDOW_INVALID:
      self._cancel_playback_start()
      self._render()

  def _start_playback(self, result: tuple[NetworkContext, PreparedPlayback]) -> None:
    context, prepared = result
    if self.account is None:
      return
    self.playback.configure_preferences(
      self.preferences.player,
      self._account_scope(self.account),
      context,
    )
    self.playback_session = self.session
    self.playback.start(prepared)

  def _poll_playback(self) -> None:
    self._present_prepared_playback()
    was_active = self.playback.active
    self.playback.poll()
    if was_active and not self.playback.active and not self.closed:
      self._restore_window()
      if self.playback.busy:
        self._status('Saving watch progress… You can browse or exit.')

  def _playback_finished(self, item_id: str) -> None:
    session = self.playback_session
    self.playback_session = None
    if self.closed or session is None or not session.work.alive:
      return
    if self.client:
      self._read(
        session.work, lambda client: client.item(item_id), partial(self._refresh_item, session)
      )

  def _refresh_item(self, session: SessionRuntime, item: MediaItem) -> None:
    if self.session is not session:
      return
    visible_changed = False
    for screen in self.navigation.screens:
      matches = any(previous.id == item.id for previous in screen.items) or (
        screen.detail is not None and screen.detail.id == item.id
      )
      visible_changed = visible_changed or (screen is self.navigation.current and matches)
      screen.items = [item if previous.id == item.id else previous for previous in screen.items]
      if screen.detail and screen.detail.id == item.id:
        screen.detail = item
    if visible_changed:
      self.return_focus = self.return_focus or self.last_focus
      self._render()

  def _sign_out(self) -> None:
    if self.account is None or self.client is None:
      return
    account = self.account
    client = self.client
    self.dialogs.request(
      partial(xbmcgui.Dialog().yesno, 'Sign out', 'Remove this saved sign-in from this device?'),
      partial(self._sign_out_confirmed, account, client),
    )

  def _sign_out_confirmed(self, account: Account, client: JellyfinClient, confirmed: bool) -> None:  # noqa: FBT001 - native dialog result.
    if not confirmed:
      return

    self.store.remove_account(account.server_id, account.user_id)
    self._persist()
    self._users()
    self._queue_barrier(
      CredentialBarrier(
        Credential.of(client),
        WorkScope(),
        lambda captured: captured.logout(),
        copy(client),
        lambda _result: None,
        lambda _failure: self._message(
          'Server sign-out unconfirmed',
          account.user_name
          + ': saved sign-in removed locally; server logout could not be confirmed.',
        ),
        retirement=True,
      )
    )

  def _click(self, control_id: int, position: int | None = None) -> None:  # noqa: C901 - explicit control routing.
    # Abandoning profile loading would let a new sign-in overwrite saved accounts
    # with this instance's empty store. Keep Retry and Exit available during boot.
    if (
      self.settings is not None
      or self.playback.active
      or (self.navigation.current.kind == 'boot' and control_id in {SERVER, USER})
    ):
      return
    if control_id == EXIT:
      self.closed = True
    elif control_id == BACK:
      self._back()
    elif control_id == USER and self.server:
      self._users()
    elif control_id == SERVER:
      self._servers()
    elif control_id == ADDON_SETTINGS:
      self.dialogs.request(self.addon.openSettings, self._addon_settings_closed)
    elif control_id == SETTINGS and self._authenticated_library_context():
      self._open_settings()
    elif control_id == LIST and self._controls_live():
      index = position
      if index is not None and 0 <= index < len(self.rows):
        row = self.rows[index]
        # Loaded list entries remain usable while an additional page is pending.
        if (
          self.busy
          and not self._setup_connection_pending()
          and not (
            row.item is not None
            and self.navigation.current.kind in {'libraries', 'items', 'seasons', 'episodes'}
            and self._visible_work() is self.navigation.current.work
          )
        ):
          return
        if self.retry is None:
          self.navigation.current.selected = index
        row.action()

  def _setup_connection_pending(self) -> bool:
    owner = self._visible_work()
    return (
      self.navigation.current.kind == 'users'
      and self.connections.busy(owner)
      and not owner.busy
      and not any(b.owner is owner for b in self.barriers)
    )

  def _authenticated_library_context(self) -> bool:
    return (
      self.account is not None
      and self.client is not None
      and self.server is not None
      and self.navigation.current.kind in {'libraries', 'items', 'seasons', 'episodes', 'details'}
    )

  def _open_settings(self) -> None:
    if self.account is None or self.client is None or self.server is None or self.session is None:
      return
    session = self.session
    binding = session.single()
    client = binding.client
    self._cancel_playback_start()
    self._remember()
    window = SettingsWindow(
      'script-jelk-settings.xml', self.addon.getAddonInfo('path'), 'Default', '1080i'
    )
    window.commands = queue.Queue()
    self.settings_surface = Surface(window)
    self.settings = SettingsController(
      self.addon,
      window,
      binding.client,
      self._account_scope(binding.account),
      session.value.server.name,
      binding.account.user_name,
      self.preferences,
      self._persist_preferences,
      self.server_settings_cache,
      self.dialogs,
      self.work,
      session.work,
      current=lambda: self.session is session and session.current(binding),
      authentication_failed=partial(self._settings_authentication_failed, session, client),
      sign_in=partial(self._settings_sign_in, session, client),
      connection_failed=partial(self._settings_connection_failed, session, client),
      reconnect=partial(self._settings_reconnect, session, client),
      report_failure=self._message,
    )
    self.settings_surface.request_show()

  def _restore_settings_window(self) -> None:
    if self.settings is None:
      return
    window = self.settings.window
    window.commands = queue.Queue()
    window.invalidated = False
    window.commands.put(('ready', 0, None))
    self.settings.ready = False
    event('Restored the jelk Settings surface.')

  def _close_settings(self) -> None:
    if self.settings is not None:
      self.settings.close()
    self.settings = None
    self.settings_surface = None
    self.return_focus = SETTINGS
    # Native controls may be reloaded on return; repaint from retained state.
    self._restore_window()

  def _back(self) -> None:
    self._cancel_playback_start()
    previous = self.navigation.current
    if self.navigation.back():
      if self.session is not None:
        self.session.single().recovery.interrupted.pop(previous.work, None)
      if self.setup_attempt is not None and not self.setup_attempt.alive:
        self.setup_attempt.dispose()
        self.setup_attempt = None
      self._render()
      if (
        not self.navigation.current.loaded
        and not self.busy
        and self.retry is None
        and self.navigation.current.kind
        in {
          'items',
          'seasons',
          'episodes',
        }
      ):
        self._load_page()
    elif self.navigation.current.kind == 'users':
      self._servers()
    elif self.navigation.current.kind == 'libraries':
      self._users()
    else:
      self.dialogs.request(
        partial(xbmcgui.Dialog().yesno, 'Exit jelk', 'Return to Kodi?'), self._exit_confirmed
      )

  def _exit_confirmed(self, confirmed: bool) -> None:  # noqa: FBT001 - native dialog result.
    self.closed = confirmed

  def _addon_settings_closed(self, _result: object) -> None:
    self.return_focus = ADDON_SETTINGS
    self._render()

  def _remember(self) -> None:
    if not self._controls_live() or self.last_focus != LIST:
      return
    position = self._selected_position()
    if position is not None:
      self.navigation.current.selected = position

  def _list(self) -> xbmcgui.ControlList:
    return cast('xbmcgui.ControlList', self.window.getControl(LIST))

  def _status(self, value: str) -> None:
    if not self._controls_live():
      return
    cast('xbmcgui.ControlLabel', self.window.getControl(11)).setLabel(value)

  def _image(self, item: MediaItem) -> str:
    if not self.client:
      return ''
    address = self.client.image_url(item)
    if not address:
      return ''
    try:
      return authenticated_url(self.client, address)
    except ApiError:
      return ''

  def _render(self) -> None:
    if not self._controls_live():
      self.render_pending = True
      return
    self.render_pending = False
    screen = self.navigation.current
    cast('xbmcgui.ControlLabel', self.window.getControl(10)).setLabel(screen.title)
    self.rows = self._screen_rows(screen)
    scope = self._visible_work()
    authentication_retry = scope.failure is not None and scope.failure.authentication
    retry_label = (
      'Retry connection' if scope.failure is not None and scope.failure.connection else 'Retry'
    )
    if scope.retry is not None:
      self.rows = [row for row in self.rows if row.label != 'Load more']
      self.rows.append(
        Row(
          'Sign in again' if authentication_retry else retry_label,
          'Your saved server and account are preserved',
          scope.retry,
        )
      )
    if (
      self.session is not None
      and self.session.single().recovery.authentication_required
      and not authentication_retry
    ):
      self.rows.append(
        Row(
          'Sign in again', 'Your sign-in has expired', partial(self._reauthenticate, self.session)
        )
      )
    self._render_rows()
    self._render_status(scope, screen)
    self._render_footer()
    self.last_focus = self.return_focus or (LIST if self.rows else EXIT)
    self.window.setFocusId(self.last_focus)
    self.return_focus = None
    self.last_selected = -1
    self._selection(restoring=True)

  def _render_status(self, scope: WorkScope, screen: Screen) -> None:
    if scope.failure is not None and scope.failure.reset_required:
      self._status(scope.failure.message)
    elif any(b.owner is scope for b in self.barriers):
      self._status('Finishing pending changes before sign-in…')
    elif self.connections.busy(scope):
      self._status(scope.failure.message if scope.failure is not None else 'Connecting…')
    elif scope.busy:
      self._status('Loading…')
    elif scope.failure is not None:
      self._status(scope.failure.message)
    elif self.session is not None:
      status = ', '.join(account.user_name for account in self.session.value.participants)
      status += ' · ' + self.session.value.server.name
      if screen.kind == 'items':
        status += ' · ' + (
          'Latest episode added' if screen.item_type == 'Series' else 'Newest added'
        )
      self._status(status)
    elif self.server and screen.kind == 'users':
      self._status(self.server.name + ' · Select a saved user or sign in')
    else:
      self._status('Choose a saved server or add your Jellyfin server')

  def _render_footer(self) -> None:
    if not self._controls_live():
      return
    self.window.setProperty(
      'jelk.settings.available', 'true' if self._authenticated_library_context() else 'false'
    )

  def _screen_rows(self, screen: Screen) -> list[Row]:
    if (
      screen.kind == 'boot'
      and screen.work.failure is not None
      and screen.work.failure.reset_required
    ):
      return [
        Row(
          'Reset saved servers and sign-ins',
          'Preserve original files and start again',
          self._request_profile_reset,
        )
      ]
    if screen.kind == 'servers':
      rows = [
        Row(s.name, 'Saved server', partial(self._select_server, s)) for s in self.store.servers
      ]
      return [*rows, Row('Add server', 'Enter a Jellyfin server address', self._add_server)]
    if screen.kind == 'users' and self.server:
      rows = [
        Row(a.user_name, 'Saved sign-in', partial(self._use_account, a))
        for a in self.store.accounts_for(self.server.id)
      ]
      return [*rows, Row('Sign in as another user', '', self._login)]
    if screen.kind == 'details' and screen.detail:
      return self._detail_rows(screen.detail)
    rows = [
      Row(
        self._item_title(item),
        self._item_summary(item),
        partial(self._open_library if screen.kind == 'libraries' else self._open_item, item),
        item,
      )
      for item in screen.items
    ]
    if screen.has_more:
      rows.append(
        Row('Load more', str(len(screen.items)) + ' of ' + str(screen.total), self._load_page)
      )
    elif screen.loaded and not screen.items:
      rows.append(Row('Nothing here yet', 'Refresh to check again', self._reload))
    if screen.kind == 'libraries':
      rows.append(Row('Sign out', 'Remove the current saved sign-in', self._sign_out))
    return rows

  def _detail_rows(self, item: MediaItem) -> list[Row]:
    if item.type == 'Series':
      return [
        Row('Seasons and episodes', self._item_summary(item), partial(self._seasons, item), item)
      ]
    rows = []
    if item.position_ticks:
      minutes = item.position_ticks // 600_000_000
      rows.append(
        Row(
          'Resume',
          'Continue from ' + str(minutes) + ' min',
          partial(self._play, item, resume=True),
          item,
        )
      )
    rows.append(
      Row(
        'Play from beginning',
        self._item_summary(item),
        partial(self._play, item, resume=False),
        item,
      )
    )
    return rows

  def _reload(self) -> None:
    if self.navigation.current.kind == 'libraries':
      self._libraries()
    else:
      self._load_page()

  def _render_rows(self) -> None:
    if not self._controls_live():
      return
    control = self._list()
    control.reset()
    for row in self.rows:
      entry = xbmcgui.ListItem(label=row.label, label2=row.secondary)
      if row.item:
        entry.setArt({'icon': self._image(row.item), 'thumb': self._image(row.item)})
      control.addItem(entry)
    if self.rows:
      control.selectItem(min(self.navigation.current.selected, len(self.rows) - 1))

  def _selection(self, *, restoring: bool = False) -> None:
    # A rebuilt list can briefly report its reset position while Kodi applies the
    # selection message. Rendering and footer focus are not new list input.
    retained = restoring or self.last_focus != LIST
    position = self.navigation.current.selected if retained else self._selected_position()
    if position is None or position == self.last_selected:
      return
    self.last_selected = position
    if not retained and self.retry is None and not self.busy:
      self.navigation.current.selected = max(0, position)
    item = self.rows[position].item if 0 <= position < len(self.rows) else None
    item = self.navigation.current.detail or item
    self.window.setProperty('jelk.detail.art', self._image(item) if item else '')
    cast('xbmcgui.ControlLabel', self.window.getControl(13)).setLabel(item.name if item else '')
    cast('xbmcgui.ControlTextBox', self.window.getControl(14)).setText(
      item.overview if item else ''
    )

  def _restore_window(self) -> None:
    """Discard old input and repaint the live native controls on the same window."""
    self.window.commands = queue.Queue()
    self.window.invalidated = False
    self.return_focus = self.return_focus or self.last_focus
    self.render_pending = True
    self.surface.request_show()
    event('Restored the jelk main surface.')

  def _controls_live(self) -> bool:
    """Gate presentation on ownership; memory safety comes from ID-based APIs."""
    return (
      self.settings is None
      and not self.playback.active
      and self.window.initialised
      and not self.surface.invalidated
      and foreground(self.window)
    )

  def _selected_position(self) -> int | None:
    if not self._controls_live():
      return None
    return selected_position(self.window, LIST)

  @staticmethod
  def _item_title(item: MediaItem) -> str:
    if item.type == 'Episode':
      return str(item.index_number) + '. ' + item.name
    if item.type == 'Season' and item.index_number == 0:
      return 'Specials'
    return item.name

  @staticmethod
  def _item_summary(item: MediaItem) -> str:
    values = []
    if item.year:
      values.append(str(item.year))
    if item.runtime_ticks:
      values.append(str(item.runtime_ticks // 600_000_000) + ' min')
    if item.position_ticks:
      values.append('In progress')
    elif item.played:
      values.append('Watched')
    if item.type == 'CollectionFolder':
      values.append(text(item.raw.get('CollectionType'), 'Library').capitalize())
    return ' · '.join(values)
