"""Kodi-owned jelk settings and read-only shortcuts to native Kodi pages."""

from __future__ import annotations

from enum import Enum

import xbmc
import xbmcaddon

LAUNCH_ON_START_SETTING = 'launch_on_start'
DEBUG_LOGGING_SETTING = 'debug_logging'


class KodiSettingsPage(str, Enum):
  CACHING = 'ActivateWindow(servicesettings,filecache)'
  VIDEO_PLAYBACK = 'ActivateWindow(playersettings,videoplayer)'
  AUDIO_OUTPUT = 'ActivateWindow(systemsettings,audio)'


class AddonSettings:
  """Typed access to values whose sole authority is Kodi's add-on settings API."""

  def __init__(self, addon: xbmcaddon.Addon) -> None:
    self.addon = addon

  @property
  def launch_on_start(self) -> bool:
    return self.addon.getSettingBool(LAUNCH_ON_START_SETTING)

  @launch_on_start.setter
  def launch_on_start(self, enabled: bool) -> None:
    self.addon.setSettingBool(LAUNCH_ON_START_SETTING, enabled)

  @property
  def debug_logging(self) -> bool:
    return self.addon.getSettingBool(DEBUG_LOGGING_SETTING)

  @debug_logging.setter
  def debug_logging(self, enabled: bool) -> None:
    self.addon.setSettingBool(DEBUG_LOGGING_SETTING, enabled)


def open_kodi_settings(page: KodiSettingsPage) -> None:
  """Open a Kodi 21 settings category without reading or changing its values."""
  if not isinstance(page, KodiSettingsPage):
    raise TypeError('Unsupported Kodi settings page.')
  xbmc.executebuiltin(page.value)
