"""Shared native-window lifetime; controller state never lives in cached controls."""

from __future__ import annotations

from collections import deque
from concurrent.futures import Future, ThreadPoolExecutor
from typing import Any, Callable, Generic, TypeVar

import xbmc
import xbmcgui

from jelk.kodi.log import event

MODAL_DIALOG = 'System.HasActiveModalDialog'
WINDOW_INVALID = 9999  # Kodi WindowIDs.h; getCurrentWindowDialogId returns this when absent.


def foreground(window: SurfaceWindow) -> bool:
  """Info labels resolve against the topmost dialog, otherwise the active window."""
  dialog_id = xbmcgui.getCurrentWindowDialogId()
  current_id = xbmcgui.getCurrentWindowId() if dialog_id == WINDOW_INVALID else dialog_id
  return bool(window.window_id) and current_id == window.window_id


def selected_position(window: SurfaceWindow, control_id: int) -> int | None:
  """Resolve through Kodi's live container, never ControlList's cached pointer."""
  if not foreground(window) or window.invalidated:
    return None
  value = xbmc.getInfoLabel(f'Container({control_id}).CurrentItem')
  try:
    position = int(value) - 1 if value else -1
    count = int(xbmc.getInfoLabel(f'Container({control_id}).NumItems') or '0')
  except ValueError:
    return None
  return position if 0 <= position < count and foreground(window) else None


class SurfaceWindow:
  """
  Mixin for both WindowXML and WindowXMLDialog callbacks.

  Kodi keeps Python control wrappers after freeing their native controls. Latch
  invalidation in onInit itself, before any queued input or completion can render.
  Controllers discard queued input and repaint after a repeated onInit. This is
  a presentation barrier, not a memory-safety guard: controls can be freed before
  Python receives onInit. Only ID-addressed messages and window properties are
  safe across that gap; never dereference a cached control's native pointer.
  """

  initialised = False
  invalidated = False
  window_id = 0

  def initialise(self, window_id: int = 0) -> str:
    if self.initialised:
      self.invalidated = True
      return 'rebuilt'
    self.initialised = True
    self.window_id = window_id or xbmcgui.getCurrentWindowId()
    return 'ready'


WindowType = TypeVar('WindowType', bound='xbmcgui.Window')


class Surface(Generic[WindowType]):
  """Own presentation and retirement without ever touching a cached control."""

  def __init__(self, window: WindowType) -> None:
    self.window = window
    self.show_pending = False
    self.closed = False

  @property
  def invalidated(self) -> bool:
    return bool(getattr(self.window, 'invalidated', False))

  def request_show(self) -> None:
    if self.closed or self.invalidated:
      return
    window_id = getattr(self.window, 'window_id', 0)
    if window_id and xbmc.getCondVisibility(f'Window.IsActive({window_id})'):
      return
    self.show_pending = True
    self.show_when_unobstructed()

  def show_when_unobstructed(self) -> None:
    if self.closed or self.invalidated or not self.show_pending:
      return
    if xbmc.getCondVisibility(MODAL_DIALOG):
      return
    self.show_pending = False
    self.window.show()

  def close(self) -> None:
    if self.closed:
      return
    self.closed = True
    self.show_pending = False
    # Window.close operates on the window ID, not vecControls. Do not reset,
    # inspect focus, or otherwise dereference controls on this retiring wrapper.
    self.window.close()


class NativeDialogs:
  """Wait for Kodi's modal APIs off the process loop; apply answers on its tick."""

  def __init__(self) -> None:
    self.worker = ThreadPoolExecutor(max_workers=1)
    self.pending: tuple[Future[Any], Callable[[Any], None]] | None = None
    self.messages: deque[tuple[str, str]] = deque()
    self.closed = False

  def request(self, work: Callable[[], Any], done: Callable[[Any], None]) -> None:
    if not self.closed and self.pending is None:
      self.pending = (self.worker.submit(work), done)

  def message(self, heading: str, message: str) -> None:
    if not self.closed:
      self.messages.append((heading, message))
      self._next_message()

  def _next_message(self) -> None:
    if self.pending is None and self.messages:
      heading, message = self.messages.popleft()
      self.request(lambda: xbmcgui.Dialog().ok(heading, message), lambda _result: None)

  def poll(self) -> None:
    if self.pending is None or not self.pending[0].done():
      return
    future, done = self.pending
    self.pending = None
    try:
      result = future.result()
    except Exception:  # noqa: BLE001 - Kodi dialog boundary; no private exception text.
      event('A Kodi dialog could not be completed.', error=True)
    else:
      done(result)
    self._next_message()

  def close(self) -> None:
    self.closed = True
    self.messages.clear()
    if self.pending is not None:
      self.pending[0].cancel()
      self.pending = None
    self.worker.shutdown(wait=False)
