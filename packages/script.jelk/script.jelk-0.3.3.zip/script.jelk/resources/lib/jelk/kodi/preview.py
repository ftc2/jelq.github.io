"""Kodi VFS cache adapter for cropped trickplay preview frames."""

from __future__ import annotations

import threading
from collections import OrderedDict
from hashlib import sha256
from uuid import uuid4

import xbmcvfs

from jelk.client import ApiError, JellyfinClient
from jelk.trickplay import TrickplayFrame, crop_trickplay_frame

PREVIEW_DIRECTORY = 'special://temp/jelk/trickplay/'
MAX_CACHED_SPRITE_SHEETS = 2
MAX_CACHED_PREVIEW_FRAMES = 12


def new_trickplay_cache_scope() -> str:
  """Return an opaque scope for one player session's temporary previews."""
  return uuid4().hex


class TrickplayPreviewCache:
  """Bounded, playback-item-scoped sprite and rendered-frame cache."""

  def __init__(
    self,
    *,
    scope: str | None = None,
    sprite_limit: int = MAX_CACHED_SPRITE_SHEETS,
    frame_limit: int = MAX_CACHED_PREVIEW_FRAMES,
  ) -> None:
    if sprite_limit < 1 or frame_limit < 1:
      raise ValueError('Trickplay cache limits must be positive.')
    self.scope = scope or new_trickplay_cache_scope()
    self.sprite_limit = sprite_limit
    self.frame_limit = frame_limit
    self._sprites: OrderedDict[str, bytes] = OrderedDict()
    self._frames: OrderedDict[str, str] = OrderedDict()
    self._lock = threading.Lock()
    self._closed = False

  @property
  def paths(self) -> set[str]:
    with self._lock:
      return set(self._frames.values())

  @property
  def sprite_count(self) -> int:
    with self._lock:
      return len(self._sprites)

  def load(self, client: JellyfinClient, frame: TrickplayFrame) -> str:
    """Fetch one sheet at most once while cropping requested cells on demand."""
    identity = sha256((self.scope + ':' + frame.key).encode('utf-8')).hexdigest()
    path = PREVIEW_DIRECTORY + identity + '.jpg'
    with self._lock:
      self._ensure_open()
      cached_path = self._frames.pop(frame.key, '')
      if cached_path and xbmcvfs.exists(cached_path):
        self._frames[frame.key] = cached_path
        return cached_path
      content = self._sprites.pop(frame.sheet_key, b'')
      if content:
        self._sprites[frame.sheet_key] = content
    if not content:
      content = client.download_image(frame.url)
      with self._lock:
        self._ensure_open()
        self._sprites[frame.sheet_key] = content
        while len(self._sprites) > self.sprite_limit:
          self._sprites.popitem(last=False)
    preview = crop_trickplay_frame(content, frame)
    if not xbmcvfs.mkdirs(PREVIEW_DIRECTORY) and not xbmcvfs.exists(PREVIEW_DIRECTORY):
      raise ApiError('Kodi could not create the trickplay preview cache.')
    temporary = path + '.tmp-' + uuid4().hex
    evicted: list[str] = []
    try:
      with self._lock:
        self._ensure_open()
        with xbmcvfs.File(temporary, 'w') as handle:
          if not handle.write(preview):
            raise ApiError('Kodi could not cache the trickplay preview.')
        if not xbmcvfs.rename(temporary, path) and not xbmcvfs.exists(path):
          raise ApiError('Kodi could not finish caching the trickplay preview.')
        self._frames.pop(frame.key, None)
        self._frames[frame.key] = path
        while len(self._frames) > self.frame_limit:
          _, expired = self._frames.popitem(last=False)
          evicted.append(expired)
    finally:
      if xbmcvfs.exists(temporary):
        xbmcvfs.delete(temporary)
    remove_trickplay_previews(set(evicted))
    return path

  def close(self) -> None:
    """Invalidate the item generation and remove every rendered preview."""
    with self._lock:
      if self._closed:
        return
      self._closed = True
      paths = set(self._frames.values())
      self._frames.clear()
      self._sprites.clear()
    remove_trickplay_previews(paths)

  def _ensure_open(self) -> None:
    if self._closed:
      raise ApiError('The trickplay preview cache is no longer active.')


def load_trickplay_preview(
  cache: TrickplayPreviewCache,
  client: JellyfinClient,
  frame: TrickplayFrame,
) -> str:
  """Load a cached trickplay cell off Kodi's UI thread."""
  return cache.load(client, frame)


def remove_trickplay_previews(paths: set[str]) -> None:
  """Best-effort cleanup of previews created for the closing player session."""
  for path in paths:
    if path.startswith(PREVIEW_DIRECTORY):
      xbmcvfs.delete(path)
