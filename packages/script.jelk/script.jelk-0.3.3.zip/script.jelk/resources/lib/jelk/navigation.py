from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from jelk.work import WorkScope

if TYPE_CHECKING:
  from jelk.models import MediaItem


@dataclass
class Screen:
  kind: str
  title: str
  parent_id: str = ''
  series_id: str = ''
  item_type: str = ''
  items: list[MediaItem] = field(default_factory=list)
  selected: int = 0
  total: int = 0
  loaded: bool = False
  detail: MediaItem | None = None
  work: WorkScope = field(default_factory=WorkScope, repr=False, compare=False)

  @property
  def has_more(self) -> bool:
    return len(self.items) < self.total


class Navigation:
  """Retain covered screens and dispose only routes removed from the stack."""

  def __init__(self) -> None:
    self.screens: list[Screen] = []

  @property
  def current(self) -> Screen:
    return self.screens[-1]

  def reset(self, screen: Screen) -> None:
    for previous in self.screens:
      previous.work.dispose()
    self.screens = [screen]

  def push(self, screen: Screen) -> None:
    if self.screens:
      screen.work.parent = self.current.work.parent
    self.screens.append(screen)

  def back(self) -> bool:
    if len(self.screens) <= 1:
      return False
    self.screens.pop().work.dispose()
    return True
