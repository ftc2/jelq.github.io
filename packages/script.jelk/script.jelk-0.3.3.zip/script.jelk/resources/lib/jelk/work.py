"""Scoped reads and independent writes; UI outcomes run on the caller's tick."""

from __future__ import annotations

import time
from concurrent.futures import Executor, Future
from dataclasses import dataclass, field
from typing import Any, Callable, Hashable

from jelk.accounts import UnsupportedAccountFormatError
from jelk.client import ApiError, AuthError, NetworkError, ServerIdentityError
from jelk.delivery import SETTINGS_DELIVERY_SECONDS, Credential, Delivery


@dataclass(frozen=True)
class Failure:
  message: str
  authentication: bool = False
  connection: bool = False
  unavailable: bool = False
  reset_required: bool = False


def classify(error: Exception) -> Failure:
  """Only API errors promise sanitized text; never expose arbitrary worker exceptions."""
  if isinstance(error, UnsupportedAccountFormatError):
    return Failure(
      'Profile reset required. Saved account files are preserved.', reset_required=True
    )
  if isinstance(error, AuthError):
    return Failure('This sign-in has expired or was not accepted. Please sign in again.', True)
  if isinstance(error, NetworkError) or (
    isinstance(error, ApiError) and 500 <= error.status < 600  # noqa: PLR2004 - HTTP server errors.
  ):
    return Failure(str(error), unavailable=True)
  if isinstance(error, ApiError):
    return Failure(str(error), connection=isinstance(error, ServerIdentityError))
  return Failure('Something went wrong. Retry or return to the previous screen.')


@dataclass(eq=False, repr=False)
class Deadline:
  when: float
  callback: Callable[[], None] | None

  def cancel(self) -> None:
    self.callback = None


@dataclass(eq=False)
class WorkScope:
  parent: WorkScope | None = field(default=None, repr=False)
  disposed: bool = False
  deadlines: dict[Hashable, Deadline] = field(default_factory=dict, repr=False)
  pending: set[Future[Any]] = field(default_factory=set, repr=False)
  failure: Failure | None = None
  retry: Callable[[], None] | None = field(default=None, repr=False)

  @property
  def alive(self) -> bool:
    return not self.disposed and (self.parent is None or self.parent.alive)

  @property
  def busy(self) -> bool:
    return bool(self.pending) and self.alive

  def dispose(self) -> None:
    self.disposed = True
    for deadline in self.deadlines.values():
      deadline.cancel()
    self.deadlines.clear()
    self.failure = None
    self.retry = None
    for future in self.pending:
      future.cancel()
    self.pending.clear()


class Deadlines:
  """Small tick-driven scheduler. Replacement/disposal invalidate captured callbacks."""

  def __init__(self, clock: Callable[[], float] | None = None) -> None:
    self.clock = clock if clock is not None else self._now
    self.pending: dict[tuple[WorkScope, Hashable], Deadline] = {}
    self.closed = False

  @staticmethod
  def _now() -> float:
    return time.monotonic()

  def schedule(
    self, owner: WorkScope, key: Hashable, when: float, callback: Callable[[], None]
  ) -> Deadline:
    previous = owner.deadlines.pop(key, None)
    if previous is not None:
      previous.cancel()
    deadline = Deadline(when, callback)
    if self.closed or not owner.alive:
      deadline.cancel()
      return deadline
    owner.deadlines[key] = deadline
    self.pending[owner, key] = deadline
    return deadline

  def poll(self) -> None:
    now = self.clock()
    for (owner, key), deadline in list(self.pending.items()):
      if self.pending.get((owner, key)) is not deadline:
        continue
      if not owner.alive:
        deadline.cancel()
      if deadline.callback is not None and deadline.when > now:
        continue
      del self.pending[owner, key]
      if owner.deadlines.get(key) is deadline:
        del owner.deadlines[key]
      callback = deadline.callback
      deadline.cancel()
      if callback is not None:
        callback()

  def close(self) -> None:
    self.closed = True
    for (owner, key), deadline in self.pending.items():
      deadline.cancel()
      if owner.deadlines.get(key) is deadline:
        del owner.deadlines[key]
    self.pending.clear()


@dataclass(repr=False)
class Read:
  owner: WorkScope
  done: Callable[[Any], None]
  retry: Callable[[], None]
  failed: Callable[[Failure], None]
  current: Callable[[], bool]


@dataclass(repr=False)
class AcceptedWrite:
  key: Hashable
  owner: WorkScope
  done: Callable[[Any], None]
  failed: Callable[[Failure], None]
  delivery: Delivery
  credential: Credential | None
  outcome: Callable[[Failure | None], None]


class WorkCoordinator:
  """Cancellation saves work when possible; owner/credential checks establish correctness."""

  def __init__(self, executor: Executor) -> None:
    self.executor = executor
    self.deadlines = Deadlines()
    self.tasks: dict[Future[Any], Read] = {}
    self.writes: dict[Future[Any], AcceptedWrite] = {}
    self.closed = False
    self.blocked: set[tuple[str, str]] = set()

  def accepts(self, credential: Credential) -> bool:
    return not self.closed and credential.boundary not in self.blocked

  def draining(self, matches: Callable[[Credential], bool]) -> bool:
    return any(w.credential is not None and matches(w.credential) for w in self.writes.values())

  def limit(self, deadline: float, matches: Callable[[Credential], bool] | None = None) -> None:
    for write in self.writes.values():
      if matches is None or (write.credential is not None and matches(write.credential)):
        write.delivery.limit(deadline)

  def writing(self, key: Hashable) -> bool:
    return any(write.key == key for write in self.writes.values())

  def submit_write(  # noqa: PLR0913 - explicit delivery and UI ownership collaborators.
    self,
    key: Hashable,
    owner: WorkScope,
    work: Callable[[], Any],
    done: Callable[[Any], None],
    failed: Callable[[Failure], None],
    *,
    delivery: Delivery | None = None,
    credential: Credential | None = None,
    outcome: Callable[[Failure | None], None] = lambda _failure: None,
    barrier: bool = False,
  ) -> None:
    """
    Accept once; UI disposal never cancels delivery or changes its authority.

    The caller supplies a captured payload/client and operation-specific timeout.
    No automatic retry: an uncertain write needs an explicit new user intention.
    """
    if not owner.alive or self.closed:
      return
    if credential is not None and not barrier and not self.accepts(credential):
      failed(Failure('Sign-in is changing. Reopen Settings after it finishes.'))
      return
    if delivery is None:
      delivery = Delivery(time.monotonic() + SETTINGS_DELIVERY_SECONDS)

    def deliver() -> Any:
      delivery.check()
      result = work()
      delivery.check()
      return result

    self.writes[self.executor.submit(deliver)] = AcceptedWrite(
      key, owner, done, failed, delivery, credential, outcome
    )

  def submit(  # noqa: PLR0913, PLR0917 - explicit read collaborators, no global lookup.
    self,
    owner: WorkScope,
    work: Callable[[], Any],
    done: Callable[[Any], None],
    retry: Callable[[], None],
    failed: Callable[[Failure], None],
    current: Callable[[], bool],
  ) -> Future[Any] | None:
    if not owner.alive or not current():
      return None
    owner.failure = None
    owner.retry = None
    future = self.executor.submit(work)
    owner.pending.add(future)
    self.tasks[future] = Read(owner, done, retry, failed, current)
    return future

  def _poll_writes(self) -> None:
    for future, write in list(self.writes.items()):
      if not future.done() and not write.delivery.expired:
        continue
      del self.writes[future]
      try:
        if write.delivery.expired:
          future.cancel()
        write.delivery.check()
        value = future.result()
      except Exception as error:  # noqa: BLE001 - sanitized executor boundary.
        failure = classify(error)
        write.outcome(failure)
        if write.owner.alive:
          write.failed(failure)
      else:
        write.outcome(None)
        if write.owner.alive:
          write.done(value)

  def poll(self) -> None:
    self.deadlines.poll()
    self._poll_writes()
    for future, read in list(self.tasks.items()):
      if future not in self.tasks:
        continue
      if not read.owner.alive or not read.current():
        future.cancel()
      elif not future.done():
        continue
      else:
        # Retire first: handlers may submit a retry or dispose other owners.
        del self.tasks[future]
        read.owner.pending.discard(future)
        try:
          value = future.result()
        except Exception as error:  # noqa: BLE001 - sanitized executor boundary.
          failure = classify(error)
          read.owner.failure = failure
          read.owner.retry = read.retry
          read.failed(failure)
        else:
          read.done(value)
        continue
      del self.tasks[future]
      read.owner.pending.discard(future)

  def discard_stale(self) -> list[Read]:
    """Retire superseded requests without awaiting the underlying network call."""
    stale = []
    for future, read in list(self.tasks.items()):
      if not read.owner.alive or not read.current():
        future.cancel()
        read.owner.pending.discard(future)
        del self.tasks[future]
        stale.append(read)
    return stale

  def close(self) -> None:
    self.closed = True
    self.deadlines.close()
    for future, read in self.tasks.items():
      read.owner.dispose()
      future.cancel()
    self.tasks.clear()
    # Invalidate UI callbacks; the process continues polling accepted delivery
    # until success or its bound. Never join an uncancellable worker here.
    for write in self.writes.values():
      write.owner.dispose()
    self.executor.shutdown(wait=False)
