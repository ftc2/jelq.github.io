"""Write delivery bounds, independent of UI lifetimes and request timeouts."""

from __future__ import annotations

import time
from copy import copy
from dataclasses import dataclass, field
from typing import Any, Callable

from jelk.client import ApiError, JellyfinClient

SETTINGS_DELIVERY_SECONDS = 45.0
DRAIN_SECONDS = 15.0
RETIRE_TIMEOUT = 3.0


class DeliveryExpiredError(ApiError):
  def __init__(self) -> None:
    super().__init__('Delivery could not be confirmed before its deadline.')


@dataclass(frozen=True, repr=False)
class Credential:
  server_id: str
  device: str
  user: str
  token: str

  @classmethod
  def of(cls, client: JellyfinClient) -> Credential:
    if not client.server_id:
      raise ValueError('A credential requires a verified server identity.')
    return cls(client.server_id, client.device_id, client.user_id, client.token)

  @property
  def boundary(self) -> tuple[str, str]:
    return self.server_id, self.device


@dataclass(repr=False)
class Delivery:
  deadline: float
  clock: Callable[[], float] = field(default=time.monotonic, repr=False)

  @property
  def expired(self) -> bool:
    return self.clock() >= self.deadline

  def check(self) -> None:
    if self.expired:
      raise DeliveryExpiredError

  def limit(self, deadline: float) -> None:
    self.deadline = min(self.deadline, deadline)


def captured_client(client: JellyfinClient, delivery: Delivery) -> JellyfinClient:
  """Guard every HTTP stage, retaining the original credential and normal timeout."""
  captured = copy(client)
  captured.transport = DeliveryTransport(client.transport, delivery)
  return captured


class DeliveryTransport:
  def __init__(self, transport: Any, delivery: Delivery) -> None:
    self.transport = transport
    self.delivery = delivery

  def request(
    self,
    method: str,
    url: str,
    headers: dict[str, str],
    body: dict[str, Any] | None,
    timeout: float,
  ) -> Any:
    self.delivery.check()
    result = self.transport.request(method, url, headers, body, timeout)
    # A call already in flight cannot be cancelled. Never turn its late result
    # into confirmation or begin a following stage after the delivery bound.
    self.delivery.check()
    return result
