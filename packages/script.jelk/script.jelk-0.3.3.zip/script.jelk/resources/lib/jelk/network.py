"""Invocation-owned HTTP sockets, retained until bounded response consumption ends."""

from __future__ import annotations

import socket
import ssl
import threading
from contextlib import suppress
from functools import partial
from http.client import HTTPConnection, HTTPSConnection
from typing import Any, cast
from urllib.error import HTTPError
from urllib.request import HTTPHandler, HTTPRedirectHandler, HTTPSHandler, Request, build_opener


class RequestCancelledError(OSError):
  def __init__(self) -> None:
    super().__init__('The request was interrupted; its outcome is unconfirmed.')


class Interrupter:
  """Cancellation is permanent. A new invocation gets a new instance."""

  def __init__(self) -> None:
    self.lock = threading.RLock()
    self.cancelled = False
    self.sockets: set[socket.socket] = set()

  def check(self) -> None:
    with self.lock:
      if self.cancelled:
        raise RequestCancelledError

  def attach(self, sock: socket.socket) -> None:
    with self.lock:
      if self.cancelled:
        sock.close()
        raise RequestCancelledError
      self.sockets.add(sock)

  def release(self, sock: socket.socket) -> None:
    with self.lock:
      self.sockets.discard(sock)
      sock.close()

  def cancel(self) -> None:
    with self.lock:
      self.cancelled = True
      for sock in self.sockets:
        with suppress(OSError):
          # close alone cannot wake a read holding a socket.makefile reference.
          # Leave TLS state intact for the reading thread and its final cleanup.
          socket.socket.shutdown(sock, socket.SHUT_RDWR)


PROCESS_NETWORK = Interrupter()


class RequestSockets:
  def __init__(self, interrupter: Interrupter) -> None:
    self.interrupter = interrupter
    self.sockets: list[socket.socket] = []

  def connect(
    self, address: tuple[str, int], timeout: float, source_address: Any = None
  ) -> socket.socket:
    self.interrupter.check()
    # DNS is a platform resolver call and cannot be interrupted by socket shutdown.
    candidates = socket.getaddrinfo(*address, 0, socket.SOCK_STREAM)
    error: OSError = OSError('No address available')
    for family, kind, proto, _name, target in candidates:
      self.interrupter.check()
      sock = socket.socket(family, kind, proto)
      self.interrupter.attach(sock)
      self.sockets.append(sock)
      try:
        sock.settimeout(timeout)
        if source_address:
          sock.bind(source_address)
        sock.connect(target)
        self.interrupter.check()
      except OSError as caught:
        error = caught
        self.interrupter.release(sock)
        self.interrupter.check()
      else:
        return sock
    raise error

  def tls(self, sock: socket.socket, context: ssl.SSLContext, hostname: str) -> ssl.SSLSocket:
    # Wrapping detaches the raw socket. Make replacement atomic with cancellation,
    # then handshake outside the lock so cancellation can interrupt it.
    with self.interrupter.lock:
      self.interrupter.check()
      wrapped = context.wrap_socket(sock, server_hostname=hostname, do_handshake_on_connect=False)
      self.interrupter.sockets.discard(sock)
      self.interrupter.attach(wrapped)
      self.sockets.append(wrapped)
    wrapped.do_handshake()
    self.interrupter.check()
    return wrapped

  def close(self) -> None:
    for sock in self.sockets:
      self.interrupter.release(sock)
    self.sockets.clear()


class TrackedHTTPConnection(HTTPConnection):
  def __init__(self, *args: Any, sockets: RequestSockets, **kwargs: Any) -> None:
    super().__init__(*args, **kwargs)
    self._create_connection = sockets.connect


class TrackedHTTPSConnection(HTTPSConnection):
  _context: ssl.SSLContext
  _tunnel_host: str | None

  def __init__(self, *args: Any, sockets: RequestSockets, **kwargs: Any) -> None:
    super().__init__(*args, **kwargs)
    self._create_connection = sockets.connect
    self.sockets = sockets

  def connect(self) -> None:
    HTTPConnection.connect(self)
    self.sock = self.sockets.tls(self.sock, self._context, self._tunnel_host or self.host)


class TrackedHTTPHandler(HTTPHandler):
  def __init__(self, sockets: RequestSockets) -> None:
    super().__init__()
    self.sockets = sockets

  def http_open(self, req: Request) -> Any:
    self.sockets.interrupter.check()
    return self.do_open(partial(TrackedHTTPConnection, sockets=self.sockets), req)


class TrackedHTTPSHandler(HTTPSHandler):
  _context: ssl.SSLContext | None

  def __init__(self, sockets: RequestSockets, context: ssl.SSLContext | None) -> None:
    super().__init__(context=context)
    self.sockets = sockets

  def https_open(self, req: Request) -> Any:
    self.sockets.interrupter.check()
    return self.do_open(
      partial(TrackedHTTPSConnection, sockets=self.sockets), req, context=self._context
    )


def read_response(  # noqa: PLR0913 - explicit request and isolated TLS/cancellation collaborators.
  request: Request,
  timeout: float,
  limit: int,
  redirect: HTTPRedirectHandler,
  *,
  interrupter: Interrupter | None = None,
  context: ssl.SSLContext | None = None,
) -> bytes:
  """Keep ownership across redirects, headers, TLS and body; never accept cancelled EOF."""
  interrupt = interrupter if interrupter is not None else PROCESS_NETWORK
  sockets = RequestSockets(interrupt)
  try:
    interrupt.check()
    opener = build_opener(
      TrackedHTTPHandler(sockets), TrackedHTTPSHandler(sockets, context), redirect
    )
    with opener.open(request, timeout=timeout) as response:
      raw = cast('bytes', response.read(limit + 1))
    interrupt.check()
  except Exception as error:
    if isinstance(error, HTTPError) and error.fp is not None:
      error.close()
    # Interrupted TLS/HTTP can raise, return an empty body, or return partial bytes.
    interrupt.check()
    raise
  else:
    return raw
  finally:
    sockets.close()
