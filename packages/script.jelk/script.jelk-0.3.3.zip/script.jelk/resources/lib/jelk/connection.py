"""Anonymous, owner-bound verification and ordered address selection."""

from __future__ import annotations

import time
from concurrent.futures import Future
from dataclasses import dataclass, field
from typing import Any, Callable

from jelk.accounts import normalize_url
from jelk.client import ApiError, ServerIdentityError
from jelk.work import Failure, WorkCoordinator, WorkScope, classify

PROBE_TIMEOUT_SECONDS = 3.0
RESOLUTION_SECONDS = 10.0
PROBE_FRESHNESS_SECONDS = 30.0
PREFERRED_GRACE_SECONDS = 0.25
MAX_PROBES = 3


@dataclass(frozen=True, repr=False)
class VerifiedConnection:
  server_id: str
  address: str
  verified_at: float
  name: str = 'Jellyfin'

  def __post_init__(self) -> None:
    if not isinstance(self.server_id, str) or not self.server_id.strip():
      raise ValueError('A connection requires a server identity.')
    object.__setattr__(self, 'address', normalize_url(self.address))


def public_identity(info: dict[str, Any], expected: str = '') -> str:
  value = info.get('Id')
  if not isinstance(value, str) or not value.strip():
    raise ApiError('The server returned an invalid public identity.')
  if expected and value != expected:
    raise ServerIdentityError
  return value


def choose_address(
  outcomes: tuple[VerifiedConnection | Failure | None, ...], now: float, deadline: float
) -> VerifiedConnection | None:
  """
  Priority wins until grace expires; completion exactly at the total bound is late.

  None means pending (including candidates waiting for capacity). Failure is terminal.
  Completion timestamps make ties independent of coordinator polling and callback order.
  """
  successes = [
    result
    for result in outcomes
    if isinstance(result, VerifiedConnection) and result.verified_at < deadline
  ]
  if not successes:
    return None
  cutoff = min(deadline, min(result.verified_at for result in successes) + PREFERRED_GRACE_SECONDS)
  for index, result in enumerate(outcomes):
    if (
      isinstance(result, VerifiedConnection)
      and result in successes
      and result.verified_at <= cutoff
    ):
      if now >= cutoff or all(outcome is not None for outcome in outcomes[:index]):
        return result
      return None
  return None


@dataclass(repr=False)
class Waiting:
  owner: WorkScope
  done: Callable[[VerifiedConnection], None]
  failed: Callable[[Failure], None]


@dataclass(repr=False)
class Candidate:
  address: str
  owner: WorkScope
  future: Future[Any] | None = None
  outcome: VerifiedConnection | Failure | None = None


@dataclass(repr=False)
class Resolution:
  server_id: str
  addresses: tuple[str, ...]
  probe: Callable[[str], dict[str, Any]]
  deadline: float
  owner: WorkScope = field(default_factory=WorkScope)
  waiting: list[Waiting] = field(default_factory=list)
  candidates: list[Candidate] = field(default_factory=list)

  def dispose(self) -> None:
    self.owner.dispose()
    for candidate in self.candidates:
      candidate.owner.dispose()


class ConnectionResolver:
  """
  Three physical slots across live and abandoned attempts, on the shared pool.

  DNS may retain its slot beyond logical expiry. A replacement can use any free
  slots but never builds an unbounded executor queue. Only the caller's tick
  mutates candidate outcomes, caches, and selection.
  """

  def __init__(self, work: WorkCoordinator, clock: Callable[[], float] = time.monotonic) -> None:
    self.work = work
    self.clock = clock
    self.cache: dict[tuple[str, tuple[str, ...]], VerifiedConnection] = {}
    self.attempt: Resolution | None = None
    self.physical: set[Future[Any]] = set()
    self.outcomes: tuple[VerifiedConnection | Failure | None, ...] = ()

  def forget(self, server_id: str, address: str) -> None:
    self.cache = {
      key: result
      for key, result in self.cache.items()
      if not (key[0] == server_id and address in key[1])
    }

  def busy(self, owner: WorkScope) -> bool:
    return self.attempt is not None and any(
      waiter.owner is owner and owner.alive for waiter in self.attempt.waiting
    )

  def resolve(  # noqa: PLR0913, PLR0917 - explicit connection and outcome collaborators.
    self,
    server_id: str,
    addresses: tuple[str, ...],
    owner: WorkScope,
    probe: Callable[[str], dict[str, Any]],
    done: Callable[[VerifiedConnection], None],
    failed: Callable[[Failure], None],
  ) -> None:
    if not owner.alive or self.work.closed:
      return
    addresses = tuple(dict.fromkeys(normalize_url(address) for address in addresses))
    if not addresses:
      raise ValueError('Resolution requires addresses.')
    attempt = self.attempt
    if attempt is not None and (
      (attempt.server_id, attempt.addresses) != (server_id, addresses)
      or not any(waiter.owner.alive for waiter in attempt.waiting)
      or self.clock() >= attempt.deadline
    ):
      attempt.dispose()
      self.attempt = attempt = None
    cached = self.cache.get((server_id, addresses))
    if cached is not None and self.clock() - cached.verified_at < PROBE_FRESHNESS_SECONDS:
      done(cached)
      return
    if attempt is None or not attempt.owner.alive:
      attempt = Resolution(server_id, addresses, probe, self.clock() + RESOLUTION_SECONDS)
      attempt.candidates = [
        Candidate(address, WorkScope(parent=attempt.owner)) for address in addresses
      ]
      self.attempt = attempt
      self.work.deadlines.schedule(attempt.owner, 'resolution', attempt.deadline, self.poll)
    attempt.waiting.append(Waiting(owner, done, failed))
    self.poll()

  def poll(self) -> None:
    self.physical = {future for future in self.physical if not future.done()}
    attempt = self.attempt
    if attempt is None:
      return
    if self.work.closed or not any(waiter.owner.alive for waiter in attempt.waiting):
      attempt.dispose()
      self.attempt = None
      return
    self._harvest(attempt)
    self.outcomes = tuple(candidate.outcome for candidate in attempt.candidates)
    now = self.clock()
    selected = choose_address(self.outcomes, now, attempt.deadline)
    if selected is not None:
      self.cache[selected.server_id, attempt.addresses] = selected
      self._finish(attempt, lambda waiter: waiter.done(selected))
      return
    if now >= attempt.deadline or all(result is not None for result in self.outcomes):
      failures = [result for result in self.outcomes if isinstance(result, Failure)]
      failure = next((result for result in failures if result.connection), None)
      failure = failure or (
        failures[0] if failures else Failure('The server connection timed out. Retry to reconnect.')
      )
      self._finish(attempt, lambda waiter: waiter.failed(failure))
      return
    successes = [result for result in self.outcomes if isinstance(result, VerifiedConnection)]
    if successes:
      grace = min(
        attempt.deadline, min(result.verified_at for result in successes) + PREFERRED_GRACE_SECONDS
      )
      self.work.deadlines.schedule(attempt.owner, 'grace', grace, self.poll)
    for candidate in attempt.candidates:
      if len(self.physical) >= MAX_PROBES:
        break
      if candidate.future is None:
        self._start(attempt, candidate)

  @staticmethod
  def _harvest(attempt: Resolution) -> None:
    # Harvest the whole completed batch before choosing, including exact grace ties.
    for candidate in attempt.candidates:
      if candidate.outcome is None and candidate.future is not None and candidate.future.done():
        try:
          candidate.outcome = candidate.future.result()
        except Exception as error:  # noqa: BLE001 - sanitized executor boundary.
          candidate.outcome = classify(error)

  def _start(self, attempt: Resolution, candidate: Candidate) -> None:
    def probe() -> VerifiedConnection:
      info = attempt.probe(candidate.address)
      name = info.get('ServerName')
      return VerifiedConnection(
        public_identity(info, attempt.server_id),
        candidate.address,
        self.clock(),
        name if isinstance(name, str) and name.strip() else 'Jellyfin',
      )

    candidate.future = self.work.submit(
      candidate.owner,
      probe,
      lambda _result: self.poll(),
      lambda: None,
      lambda _failure: self.poll(),
      lambda: self.attempt is attempt and any(w.owner.alive for w in attempt.waiting),
    )
    if candidate.future is not None:
      self.physical.add(candidate.future)

  def _finish(self, attempt: Resolution, deliver: Callable[[Waiting], None]) -> None:
    self.attempt = None
    attempt.dispose()
    for waiter in attempt.waiting:
      if waiter.owner.alive:
        deliver(waiter)
