"""Stable client identity shared by Jellyfin requests and release metadata tests."""

VERSION = '0.3.3'
USER_AGENT = 'jelk/' + VERSION
