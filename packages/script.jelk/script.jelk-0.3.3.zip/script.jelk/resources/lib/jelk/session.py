"""Watching identity, credential snapshots, and session-owned participant lifetimes."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Callable

from jelk.client import JellyfinClient
from jelk.work import WorkScope

if TYPE_CHECKING:
  from jelk.accounts import Account, Server
  from jelk.connection import VerifiedConnection


@dataclass(frozen=True)
class SessionIdentity:
  """Participant order, credentials, names, and addresses are not identity."""

  server_id: str
  user_ids: frozenset[str]

  def __post_init__(self) -> None:
    if not isinstance(self.server_id, str) or not self.server_id.strip():
      raise ValueError('A session requires a server identity.')
    if not self.user_ids or any(
      not isinstance(user, str) or not user.strip() for user in self.user_ids
    ):
      raise ValueError('A session requires participant identities.')
    object.__setattr__(self, 'user_ids', frozenset(self.user_ids))


@dataclass(frozen=True)
class WatchingSession:
  """An ordered immutable snapshot; full equality includes credential/address changes."""

  server: Server
  participants: tuple[Account, ...] = field(repr=False)

  def __post_init__(self) -> None:
    participants = tuple(self.participants)
    if not participants:
      raise ValueError('A watching session requires participants.')
    if any(account.server_id != self.server.id for account in participants):
      raise ValueError('Every participant must belong to the session server.')
    if len({account.user_id for account in participants}) != len(participants):
      raise ValueError('A watching session cannot repeat a participant identity.')
    object.__setattr__(self, 'participants', participants)

  @property
  def identity(self) -> SessionIdentity:
    return SessionIdentity(
      self.server.id, frozenset(account.user_id for account in self.participants)
    )


@dataclass(repr=False)
class CredentialRecovery:
  authentication_required: bool = False
  attempt: WorkScope | None = None
  interrupted: dict[WorkScope, Callable[[], None]] = field(default_factory=dict)


@dataclass(frozen=True, repr=False, eq=False)
class ParticipantBinding:
  """Object identity is the generation checked by reads and UI continuations."""

  account: Account
  client: JellyfinClient
  recovery: CredentialRecovery = field(default_factory=CredentialRecovery)


class SessionRuntime:
  """One authoritative value, connection, work scope, and binding per participant."""

  def __init__(
    self,
    value: WatchingSession,
    connection: VerifiedConnection,
    client_factory: Callable[..., JellyfinClient] = JellyfinClient,
  ) -> None:
    self.work = WorkScope()
    self._client_factory = client_factory
    self._value = value
    self._connection: VerifiedConnection | None = None
    self._bindings: tuple[ParticipantBinding, ...] = ()
    self.replace(value, connection)

  @property
  def value(self) -> WatchingSession:
    return self._value

  @property
  def connection(self) -> VerifiedConnection | None:
    return self._connection

  @property
  def bindings(self) -> tuple[ParticipantBinding, ...]:
    return self._bindings

  def single(self) -> ParticipantBinding:
    """M4 product policy: reject plural authority rather than infer it from order."""
    if len(self._bindings) != 1:
      raise ValueError('This operation requires exactly one watching participant.')
    return self._bindings[0]

  def current(self, binding: ParticipantBinding) -> bool:
    return self.work.alive and self._connection is not None and binding in self._bindings

  def invalidate_connection(self) -> None:
    self._connection = None

  def replace(self, value: WatchingSession, connection: VerifiedConnection) -> None:
    """Replace snapshots for unchanged identity, atomically retaining unaffected bindings."""
    if not self.work.alive or value.identity != self._value.identity:
      raise ValueError('A different watching identity requires a new session runtime.')
    if connection.server_id != value.server.id or connection.address not in value.server.addresses:
      raise ValueError('The session requires a verified address from its saved server.')
    previous = {binding.account.user_id: binding for binding in self._bindings}
    bindings = []
    for account in value.participants:
      old = previous.get(account.user_id)
      if old is not None and old.account == account and self._connection == connection:
        bindings.append(old)
      else:
        client = self._client_factory(
          connection.address,
          account.device_id,
          account.token,
          account.user_id,
          server_id=connection.server_id,
        )
        bindings.append(ParticipantBinding(account, client))
    for old in self._bindings:
      if old not in bindings and old.recovery.attempt is not None:
        old.recovery.attempt.dispose()
    self._value, self._connection, self._bindings = value, connection, tuple(bindings)

  def dispose(self) -> None:
    self.work.dispose()
    for binding in self._bindings:
      if binding.recovery.attempt is not None:
        binding.recovery.attempt.dispose()
      binding.recovery.interrupted.clear()
