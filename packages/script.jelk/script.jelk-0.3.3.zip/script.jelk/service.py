from __future__ import annotations

import xbmc
import xbmcaddon
import xbmcgui

if __name__ == '__main__':
  monitor = xbmc.Monitor()
  if not monitor.waitForAbort(2):
    addon = xbmcaddon.Addon()
    if addon.getSettingBool('launch_on_start') and not xbmcgui.Window(10000).getProperty(
      'jelk.active'
    ):
      xbmc.executebuiltin('RunScript(script.jelk)')
